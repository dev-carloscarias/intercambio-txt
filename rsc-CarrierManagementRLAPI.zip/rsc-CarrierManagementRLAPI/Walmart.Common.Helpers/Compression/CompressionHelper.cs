﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Text;

namespace Walmart.Common.Helpers
{
    /// <summary>
    /// Implement compression helper
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class CompressionHelper
    {
        #region Methods
        /// <summary>
        /// Compression is an easy and effective way to reduce the size
        /// of packages and increase the speed.
        /// </summary>
        /// <param name="str">Byte array</param>
        /// <returns>Byte array deflate</returns>
        public static byte[] DeflateByte(byte[] str)
        {
            if (str == null)
            {
                return new byte[0];
            }

            try
            {
                using (var output = new MemoryStream())
                {
                    using (
                        var compressor = new Ionic.Zlib.DeflateStream(
                        output,
                        Ionic.Zlib.CompressionMode.Compress,
                        Ionic.Zlib.CompressionLevel.BestSpeed))
                    {
                        compressor.Write(str, 0, str.Length);
                    }

                    return output.ToArray();
                }
            }
            catch (MemberAccessException)
            {
                return new byte[0];
            }
            catch (Exception)
            {
                return new byte[0];
            }
        }
        #endregion
    }
}
