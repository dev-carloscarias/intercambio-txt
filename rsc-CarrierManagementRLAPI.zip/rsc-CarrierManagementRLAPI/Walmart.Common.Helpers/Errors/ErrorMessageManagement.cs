﻿//-----------------------------------------------------------------------    
// <copyright file="ErrorMessageManagement.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Esteban Barboza</author>    
//----------------------------------------------------------------------- 
namespace Walmart.Common.Helpers
{
    using System.Globalization;
    using Microsoft.AspNetCore.Mvc.ModelBinding;
    using Newtonsoft.Json;

    /// <summary>
    /// Helper class for return to user errors messages and help likes as well
    /// </summary>
    public static class ErrorMessageManagement
    {
        /// <summary>
        /// Message error to show to user
        /// </summary>
        private const string UserMessageError = "userMessage";

        /// <summary>
        /// Message error to internal management
        /// </summary>
        private const string InternalMessageError = "internalMessage";

        /// <summary>
        /// Link for help to user
        /// </summary>
        private const string UserLinkHelp = "link";

        /// <summary>
        /// Error message code
        /// </summary>
        private const string UserCodeError = "codeError";

        /// <summary>
        /// Error message code
        /// </summary>
        private const string EntityError = "entityError";

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <param name="userMessage">Error message to show to user</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages(string userMessage) => GetMessages(userMessage, null, null, 0);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <typeparam name="T">Generic entity</typeparam>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="genericObject">Generic entity property</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages<T>(string userMessage, T genericObject) where T : class => GetMessages(userMessage, null, null, 0, genericObject);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="errorCode">Error code property</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages(string userMessage, int errorCode) => GetMessages(userMessage, null, null, errorCode);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <typeparam name="T">Generic entity</typeparam>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="errorCode">Error code property</param>
        /// <param name="genericObject">Generic entity property</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages<T>(string userMessage, int errorCode, T genericObject) where T : class => GetMessages(userMessage, null, null, errorCode, genericObject);
        
        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages(string userMessage, string exceptionMessage) => GetMessages(userMessage, exceptionMessage, null, 0);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <typeparam name="T">Generic entity</typeparam>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <param name="genericObject">Generic entity property</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages<T>(string userMessage, string exceptionMessage, T genericObject) where T : class => GetMessages(userMessage, exceptionMessage, null, 0, genericObject);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <param name="helpLink">Link where the user can get more information for the error</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages(string userMessage, string exceptionMessage, string helpLink) => GetMessages(userMessage, exceptionMessage, helpLink, 0);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <typeparam name="T">Generic entity</typeparam>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <param name="helpLink">Link where the user can get more information for the error</param>
        /// <param name="genericObject">Generic entity property</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages<T>(string userMessage, string exceptionMessage, string helpLink, T genericObject) where T : class => GetMessages(userMessage, exceptionMessage, helpLink, 0, genericObject);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <param name="errorCode">Error code property</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages(string userMessage, string exceptionMessage, int errorCode) => GetMessages(userMessage, exceptionMessage, string.Empty, errorCode);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <typeparam name="T">Generic entity</typeparam>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <param name="errorCode">Error code property</param>
        /// <param name="genericObject">Generic entity property</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages<T>(string userMessage, string exceptionMessage, int errorCode, T genericObject) where T : class => GetMessages(userMessage, exceptionMessage, string.Empty, errorCode, genericObject);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <param name="helpLink">Link where the user can get more information for the error</param>
        /// <param name="errorCode">Error code property</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages(string userMessage, string exceptionMessage, string helpLink, int errorCode) => GetMessages(userMessage, exceptionMessage, helpLink, errorCode);

        /// <summary>
        /// Sets an errors messages to response
        /// </summary>
        /// <typeparam name="T">Generic entity</typeparam>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <param name="helpLink">Link where the user can get more information for the error</param>
        /// <param name="errorCode">Error code property</param>
        /// <param name="genericObject">Generic entity property</param>
        /// <returns>Model error dictionary</returns>
        public static ModelStateDictionary SetsErrorMessages<T>(string userMessage, string exceptionMessage, string helpLink, int errorCode, T genericObject) where T : class => GetMessages(userMessage, exceptionMessage, helpLink, errorCode, genericObject);

        /// <summary>
        /// Gets required errors messages
        /// </summary>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <param name="helpLink">Link where the user can get more information for the error</param>
        /// <param name="errorCode">Error code property</param>
        /// <returns>Model error dictionary</returns>
        private static ModelStateDictionary GetMessages(string userMessage, string exceptionMessage, string helpLink, int errorCode)
        {
            ModelStateDictionary modelState = new ModelStateDictionary();
            modelState.AddModelError(UserMessageError, userMessage);

            if (!string.IsNullOrEmpty(exceptionMessage))
            {
                modelState.AddModelError(InternalMessageError, exceptionMessage);
            }

            if (!string.IsNullOrEmpty(helpLink))
            {
                modelState.AddModelError(UserLinkHelp, helpLink);
            }

            if (errorCode != 0)
            {
                modelState.AddModelError(UserCodeError, errorCode.ToString(CultureInfo.InvariantCulture));
            }

            return modelState;
        }

        /// <summary>
        /// Gets required errors messages
        /// </summary>
        /// <typeparam name="T">Generic entity</typeparam>
        /// <param name="userMessage">Error message to show to user</param>
        /// <param name="exceptionMessage">Exception error message to internal management</param>
        /// <param name="helpLink">Link where the user can get more information for the error</param>
        /// <param name="errorCode">Error code property</param>
        /// <param name="genericObject">Generic object property error</param>
        /// <returns>Model error dictionary</returns>
        private static ModelStateDictionary GetMessages<T>(string userMessage, string exceptionMessage, string helpLink, int errorCode, T genericObject) where T : class
        {
            ModelStateDictionary modelState = new ModelStateDictionary();
            modelState.AddModelError(UserMessageError, userMessage);

            if (!string.IsNullOrEmpty(exceptionMessage))
            {
                modelState.AddModelError(InternalMessageError, exceptionMessage);
            }

            if (!string.IsNullOrEmpty(helpLink))
            {
                modelState.AddModelError(UserLinkHelp, helpLink);
            }

            if (errorCode != 0)
            {
                modelState.AddModelError(UserCodeError, errorCode.ToString(CultureInfo.InvariantCulture));
            }

            if (genericObject != null)
            {
                modelState.AddModelError(EntityError, JsonConvert.SerializeObject(genericObject));
            }

            return modelState;
        }
    }
}