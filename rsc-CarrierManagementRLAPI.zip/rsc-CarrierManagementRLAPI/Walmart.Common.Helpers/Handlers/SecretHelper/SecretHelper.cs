﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walmart.Common.Helpers.Handlers
{
    public class SecretHelper: ISecretHelper
    {
        private string basePath { get; set; }
        private string env { get; set; }
        public SecretHelper(string env)
        {
            this.env = env;
            this.basePath = getBasePathFromEnvironment();
        }

        private string readFromFile(string name)
        {
            string path = Path.Combine(basePath, name);
            try
            {
                return File.ReadAllText(path);
            }
            catch (Exception)
            {
                return "Not Found File" + path;
            }
        }

        private string getBasePathFromEnvironment()
        {
            if (env.Equals("localhost")) return Path.Combine(Environment.CurrentDirectory, @"config/txt/");
            else if (env.Equals("development")) return "/etc/secrets/dev/";
            else if (env.Equals("staging")) return "/etc/secrets/stage/";
            else if (env.Equals("production")) return "/etc/secrets/prod/";
            return "/etc/secrets/dev/";
        }

        public bool IsDevelopmentEnvironment()
        {
            if (env.Equals("localhost") || env.Equals("development")) return true;

            return false;
        }


        public string getDBCarrierConnection()
        {
            return readFromFile("database_carrier.txt");
        }

        public string getDBTMSConnection()
        {
            return readFromFile("database_tms.txt");
        }

        public string getElasticSearchUrl()
        {
            return readFromFile("elasticsearch-url.txt");
        }

        public string getElasticSearchFormat()
        {
            return readFromFile("elasticsearch-indexFormat.txt");
        }

        public string getElasticSearchTemplate()
        {
            return readFromFile("elasticsearch-templateName.txt");
        }

        public string getElasticSearchType()
        {
            return readFromFile("elasticsearch-typeName.txt");
        }

        public string getApiBaseUrl()
        {
            return readFromFile("api_base_url.txt");
        }

        public string getItemFileClientId()
        {
            return readFromFile("item_file_client_id.txt");
        }

        public string getItemFileClientSec()
        {
            return readFromFile("item_file_client_sec.txt");
        }

        public string getItemFileTokenScopes()
        {
            return readFromFile("item_file_token_scopes.txt");
        }

        public string getSTFPServer()
        {
            return readFromFile("stfp_server.txt");
        }

        public string getFalconBaseUrl()
        {
            return readFromFile("falcon_base_url.txt");
        }

        public string getFalconClientId()
        {
            return readFromFile("falcon_client_id.txt");
        }

        public string getFalconType()
        {
            return readFromFile("falcon_client_type.txt");
        }

        public string getSTSTokenProvider()
        {
            return readFromFile("sts_token_provider.txt");
        }

        public string getServiceRegistryPK()
        {
            return readFromFile("service_registry_pk.txt");
        }

        public string getWmSvcName()
        {
            return readFromFile("wm_svc_name.txt");
        }

        public string getWmSvcEnv()
        {
            return readFromFile("wm_svc_env.txt");
        }

        public string getWmConsumerId()
        {
            return readFromFile("wm_consumer_id.txt");
        }

        public string getWmRegistryVersion()
        {
            return readFromFile("wm_registry_version.txt");
        }
    }
}
