﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walmart.Common.Helpers.Handlers
{
    public interface ISecretHelper
    {
        public string getDBCarrierConnection();
        public string getDBTMSConnection();
        public string getElasticSearchUrl();
        public string getElasticSearchFormat();
        public string getElasticSearchTemplate();
        public string getElasticSearchType();
        public string getApiBaseUrl();
        public string getItemFileClientId();
        public string getItemFileClientSec();
        public string getItemFileTokenScopes();
        public string getSTFPServer();
        public string getFalconBaseUrl();
        public string getFalconClientId();
        public string getFalconType();
        public string getSTSTokenProvider();

        public string getServiceRegistryPK();
        
        public string getWmSvcName();
        public string getWmSvcEnv();
        public string getWmConsumerId();
        public string getWmRegistryVersion();
    }

   
}
