﻿namespace Walmart.Common.Helpers
{
    public class TokenConfiguration : ITokenConfiguration
    {
        public string STSTokenEndpoint { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string ImageUserInfoPath { get; set; }
    }
}
