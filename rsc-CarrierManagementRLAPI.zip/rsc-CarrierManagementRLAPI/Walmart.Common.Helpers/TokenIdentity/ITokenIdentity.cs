﻿//---------------------------------------------------------------------------------------    
// <copyright file="ITokenIdentity.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Helpers
{
    using Microsoft.AspNetCore.Http;
    using System.Threading.Tasks;
    using System.Web;

    /// <summary>
    /// Token identity helper interface
    /// </summary>
    public interface ITokenIdentity
    {
        /// <summary>
        /// Get owner key token from service
        /// </summary>
        /// <param name="context">Current context</param>
        /// <returns>Owner token</returns>
        string GetOwnerIdFromToken(HttpContext context);

        /// <summary>
        /// Get access key token
        /// </summary>
        /// <param name="context">Current context</param>
        /// <returns>Owner token</returns>
        string GetAccessToken(HttpContext context);

        /// <summary>
        /// Gets user image
        /// </summary>
        /// <param name="context">Current context</param>
        /// <returns>Image string</returns>        
        Task<string> GetUserImage(HttpContext context);
    }
}