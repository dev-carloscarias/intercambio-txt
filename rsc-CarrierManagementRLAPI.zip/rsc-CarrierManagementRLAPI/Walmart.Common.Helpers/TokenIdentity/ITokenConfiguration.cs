﻿namespace Walmart.Common.Helpers
{
    /// <summary>
    /// Defines the properties for the configuration of Token Client
    /// </summary>
    public interface ITokenConfiguration
    {
        string STSTokenEndpoint { get; set; }
        string ClientId { get; set; }
        string ClientSecret { get; set; }
        string ImageUserInfoPath { get; set; }
    }
}
