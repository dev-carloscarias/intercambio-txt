﻿//---------------------------------------------------------------------------------------    
// <copyright file="ListToDataTableConverter.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Helpers
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Globalization;

    /// <summary>
    /// List to data table converter
    /// </summary>
    public static class ListToDataTableConverter
    {
        /// <summary>
        /// Class list to data table
        /// </summary>
        /// <typeparam name="T">Generic property</typeparam>
        /// <param name="list">Generic object property</param>
        /// <returns>Data table object</returns>
        public static DataTable ClassListToDataTable<T>(IList<T> list) where T : class
        {
            var table = CreateTable<T>();
            var entityType = typeof(T);
            var properties = TypeDescriptor.GetProperties(entityType);

            foreach (T item in list)
            {
                var row = table.NewRow();

                foreach (PropertyDescriptor prop in properties)
                {
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                }

                table.Rows.Add(row);
            }

            return table;
        }

        /// <summary>
        /// Create table object
        /// </summary>
        /// <typeparam name="T">Generic property</typeparam>
        /// <returns>Data table object</returns>
        public static DataTable CreateTable<T>() where T : class
        {
            var entityType = typeof(T);
            var table = new DataTable(entityType.Name);
            table.Locale = CultureInfo.InvariantCulture;

            var properties = TypeDescriptor.GetProperties(entityType);

            foreach (PropertyDescriptor prop in properties)
            {
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            }

            return table;
        }
    }
}