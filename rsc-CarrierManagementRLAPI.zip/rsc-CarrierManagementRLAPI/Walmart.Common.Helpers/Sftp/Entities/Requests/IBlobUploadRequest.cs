﻿//---------------------------------------------------------------------------------------    
// <copyright file="IBlobUploadRequest.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.SecureFtpClient
{
    #region Using
    #endregion

    /// <summary>
    /// Upload model interface
    /// </summary>
    public interface IBlobUploadRequest
    {
        /// <summary>
        /// Gets or sets File key
        /// </summary>       
        string FileId { get; set; }

        /// <summary>
        /// Gets or sets file stream
        /// </summary>        
        byte[] File { get; set; }       

        /// <summary>
        /// Gets or sets file name
        /// </summary>
        string FileName { get; set; }

        /// <summary>
        /// Gets or sets user name
        /// </summary>
        string UserName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether sensitive data property
        /// </summary>
        bool SensitiveData { get; set; }        
    }
}