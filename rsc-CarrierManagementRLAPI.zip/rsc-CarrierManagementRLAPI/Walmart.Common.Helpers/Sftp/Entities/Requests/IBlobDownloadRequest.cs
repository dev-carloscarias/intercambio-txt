﻿//---------------------------------------------------------------------------------------    
// <copyright file="IBlobDownloadRequest.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.SecureFtpClient
{
    #region Using
    #endregion

    /// <summary>
    /// Upload model interface
    /// </summary>
    public interface IBlobDownloadRequest
    {
        /// <summary>
        /// Gets or sets File key
        /// </summary>       
        string FileId { get; set; }       
    }
}