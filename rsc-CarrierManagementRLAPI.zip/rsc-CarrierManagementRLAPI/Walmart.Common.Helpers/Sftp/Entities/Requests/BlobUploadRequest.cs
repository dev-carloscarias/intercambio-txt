//---------------------------------------------------------------------------------------    
// <copyright file="BlobUploadRequest.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.SecureFtpClient
{
    #region Using
    using System;
    using Walmart.Common.Models;
    #endregion

    /// <summary>
    /// Upload model class
    /// </summary>
    public class BlobUploadRequest : IBlobUploadRequest, IBlobCredentials
    {
        /// <summary>
        /// Gets or sets File key
        /// </summary>       
        public string FileId { get; set; }

        /// <summary>
        /// Gets or sets file key
        /// </summary>       
        public byte[] File { get; set; }
        
        /// <summary>
        /// Gets or sets file name
        /// </summary>
        public string FileName { get; set; }

        /// <summary>
        /// Gets or sets user name
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether sensitive data property
        /// </summary>
        public bool SensitiveData { get; set; }

        /// <summary>
        /// Gets or sets secure server name
        /// </summary>   
        public string SftpHost { get; set; }

        /// <summary>
        /// Gets or sets secure port number
        /// </summary>        
        public int SftpPort { get; set; }

        /// <summary>
        /// Gets or sets secure user name
        /// </summary>
        public string SftpUserName { get; set; }

        /// <summary>
        /// Gets or sets secure password name
        /// </summary>
        public string SftpSecret { get; set; }

        /// <summary>
        /// Gets or sets secure folder
        /// </summary>
        public string SftpShareFolder { get; set; }
    }
}