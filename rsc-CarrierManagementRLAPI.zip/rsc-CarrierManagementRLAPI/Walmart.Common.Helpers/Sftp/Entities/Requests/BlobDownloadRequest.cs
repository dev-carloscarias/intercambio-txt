//---------------------------------------------------------------------------------------    
// <copyright file="BlobDownloadRequest.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.SecureFtpClient
{
    #region Using

    using Walmart.Common.Models;
    #endregion

    /// <summary>
    /// Upload model class
    /// </summary>
    public class BlobDownloadRequest : IBlobDownloadRequest, IBlobCredentials
    {
        /// <summary>
        /// Gets or sets File key
        /// </summary>       
        public string FileId { get; set; }
        
        /// <summary>
        /// Gets or sets secure server name
        /// </summary>   
        public string SftpHost { get; set; }

        /// <summary>
        /// Gets or sets secure port number
        /// </summary>        
        public int SftpPort { get; set; }

        /// <summary>
        /// Gets or sets secure user name
        /// </summary>
        public string SftpUserName { get; set; }

        /// <summary>
        /// Gets or sets secure password name
        /// </summary>
        public string SftpSecret { get; set; }

        /// <summary>
        /// Gets or sets secure folder
        /// </summary>
        public string SftpShareFolder { get; set; }
    }
}