
//---------------------------------------------------------------------------------------    
// <copyright file="IBlobCredentials.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Models
{
    #region Using
    #endregion

    /// <summary>
    /// Credential upload model interface
    /// </summary>
    public interface IBlobCredentials
    {
        /// <summary>
        /// Gets or sets secure server name
        /// </summary>        
        string SftpHost { get; set; }

        /// <summary>
        /// Gets or sets secure port number
        /// </summary>        
        int SftpPort { get; set; }

        /// <summary>
        /// Gets or sets secure user name
        /// </summary>
        string SftpUserName { get; set; }

        /// <summary>
        /// Gets or sets secure password name
        /// </summary>
        string SftpSecret { get; set; }

        /// <summary>
        /// Gets or sets secure folder
        /// </summary>
        string SftpShareFolder { get; set; }
    }
}