﻿//---------------------------------------------------------------------------------------    
// <copyright file="IBlobUploadResponse.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.SecureFtpClient
{
    #region Using
    using Newtonsoft.Json;
    #endregion

    /// <summary>
    /// Upload model interface
    /// </summary>
    public interface IBlobUploadResponse
    {
        /// <summary>
        /// Gets or sets File key
        /// </summary>       
        [JsonProperty("FileId")]
        string FileId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether success data property
        /// </summary>
        bool Success { get; set; }

        /// <summary>
        /// Gets or sets messages value
        /// </summary>
        string Messages { get; set; }
    }
}