﻿//---------------------------------------------------------------------------------------    
// <copyright file="IHeaderResponse.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.SecureFtpClient
{
    #region Using
    using System;
    using System.Net;
    #endregion

    /// <summary>
    /// Header response interface
    /// </summary>
    public interface IHeaderResponse
    {
        /// <summary>
        /// Gets or sets returned results
        /// </summary>
        int ReturnedResults { get; set; }

        /// <summary>
        /// Gets or sets status code
        /// </summary>
        HttpStatusCode StatusCode { get; set; }

        /// <summary>
        /// Gets or sets timestamp response
        /// </summary>
        DateTime Timestamp { get; set; }

        /// <summary>
        /// Gets or sets total results
        /// </summary>
        int TotalResults { get; set; }

        /// <summary>
        /// Gets or sets version
        /// </summary>
        string Version { get; set; }
    }
}