﻿//---------------------------------------------------------------------------------------    
// <copyright file="BlobUploadResponse.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.SecureFtpClient
{
    #region Using
    #endregion

    /// <summary>
    /// Upload model interface
    /// </summary>
    public class BlobUploadResponse : IBlobUploadResponse
    {
        /// <summary>
        /// Gets or sets File key
        /// </summary>       
        public string FileId { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether success data property
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// Gets or sets messages value
        /// </summary>
        public string Messages { get; set; }
    }
}