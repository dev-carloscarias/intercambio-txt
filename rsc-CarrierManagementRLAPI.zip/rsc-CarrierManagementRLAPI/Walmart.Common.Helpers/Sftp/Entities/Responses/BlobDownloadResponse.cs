﻿//---------------------------------------------------------------------------------------    
// <copyright file="BlobDownloadResponse.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.SecureFtpClient
{
    #region Using
    #endregion

    /// <summary>
    /// Download model class
    /// </summary>
    public class BlobDownloadResponse : IBlobDownloadResponse
    {
        /// <summary>
        /// Gets or sets File key
        /// </summary>        
        public string FileId { get; set; }

        /// <summary>
        /// Gets or sets blob stream
        /// </summary>       
        public byte[] BlobStream { get; set; }

        /// <summary>
        /// Gets or sets blob file name
        /// </summary>        
        public string BlobFileName { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether success data property
        /// </summary>        
        public bool Success { get; set; }

        /// <summary>
        /// Gets or sets messages value
        /// </summary>
        public string Messages { get; set; }        
    }
}