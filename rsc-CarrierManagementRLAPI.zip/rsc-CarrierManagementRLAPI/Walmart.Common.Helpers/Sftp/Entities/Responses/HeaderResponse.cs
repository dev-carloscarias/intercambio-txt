﻿//---------------------------------------------------------------------------------------    
// <copyright file="HeaderResponse.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.SecureFtpClient
{
    #region Using
    using System;
    using System.Net;
    #endregion

    /// <summary>
    /// Header response class
    /// </summary>
    public class HeaderResponse : IHeaderResponse
    {
        /// <summary>
        /// Gets or sets object version
        /// </summary>
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets status code
        /// </summary>
        public HttpStatusCode StatusCode { get; set; }

        /// <summary>
        /// Gets or sets total results
        /// </summary>        
        public int TotalResults { get; set; }

        /// <summary>
        /// Gets or sets returned results
        /// </summary>       
        public int ReturnedResults { get; set; }

        /// <summary>
        /// Gets or sets timestamp response
        /// </summary>       
        public DateTime Timestamp { get; set; }
    }
}
