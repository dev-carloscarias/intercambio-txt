﻿//---------------------------------------------------------------------------------------    
// <copyright file="SqlReaderHelper.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Helpers
{
    using System;
    using System.ComponentModel;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;

    /// <summary>
    /// Helper class for dataReader, which allows for the calling code to retrieve a value in a generic fashion.
    /// </summary>
    public static class SqlReaderHelper
    {
        /// <summary>
        /// Returns the value, of type T, from the dataReader, accounting for both generic and non-generic types.
        /// </summary>
        /// <typeparam name="T">T, type applied</typeparam>
        /// <param name="theReader">The dataReader object that queried the database</param>
        /// <param name="theColumnName">The column of data to retrieve a value from</param>
        /// <returns>T, type applied; default value of type if database value is null</returns>
        public static T GetValue<T>(this SqlDataReader theReader, string theColumnName)
        {
            // Read the value out of the reader by string (column name); returns object
            object theValue = theReader[theColumnName];

            // Cast to the generic type applied to this method (i.e. int?)
            Type theValueType = typeof(T);

            // Check for null value from the database
            if (DBNull.Value != theValue)
            {
                // We have a null, do we have a nullable type for T?
                if (!IsNullableType(theValueType))
                {
                    // No, this is not a nullable type so just change the value's type from object to T
                    return (T)Convert.ChangeType(theValue, theValueType, CultureInfo.InvariantCulture);
                }
                else
                {
                    // Yes, this is a nullable type so change the value's type from object to the underlying type of T
                    NullableConverter theNullableConverter = new NullableConverter(theValueType);

                    return (T)Convert.ChangeType(theValue, theNullableConverter.UnderlyingType, CultureInfo.InvariantCulture);
                }
            }

            // The value was null in the database, so return the default value for T; this will vary based on what T is (i.e. int has a default of 0)
            return default(T);
        }

        /// <summary>
        /// Returns the value, of type T, from the dataReader, accounting for both generic and non-generic types.
        /// </summary>
        /// <param name="theReader">The dataReader object that queried the database</param>
        /// <param name="property">Reflection property value</param>
        /// <returns>Default value of type, if database value is null</returns>
        public static object SetValue(this DbDataReader theReader, System.Reflection.PropertyInfo property)
        {

            // Validate public parameters
            if (property == null) return null;
            if (theReader == null) return SetANulleableValue(property.PropertyType); 

            // Get the DisyplayName for populate the object  
            string displayName = null;

            if (property.GetCustomAttributes(typeof(DisplayNameAttribute), true).Any())
            {
                displayName = property.GetCustomAttributes(typeof(DisplayNameAttribute), true).Cast<DisplayNameAttribute>().Single().DisplayName;
            }

            // Cast to the generic type applied to this method (i.e. int?)
            Type theValueType = property.PropertyType;

            if (!Enumerable.Range(0, theReader.FieldCount).Any(i => theReader.GetName(i) == (!string.IsNullOrEmpty(displayName) ? displayName : property.Name)))
            {
                return SetANulleableValue(theValueType);
            }

            // Read the value out of the reader by string (column name); returns object
            object theValue = theReader[!string.IsNullOrEmpty(displayName) ? displayName : property.Name];

            // Check for null value from the database
            if (Convert.IsDBNull(theValue))
            {
                return SetANulleableValue(theValueType);
            }

            if (theValue.GetType() != theValueType)
            {
                if (IsNullableType(theValueType))
                {
                    NullableConverter theNullableConverter = new NullableConverter(theValueType);
                    return Convert.ChangeType(theValue, theNullableConverter.UnderlyingType, CultureInfo.InvariantCulture);
                }

                return Convert.ChangeType(theValue, theValueType, CultureInfo.InvariantCulture);
            }

            // The value was null in the database, so return the default value for T; this will vary based on what T is (i.e. int has a default of 0)
            return theValue;
        }        

        /// <summary>
        /// Populate an object from SQL Reader when using the same names properties or Displays names from data base tables.
        /// </summary>
        /// <typeparam name="T">Generic entity to create</typeparam>
        /// <param name="reader">SQL reader that have all DB info</param>
        /// <returns>A populate object from SQL Data Reader</returns>
        public static T GetPopulateObject<T>(DbDataReader reader) where T : new()
        {
            var objToPopulate = new T();

            if (reader != null && reader.FieldCount > 0)
            {
                foreach (var item in objToPopulate.GetType().GetProperties())
                {
                    item.SetValue(objToPopulate, SetValue(reader, item));
                }
            }

            return objToPopulate;
        }

        /// <summary>
        /// Is empty type
        /// </summary>
        /// <param name="theValueType">Property value</param>
        /// <returns>Empty type</returns>
        private static bool IsNullableType(Type theValueType)
        {
            return theValueType.IsGenericType && theValueType.GetGenericTypeDefinition().Equals(typeof(Nullable<>));
        }

        /// <summary>
        /// Sets a null or new instance of the value for property
        /// </summary>
        /// <param name="theValueType">The property value type</param>
        /// <returns>A new value for the property type</returns>
        private static object SetANulleableValue(Type theValueType)
        {
            // We have a null, do we have a nullable type for T?
            if (!theValueType.IsValueType || (Nullable.GetUnderlyingType(theValueType) != null))
            {
                return null;
            }

            if (theValueType.IsValueType)
            {
                return Activator.CreateInstance(theValueType);
            }

            return null;
        }
    }
}