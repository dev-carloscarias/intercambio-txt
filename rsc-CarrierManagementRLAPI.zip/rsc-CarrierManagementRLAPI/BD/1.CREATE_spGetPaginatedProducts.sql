-- DROP PROC spGetPaginatedProducts
GO
CREATE PROCEDURE spGetPaginatedProducts
(
	@offset INT,
	@limit INT
)
AS
BEGIN

	DECLARE @sql NVARCHAR(MAX)
	DECLARE @total INT;
	SET NOCOUNT ON
	SET @offset = ISNULL(@offset, 0);
	SET @limit = ISNULL(@limit, 500);
	
	SET @total = (SELECT COUNT(*) FROM [Products])	
    SET @sql = '
     WITH OrderedSet AS
    (
      SELECT *, ROW_NUMBER() OVER (ORDER BY ProductId) AS ''__index''
      FROM [dbo].[Products] 
    )
   SELECT *, ' + CAST(@total as NVARCHAR) + 'AS __total FROM OrderedSet WHERE [__index] > ' + CONVERT(NVARCHAR(12), @offset) + 
   ' AND [__index] <=' + CONVERT(NVARCHAR(12), (@offset + @limit)) 
   EXECUTE (@sql);

END