//---------------------------------------------------------------------------------------
// <copyright file="ICountryRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Country repository interface
    /// </summary>
    public interface ICountryRepository
    {
        /// <summary>
        /// Get TMS country catalog
        /// </summary>
        /// <returns>Country catalog</returns>
        Task<IQueryable<Country>> GetAll();

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        Country PopulateRecord(DbDataReader reader);
    }
}
