
//---------------------------------------------------------------------------------------
// <copyright file="CountryRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Country repository implementation
    /// </summary>
    public class CountryRepository : GenericRepository<Country>, ICountryRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CountryRepository" /> class
        /// </summary>
        /// <param name="connectionString">TMS connection string</param>
        public CountryRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get TMS country catalog
        /// </summary>
        /// <returns>Country catalog</returns>
        public async Task<IQueryable<Country>> GetAll()
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetTMSCountries;
                return await GetRecords(command);
            }
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        public override Country PopulateRecord(DbDataReader reader) => SqlReaderHelper.GetPopulateObject<Country>((SqlDataReader)reader);
    }
}
