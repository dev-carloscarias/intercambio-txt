﻿//---------------------------------------------------------------------------------------
// <copyright file="AuditTrailRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    #region Using

    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Diagnostics.CodeAnalysis;
    using System.Globalization;
    using System.Linq;
    using System.Threading.Tasks;
    using Common.Helpers;
    using Common.Repositories;

    #endregion Using

    /// <summary>
    /// Product repository class
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class AuditTrailRepository : GenericRepository<AuditTrail>, IAuditTrailRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="AuditTrailRepository" /> class
        /// </summary>
        /// <param name="connectionString"></param>
        public AuditTrailRepository(string connectionString) : base(connectionString)
        {
        }

        #endregion Constructor

        #region Get methods

        /// <summary>
        /// Get audit trail collection
        /// </summary>
        /// <returns>Audit trail collection</returns>
        public async Task<IQueryable<AuditTrail>> GetAll()
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = @"SELECT * FROM AuditTrail";
                return await this.GetRecords(command);
            }
        }

        /// <summary>
        /// Example for get specific record
        /// </summary>
        /// <param name="id">Record key</param>
        /// <returns>Audit trail data</returns>
        public async Task<AuditTrail> GetItem(string id)
        {
            // Parametirized queries
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = @"SELECT * FROM AuditTrail WHERE AuditTrailId = @id";
                command.Parameters.Add(new SqlParameter("@id", int.Parse(id, CultureInfo.InvariantCulture)));
                return await this.GetRecord(command);
            }
        }

        #endregion Get methods

        #region Modify methods

        /// <summary>
        /// Add audit trail log
        /// </summary>
        /// <param name="audit">Audit trail entity</param>
        /// <returns>Rows affected</returns>
        public async Task<int> Add(AuditTrail audit)
        {
            var affected = 0;
            var list = new List<AuditTrail>();
            list.Add(audit);
            var auditTrailRow = ListToDataTableConverter.ClassListToDataTable(list);

            var auditTrailParameter = new SqlParameter("@auditTrail", SqlDbType.Structured)
            {
                Value = auditTrailRow,
                TypeName = "dbo.AuditTrail"
            };

            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = @"AuditTrail_Insert_SP";
                command.Parameters.Add(auditTrailParameter);
                affected = await this.ExecuteCommand(command);
            }

            return affected;
        }

        #endregion Modify methods

        /// <summary>
        /// Populate audit trail
        /// </summary>
        /// <param name="reader">Represents a way of reading a forward-only stream of rows from a SQL Server database</param>
        /// <returns>Audit trail entity</returns>
        public override AuditTrail PopulateRecord(DbDataReader reader)
        {
            return SqlReaderHelper.GetPopulateObject<AuditTrail>(reader);
        }
    }
}