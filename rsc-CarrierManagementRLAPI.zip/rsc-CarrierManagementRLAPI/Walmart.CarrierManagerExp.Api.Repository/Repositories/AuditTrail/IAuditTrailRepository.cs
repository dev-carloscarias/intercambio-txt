﻿//---------------------------------------------------------------------------------------
// <copyright file="IAuditTrailRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    #region Using

    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    #endregion Using

    /// <summary>
    /// Audit trail repository interface
    /// </summary>
    public interface IAuditTrailRepository
    {
        /// <summary>
        /// Get Audit trail collection
        /// </summary>
        /// <returns>Audit trail collection</returns>
        Task<IQueryable<AuditTrail>> GetAll();

        /// <summary>
        ///  Add audit trail entity
        /// </summary>
        /// <param name="audit">Audit trail entity</param>
        /// <returns>Affected value</returns>
        Task<int> Add(AuditTrail audit);

        /// <summary>
        ///  Get specific record
        /// </summary>
        /// <param name="id">Audit trail key</param>
        /// <returns>Audit trail entity</returns>
        Task<AuditTrail> GetItem(string id);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Audit trail entity</returns>
        AuditTrail PopulateRecord(DbDataReader reader);

        /// <summary>
        /// Dispose class
  
    }
}