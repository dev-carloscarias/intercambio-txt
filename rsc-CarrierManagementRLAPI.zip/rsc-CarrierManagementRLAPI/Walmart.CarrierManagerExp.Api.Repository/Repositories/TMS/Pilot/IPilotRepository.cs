﻿//---------------------------------------------------------------------------------------
// <copyright file="IPilotRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Pilot repository
    /// </summary>
    public interface IPilotRepository
    {
        /// <summary>
        /// Get TMS Carrier pilot
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="code">Pilot code code</param>
        /// <param name="id">Pilot id</param>
        /// <param name="carrierId">Carrier id</param>
        /// <returns>TMS box car</returns>
        Task<IQueryable<Pilot>> Get(string carrierCode, string code, int? id, int? carrierId);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        Pilot PopulateRecord(DbDataReader reader);
    }
}
