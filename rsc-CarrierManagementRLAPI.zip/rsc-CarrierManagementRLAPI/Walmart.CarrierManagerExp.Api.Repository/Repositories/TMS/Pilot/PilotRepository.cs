﻿//---------------------------------------------------------------------------------------
// <copyright file="PilotRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Pilot repository implementation
    /// </summary>
    public class PilotRepository : GenericRepository<Pilot>, IPilotRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PilotRepository" /> class
        /// </summary>
        /// <param name="connectionString">TMS connection string</param>
        public PilotRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get TMS Carrier pilot
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="code">Pilot code code</param>
        /// <param name="id">Pilot id</param>
        /// <param name="carrierId">Carrier id</param>
        /// <returns>TMS box car</returns>
        public async Task<IQueryable<Pilot>> Get(string carrierCode, string code, int? id, int? carrierId)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetPilotbyCodesSP;
                command.Parameters.Add(new SqlParameter("@carrierCode", carrierCode));
                command.Parameters.Add(new SqlParameter("@code", code));
                command.Parameters.Add(new SqlParameter("@id", id));
                command.Parameters.Add(new SqlParameter("@carrierId", carrierId));
                return await GetRecords(command);
            }
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        public override Pilot PopulateRecord(DbDataReader reader) => SqlReaderHelper.GetPopulateObject<Pilot>((SqlDataReader)reader);
    }
}
