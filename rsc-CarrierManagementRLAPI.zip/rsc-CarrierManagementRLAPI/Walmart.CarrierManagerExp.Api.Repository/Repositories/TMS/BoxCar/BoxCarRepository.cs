﻿//---------------------------------------------------------------------------------------
// <copyright file="BoxCarRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Box car repository implementation
    /// </summary>
    public class BoxCarRepository : GenericRepository<BoxCar>, IBoxCarRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BoxCarRepository" /> class
        /// </summary>
        /// <param name="connectionString">TMS connection string</param>
        public BoxCarRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get TMS Carrier box car info
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="code">Box car code</param>
        /// <param name="id">Box car code</param>
        /// <returns>TMS box car</returns>
        public async Task<IQueryable<BoxCar>> Get(string carrierCode, string code, int? id)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetBoxCarByCodesSP;
                command.Parameters.Add(new SqlParameter("@carrierCode", carrierCode));
                command.Parameters.Add(new SqlParameter("@code", code));
                command.Parameters.Add(new SqlParameter("@Id", id));
                return await GetRecords(command);
            }
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        public override BoxCar PopulateRecord(DbDataReader reader) => SqlReaderHelper.GetPopulateObject<BoxCar>((SqlDataReader)reader);
    }
}
