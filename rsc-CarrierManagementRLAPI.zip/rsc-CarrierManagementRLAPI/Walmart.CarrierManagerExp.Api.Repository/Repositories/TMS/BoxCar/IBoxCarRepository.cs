﻿//---------------------------------------------------------------------------------------
// <copyright file="IBoxCarRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Box car repository
    /// </summary>
    public interface IBoxCarRepository
    {
        /// <summary>
        /// Get TMS Carrier box car info
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="code">Box car code</param>
        /// <param name="id">Box car id</param>
        /// <returns>TMS box car</returns>
        Task<IQueryable<BoxCar>> Get(string carrierCode, string code, int? id);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        BoxCar PopulateRecord(DbDataReader reader);
    }
}
