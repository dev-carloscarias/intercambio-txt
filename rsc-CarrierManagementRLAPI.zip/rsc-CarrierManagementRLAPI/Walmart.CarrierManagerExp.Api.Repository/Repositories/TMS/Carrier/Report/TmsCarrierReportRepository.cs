//---------------------------------------------------------------------------------------
// <copyright file="TmsCarrierReportRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Tms carrier report repository implementation
    /// </summary>
    public class TmsCarrierReportRepository : GenericRepository<TmsCarrierReport>, ITmsCarrierReportRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TmsCarrierReportRepository" /> class
        /// </summary>
        /// <param name="connectionString">Carrier connection string</param>
        public TmsCarrierReportRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get TMS carrier info using a long idneitfier array
        /// </summary>
        /// <param name="identifiers">All carrier management ids</param>
        /// <returns></returns>
        public async Task<IQueryable<TmsCarrierReport>> GetReportByIdentifiers(string identifiers)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetTMSCarrierReportSP;
                
                command.Parameters.Add(new SqlParameter("@identificador", identifiers));
                return await GetRecords(command);
            }
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier Document</returns>
        public override TmsCarrierReport PopulateRecord(DbDataReader reader) => SqlReaderHelper.GetPopulateObject<TmsCarrierReport>((SqlDataReader)reader);
    }
}
