//---------------------------------------------------------------------------------------
// <copyright file="IDocumentsRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// TMS carrier repository interface
    /// </summary>
    public interface ITmsCarrierReportRepository
    {
        
        /// <summary>
        /// Get TMS carrier info using a long idneitfier array
        /// </summary>
        /// <param name="identifiers">All carrier management ids</param>
        /// <returns></returns>
        Task<IQueryable<TmsCarrierReport>> GetReportByIdentifiers(string identifiers);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier Document</returns>
        TmsCarrierReport PopulateRecord(DbDataReader reader);

    }
}
