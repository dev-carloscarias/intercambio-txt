﻿//---------------------------------------------------------------------------------------
// <copyright file="ICarrierRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Collections.Generic;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Carrier repository interface
    /// </summary>
    public interface ICarrierRepository
    {
        /// <summary>
        /// Get TMS Carrier info using carrier code
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <returns>TMS Carrier entity entity</returns>
        Task<TmsCarrier> GetItem(string carrierCode);

        /// <summary>
        /// Get TMS Carrier info using email
        /// </summary>
        /// <param name="email">Carrier email</param>
        /// <returns>TMS Carrier entity entity</returns>
        Task<IQueryable<TmsCarrier>> GetByEmail(string email);

        /// <summary>
        /// Get TMS Carrier info using id
        /// </summary>
        /// <param name="id">Carrier id</param>
        /// <returns>TMS Carrier entity entity</returns>
        Task<TmsCarrier> GetByCarrierId(int id);

        /// <summary>
        /// Get TMS vehicule by code
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="filer">Filter name</param>
        /// <param name="filterCode">Filter code for searching</param>
        /// <returns>TMS Carrier entity entity</returns>
        Task<bool> ValidateCarriers(string carrierCode, string fiter, string filterCode);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>TMS Carrier entity entity</returns>
        TmsCarrier PopulateRecord(DbDataReader reader);
    }
}