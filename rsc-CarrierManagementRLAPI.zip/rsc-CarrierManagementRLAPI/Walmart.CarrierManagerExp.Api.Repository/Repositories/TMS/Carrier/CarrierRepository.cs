﻿//---------------------------------------------------------------------------------------
// <copyright file="CarrierRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Carrier repository implementation
    /// </summary>
    public class CarrierRepository : GenericRepository<TmsCarrier>, ICarrierRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CarrierRepository" /> class
        /// </summary>
        /// <param name="connectionString">TMS connection string</param>
        public CarrierRepository(string connectionString) : base(connectionString)
        {
        }

        // <summary>
        /// Get TMS Carrier info using carrier code
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <returns>TMS Carrier entity entity</returns>
        public async Task<TmsCarrier> GetItem(string carrierCode)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetCarrierByCodeSP;
                command.Parameters.Add(new SqlParameter("@Transportista_code", carrierCode));
                return await GetRecord(command);
            }
        }

        /// <summary>
        /// Get TMS Carrier info using id
        /// </summary>
        /// <param name="id">Carrier id</param>
        /// <returns>TMS Carrier entity entity</returns>
        public async Task<TmsCarrier> GetByCarrierId(int id)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetCarrierByIdSP;
                command.Parameters.Add(new SqlParameter("@CarrierId", id));
                return await GetRecord(command);
            }
        }

        /// <summary>
        /// Get TMS Carrier info using email
        /// </summary>
        /// <param name="email">Carrier email</param>
        /// <returns>TMS Carrier entity entity</returns>
        public async Task<IQueryable<TmsCarrier>> GetByEmail(string email)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetCarrierByEmail;
                command.Parameters.Add(new SqlParameter("@CMUser", email));
                return await ExecuteStoredProc(command);
            }
        }


        /// <summary>
        /// Get TMS vehicule by code
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="filer">Filter name</param>
        /// <param name="filterCode">Filter code for searching</param>
        /// <returns>TMS Carrier entity entity</returns>
        public async Task<bool> ValidateCarriers(string carrierCode, string fiter, string filterCode)
        {
            var affected = 0;
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.ValidateCarrierSP;
                command.Parameters.Add(new SqlParameter("@carrierCode", carrierCode));
                command.Parameters.Add(new SqlParameter("@code", filterCode));
                command.Parameters.Add(new SqlParameter("@filter", fiter));

                command.Parameters.Add("@result", System.Data.SqlDbType.Int).Direction = System.Data.ParameterDirection.ReturnValue;

                await this.ExecuteCommand(command);

                affected = (int)command.Parameters["@Result"].Value;
            }

            return Convert.ToBoolean(affected);
        }



        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>TMS Carrier entity entity</returns>
        public override TmsCarrier PopulateRecord(DbDataReader reader) => SqlReaderHelper.GetPopulateObject<TmsCarrier>((SqlDataReader)reader);
    }
}