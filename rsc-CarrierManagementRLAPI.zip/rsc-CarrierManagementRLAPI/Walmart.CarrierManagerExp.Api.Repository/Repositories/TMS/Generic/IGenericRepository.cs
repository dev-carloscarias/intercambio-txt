﻿//---------------------------------------------------------------------------------------
// <copyright file="IGenericRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
using System.Data.Common;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Walmart.CarrierManagerExp.Api.Repository
{
    /// <summary>
    /// Generic TMS Carrier info data for notifications and reports
    /// </summary>
    public interface IGenericRepository
    {
        /// <summary>
        /// Get TMS Carrier info identifier combine all carriers ids
        /// </summary>
        /// <param name="identifier">Carrier identidfier</param>
        /// <returns>TMS Carrier generic entity</returns>
        Task<GenericCarrier> GetItem(string identifier);

        /// <summary>
        /// Create carrier identifier using document
        /// </summary>
        /// <param name="document">Carrier document</param>
        /// <returns>A TMS identifier</returns>
        string GetIdentifier(CarrierDocument document);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        GenericCarrier PopulateRecord(DbDataReader reader);
    }
}
