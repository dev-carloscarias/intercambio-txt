//---------------------------------------------------------------------------------------
// <copyright file="GenericRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Generic repository implementation
    /// </summary>
    public class GenericRepository : GenericRepository<GenericCarrier>, IGenericRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GenericRepository" /> class
        /// </summary>
        /// <param name="connectionString">TMS connection string</param>
        public GenericRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get TMS Carrier info identifier combine all carriers ids
        /// </summary>
        /// <param name="identifier">Carrier identidfier</param>
        /// <returns>TMS Carrier generic entity</returns>
        public async Task<GenericCarrier> GetItem(string identifier)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetGenericCarrierSP;
                command.Parameters.Add(new SqlParameter("@identifier", identifier));
                return await GetRecord(command);
            }
        }

        /// <summary>
        /// Create carrier identifier using document
        /// </summary>
        /// <param name="document">Carrier document</param>
        /// <returns>A TMS identifier</returns>
        public string GetIdentifier(CarrierDocument document)
        {
            string values = string.Empty;

            if (document.CarrierIdV != 0 && document.CarrierIdV != null)
            {
                values = "V";
            }
            else if (document.CarrierIdF != 0 && document.CarrierIdF != null)
            {
                values = "F";
            }
            else if (document.CarrierIdP != 0 && document.CarrierIdP != null)
            {
                values = "P";
            }
            else
            {
                values = "T";
            }

            if (document.CarrierIdV == 0)
            {
                document.CarrierIdV = null;
            }

            if (document.CarrierIdF == 0)
            {
                document.CarrierIdF = null;
            }

            if (document.CarrierIdP == 0)
            {
                document.CarrierIdP = null;
            }

            var linkedIds = $"{document.CarrierId}{document.CarrierIdV ?? document.CarrierIdF ?? document.CarrierIdP}{values}";

            return linkedIds;
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        public override GenericCarrier PopulateRecord(DbDataReader reader) => SqlReaderHelper.GetPopulateObject<GenericCarrier>((SqlDataReader)reader);
    }
}