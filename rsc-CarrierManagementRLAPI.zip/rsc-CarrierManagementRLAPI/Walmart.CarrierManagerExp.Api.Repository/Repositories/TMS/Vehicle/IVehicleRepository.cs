﻿//---------------------------------------------------------------------------------------
// <copyright file="IVehicleRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Vehicle repository
    /// </summary>
    public interface IVehicleRepository
    {
        /// <summary>
        /// Get TMS Carrier vehicle
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="code">Pilot code code</param>
        /// <param name="id">Pilot id</param>
        /// <returns>TMS vehicle</returns>
        Task<IQueryable<Vehicle>> Get(string carrierCode, string code, int? id);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        Vehicle PopulateRecord(DbDataReader reader);
    }
}
