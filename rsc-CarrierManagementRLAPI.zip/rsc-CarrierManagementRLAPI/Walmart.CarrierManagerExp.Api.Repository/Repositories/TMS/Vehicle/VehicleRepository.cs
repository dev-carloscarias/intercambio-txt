﻿//---------------------------------------------------------------------------------------
// <copyright file="VehicleRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Vehicle repository implementation
    /// </summary>
    public class VehicleRepository : GenericRepository<Vehicle>, IVehicleRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="VehicleRepository" /> class
        /// </summary>
        /// <param name="connectionString">TMS connection string</param>
        public VehicleRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get TMS Carrier vehicle info
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="code">Vehicle code</param>
        /// <param name="id">Vehicle id</param>
        /// <returns>TMS Vehicle</returns>
        public async Task<IQueryable<Vehicle>> Get(string carrierCode, string code, int? id)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetVehicleByCodesSP;
                command.Parameters.Add(new SqlParameter("@carrierCode", carrierCode));
                command.Parameters.Add(new SqlParameter("@code", code));
                command.Parameters.Add(new SqlParameter("@id", id));
                return await GetRecords(command);
            }
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier generic data</returns>
        public override Vehicle PopulateRecord(DbDataReader reader) => SqlReaderHelper.GetPopulateObject<Vehicle>((SqlDataReader)reader);
    }
}
