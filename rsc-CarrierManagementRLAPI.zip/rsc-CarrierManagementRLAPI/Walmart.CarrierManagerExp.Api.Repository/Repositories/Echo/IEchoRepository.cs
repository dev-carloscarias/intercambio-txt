﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Walmart.CarrierManagerExp.Api.Repository
{
    public interface IEchoRepository
    {
        /// <summary>
        /// Gets a boolean indicating if we can connect to the database successfully.
        /// </summary>
        /// <returns>Audit trail collection</returns>
        Task<bool> IsConnectionSuccessful();
    }
}