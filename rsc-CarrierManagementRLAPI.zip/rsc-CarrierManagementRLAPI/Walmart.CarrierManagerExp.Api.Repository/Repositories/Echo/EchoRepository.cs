﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Api.Repository
{
    public class EchoRepository : GenericRepository<object>, IEchoRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="EchoRepository" /> class
        /// </summary>
        /// <param name="connectionString"></param>
        public EchoRepository(string connectionString) : base(connectionString)
        {
        }

        #endregion Constructor

        public async Task<bool> IsConnectionSuccessful()
        {
            return await base.TestConnection();
        }
    }
}