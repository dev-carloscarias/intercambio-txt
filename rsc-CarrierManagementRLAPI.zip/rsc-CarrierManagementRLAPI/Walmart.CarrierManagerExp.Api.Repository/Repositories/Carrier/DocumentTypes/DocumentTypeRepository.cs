﻿//---------------------------------------------------------------------------------------
// <copyright file="DocumentTypeRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Document type repository implementation
    /// </summary>
    public class DocumentTypeRepository : GenericRepository<DocumentType>, IDocumentTypeRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentTypeRepository" /> class
        /// </summary>
        /// <param name="connectionString">Carrier connection string</param>
        public DocumentTypeRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get document type by filter
        /// </summary>
        /// <param name="countryCode">Country code</param>
        /// <param name="applyTo">Apply to specific type</param>
        /// <param name="documentTypeId">Document type id</param>
        /// <returns>Document type collection</returns>
        public async Task<IQueryable<DocumentType>> GetItems(int countryCode, string applyTo, int documentTypeId)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetDocumentTypeSP;

                if (countryCode != 0)
                {
                    command.Parameters.Add(new SqlParameter("@CountryId", countryCode));
                }

                if (!string.IsNullOrEmpty(applyTo))
                {
                    command.Parameters.Add(new SqlParameter("@ApplyTo", applyTo));
                }

                if (documentTypeId != 0)
                {
                    command.Parameters.Add(new SqlParameter("@Id", documentTypeId));
                }

                return await GetRecords(command);
            }
        }

        /// <summary>
        /// Get document allowed days
        /// </summary>
        /// <param name="carrierId">Carrier id code</param>
        /// <param name="pilotId">Pilot id</param>
        /// <returns>Document type collection</returns>
        public async Task<DocumentType> GetIAllowedDays(int carrierId, int pilotId)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetDocumentAllowedDaysSP;

                command.Parameters.Add(new SqlParameter("@CarrierId", carrierId));
                command.Parameters.Add(new SqlParameter("@PilotId", pilotId));

                return await GetRecord(command);
            }
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Document type entity</returns>
        public override DocumentType PopulateRecord(DbDataReader reader)
        {
            var documentType = SqlReaderHelper.GetPopulateObject<DocumentType>((SqlDataReader)reader);
            documentType.ApplyToEntity = SqlReaderHelper.GetPopulateObject<DocumentTypeApply>((SqlDataReader)reader);

            return documentType;
        }
    }
}