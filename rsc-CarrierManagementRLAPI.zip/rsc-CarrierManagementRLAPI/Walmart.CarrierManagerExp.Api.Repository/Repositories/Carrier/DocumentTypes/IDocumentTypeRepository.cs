﻿//---------------------------------------------------------------------------------------
// <copyright file="IDocumentTypeRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Document type repository interface
    /// </summary>
    public interface IDocumentTypeRepository
    {
        /// <summary>
        /// Get document type by filter
        /// </summary>
        /// <param name="countryCode">Country code</param>
        /// <param name="applyTo">Apply to specific type</param>
        /// <param name="documentTypeId">Document type id</param>
        /// <returns>Document type collection</returns>
        Task<IQueryable<DocumentType>> GetItems(int countryCode, string applyTo, int documentTypeId);

        /// <summary>
        /// Get document allowed days
        /// </summary>
        /// <param name="carrierId">Carrier id code</param>
        /// <param name="pilotId">Pilot id</param>
        /// <returns>Document type collection</returns>
        Task<DocumentType> GetIAllowedDays(int carrierId, int pilotId);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Document type entity</returns>
        DocumentType PopulateRecord(DbDataReader reader);
    }
}