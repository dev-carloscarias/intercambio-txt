//---------------------------------------------------------------------------------------
// <copyright file="IDocumentTypeRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Document type apply repository implementation
    /// </summary>
    public interface IDocumentTypeApplyRepository
    {
        /// <summary>
        /// Get items using filters
        /// </summary>
        /// <param name="id">Record id</param>
        /// <param name="applyTo">Apply to</param>
        /// <param name="applyToEn">Apply to english</param>
        /// <param name="active">Indicates if records have to be active or not</param>
        /// <returns>Document type apply collection</returns>
        Task<IQueryable<DocumentTypeApply>> GetItems(int? id = null, string applyTo = "", string applyToEn = "", bool? active = null);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Document type entity</returns>
        DocumentTypeApply PopulateRecord(DbDataReader reader);
    }
}
