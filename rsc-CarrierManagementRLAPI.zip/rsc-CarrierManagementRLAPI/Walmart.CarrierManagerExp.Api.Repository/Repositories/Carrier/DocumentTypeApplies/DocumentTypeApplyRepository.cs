//---------------------------------------------------------------------------------------
// <copyright file="DocumentTypeApplyRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Document type apply repository implementation
    /// </summary>
    public class DocumentTypeApplyRepository : GenericRepository<DocumentTypeApply>, IDocumentTypeApplyRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentTypeApplyRepository" /> class
        /// </summary>
        /// <param name="connectionString">Carrier connection string</param>
        public DocumentTypeApplyRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get items using filters
        /// </summary>
        /// <param name="id">Record id</param>
        /// <param name="applyTo">Apply to</param>
        /// <param name="applyToEn">Apply to english</param>
        /// <param name="active">Indicates if records have to be active or not</param>
        /// <returns>Document type apply collection</returns>
        public async Task<IQueryable<DocumentTypeApply>> GetItems(int? id = null, string applyTo = "", string applyToEn = "", bool? active = null)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.CarrierTypeApplySP;

                if (id != null && id != 0)
                {
                    command.Parameters.Add(new SqlParameter("@Carrier_Doc_Type_Apply_Id", id.Value));
                }

                if (!string.IsNullOrEmpty(applyTo))
                {
                    command.Parameters.Add(new SqlParameter("@Carrier_Doc_Type_Apply_Name", applyTo));
                }

                if (!string.IsNullOrEmpty(applyToEn))
                {
                    command.Parameters.Add(new SqlParameter("@Carrier_Doc_Type_Apply_Name_En", applyToEn));
                }

                if (active != null)
                {
                    command.Parameters.Add(new SqlParameter("@Carrier_Doc_Type_Apply_Active", active));
                }

                return await GetRecords(command);
            }
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Document type entity</returns>
        public override DocumentTypeApply PopulateRecord(DbDataReader reader) => SqlReaderHelper.GetPopulateObject<DocumentTypeApply>(reader);
    }
}
