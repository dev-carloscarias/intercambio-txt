//---------------------------------------------------------------------------------------
// <copyright file="DocumentsRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Documents repository implementation
    /// </summary>
    public class DocumentsRepository : GenericRepository<CarrierDocument>, IDocumentsRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentsRepository" /> class
        /// </summary>
        /// <param name="connectionString">Carrier connection string</param>
        public DocumentsRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get document using filter
        /// </summary>
        /// <param name="Id">Document id</param>
        /// <param name="countryId">Country id</param>
        /// <param name="carrierId">TMS carrier id</param>
        /// <param name="documentTypeId">Document type id</param>
        /// <param name="documentTypeDescription">Document type description</param>
        /// <returns>Carrier Document</returns>
        public async Task<IQueryable<CarrierDocument>> GetItems(int id = 0, int countryId = 0, int carrierId = 0, int documentTypeId = 0, string documentTypeDescription = "")
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetDocumentSP;

                if (id != 0)
                {
                    command.Parameters.Add(new SqlParameter("@DocumentId", id));
                }

                if (countryId != 0)
                {
                    command.Parameters.Add(new SqlParameter("@CountryId", countryId));
                }

                if (carrierId != 0)
                {
                    command.Parameters.Add(new SqlParameter("@CarrierId", carrierId));
                }

                if (documentTypeId != 0)
                {
                    command.Parameters.Add(new SqlParameter("@DocumentTypeId", documentTypeId));
                }

                if (!string.IsNullOrEmpty(documentTypeDescription))
                {
                    command.Parameters.Add(new SqlParameter("@DocumentTypeDescription", documentTypeDescription));
                }

                return await GetRecords(command);
            }
        }

        /// <summary>
        ///  Add new document
        /// </summary>
        /// <param name="document">Document entity</param>
        /// <returns>Affected value</returns>
        public async Task<int> Add(CarrierDocument document)
        {
            var affected = 0;
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.InsertDocumentSP;
                command.Parameters.Add(new SqlParameter("@Carrierd_ID_Transportista", document.CarrierId));
                command.Parameters.Add(new SqlParameter("@Carrierd_Carrierdt_Id", document.DocumentTypeId));
                command.Parameters.Add(new SqlParameter("@Carrierd_ID_TransportistaV", document.CarrierIdV == null || document.CarrierIdV == 0 ? Convert.DBNull : document.CarrierIdV));
                command.Parameters.Add(new SqlParameter("@Carrierd_ID_TransportistaF", document.CarrierIdF == null || document.CarrierIdF == 0 ? Convert.DBNull : document.CarrierIdF));
                command.Parameters.Add(new SqlParameter("@Carrierd_ID_TransportistaP", document.CarrierIdP == null || document.CarrierIdP == 0 ? Convert.DBNull : document.CarrierIdP));
                command.Parameters.Add(new SqlParameter("@Carrierd_Expiration_Date", document.ExpirationDate));
                command.Parameters.Add(new SqlParameter("@Carrierd_Token_FileShare", document.TokenFileShare));
                command.Parameters.Add(new SqlParameter("@DocumentCreatorUser", document.ActionUser));
                command.Parameters.Add(new SqlParameter("@Carrierd_Email", document.CarrierDocumentEmail));
                command.Parameters.Add(new SqlParameter("@CountryId", document.CountryId));

                command.Parameters.Add("@result", System.Data.SqlDbType.Int).Direction = System.Data.ParameterDirection.ReturnValue;

                await this.ExecuteCommand(command);

                affected = (int)command.Parameters["@Result"].Value;
            }

            return affected;
        }


        /// <summary>
        /// Get docuemnt by id
        /// </summary>
        /// <param name="carrierId">Carrier id</param>
        /// <returns>TMS Carrier entity entity</returns>
        public async Task<CarrierDocument> GetById(int carrierId)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetDocumentSP;
                command.Parameters.Add(new SqlParameter("@DocumentId", carrierId));
                return await GetRecord(command);
            }
        }

        /// <summary>
        ///  Update carrier document
        /// </summary>
        /// <param name="document">Document entity</param>
        /// <returns>Affected value</returns>
        public async Task<int> Update(CarrierDocument document)
        {
            var affected = 0;
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.UpdateDocumentSP;
                command.Parameters.Add(new SqlParameter("@CarrierdId", document.CarrierDocumentId));
                command.Parameters.Add(new SqlParameter("@ExpirationDate", document.ExpirationDate));
                command.Parameters.Add(new SqlParameter("@TokenFileShare", document.TokenFileShare));
                command.Parameters.Add(new SqlParameter("@DocumentLastUserUpdate", document.ActionUser));
                command.Parameters.Add(new SqlParameter("@CountryId", document.CountryId));
                command.Parameters.Add(new SqlParameter("@DocumentTypeId", document.DocumentTypeId));
                
                command.Parameters.Add("@result", System.Data.SqlDbType.Int).Direction = System.Data.ParameterDirection.ReturnValue;

                affected = await ExecuteCommand(command);
            }

            return affected;
        }

        /// <summary>
        /// Get document using token file share
        /// </summary>
        /// <param name="toke">File Sftp token</param>
        /// <returns>Carrier Document</returns>
        public async Task<CarrierDocument> GetByTokenFileShare(string token)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.GetDocumentSP;

                command.Parameters.Add(new SqlParameter("@TokenFileShare", token));
                
                return await GetRecord(command);
            }
        }

        /// <summary>
        ///  Send updoad new document 
        /// </summary>
        /// <param name="document">Document entity</param>
        /// <param name="genericCarrier">Generic carrier entity</param>
        /// <returns>Affected value</returns>
        public void SendNotifications(CarrierDocument document, GenericCarrier genericCarrier)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.SendNotificationsSP;

                command.Parameters.Add(new SqlParameter("@CarrierdtId", document.DocumentTypeId));
                command.Parameters.Add(new SqlParameter("@CarrierName", genericCarrier.CarrierName));
                command.Parameters.Add(new SqlParameter("@CarrierCode", genericCarrier.CarrierCode));
                command.Parameters.Add(new SqlParameter("@CarrierEmail", document.CarrierDocumentEmail));
                command.Parameters.Add(new SqlParameter("@Code", genericCarrier.Code));
                command.Parameters.Add(new SqlParameter("@Description", genericCarrier.Description));

                _ = this.ExecuteCommand(command).Result;
            }
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier Document</returns>
        public override CarrierDocument PopulateRecord(DbDataReader reader)
        {
            var document = SqlReaderHelper.GetPopulateObject<CarrierDocument>(reader);

            return document;
        }
    }
}