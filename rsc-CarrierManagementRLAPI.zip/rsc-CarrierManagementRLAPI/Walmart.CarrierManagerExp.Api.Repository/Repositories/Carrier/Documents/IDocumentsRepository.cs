//---------------------------------------------------------------------------------------
// <copyright file="IDocumentsRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Documents repository interface
    /// </summary>
    public interface IDocumentsRepository
    {
        /// <summary>
        /// Get document using filter
        /// </summary>
        /// <param name="Id">Document id</param>
        /// <param name="countryId">Country id</param>
        /// <param name="carrierId">TMS carrier id</param>
        /// <param name="documentTypeId">Document type id</param>
        /// <param name="documentTypeDescription">Document type description</param>
        /// <returns>Carrier Document</returns>
        Task<IQueryable<CarrierDocument>> GetItems(int id = 0, int countryId = 0, int carrierId = 0, int documentTypeId = 0, string documentTypeDescription = "");

        /// <summary>
        /// Get document using token file share
        /// </summary>
        /// <param name="toke">File Sftp token</param>
        /// <returns>Carrier Document</returns>
        Task<CarrierDocument> GetByTokenFileShare(string token);

        /// <summary>
        ///  Add new document
        /// </summary>
        /// <param name="document">Document entity</param>
        /// <returns>Affected value</returns>
        Task<int> Add(CarrierDocument document);

        /// <summary>
        ///  Update carrier document
        /// </summary>
        /// <param name="document">Document entity</param>
        /// <returns>Affected value</returns>
        Task<int> Update(CarrierDocument document);

        /// <summary>
        /// Get TMS Carrier info using id
        /// </summary>
        /// <param name="carrierId">Carrier id</param>
        /// <returns>TMS Carrier entity entity</returns>
        Task<CarrierDocument> GetById(int carrierId);

        /// <summary>
        ///  Send updoad new document 
        /// </summary>
        /// <param name="document">Document entity</param>
        /// <param name="genericCarrier">Generic carrier entity</param>
        void SendNotifications(CarrierDocument document, GenericCarrier genericCarrier);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier Document</returns>
        CarrierDocument PopulateRecord(DbDataReader reader);
    }
}