//---------------------------------------------------------------------------------------
// <copyright file="IReportRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>
    /// Report repository interface
    /// </summary>
    public interface IReportRepository
    {
        /// <summary>
        /// Get report result using filters
        /// </summary>
        /// <param name="carrierId">Carrier id</param>
        /// <param name="carrierIdF">Carrier box car id</param>
        /// <param name="carrierIdV">Carrier vehicle id</param>
        /// <param name="carrierIdP">Carrier pilot id</param>
        /// <param name="applyFor">Apply for specific document</param>
        /// <returns>A carrier report response</returns>
        Task<IQueryable<ReportResponse>> GetReport(int carrierId, int? documentType = null, int? carrierIdF = null, int? carrierIdV = null, int? carrierIdP = null, string applyFor = " ");

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier Document</returns>
        ReportResponse PopulateRecord(DbDataReader reader);
    }
}