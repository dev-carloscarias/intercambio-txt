//---------------------------------------------------------------------------------------
// <copyright file="ReportRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    using Walmart.Common.Helpers;
    using Walmart.Common.Repositories;

    /// <summary>
    /// Report repository implementation
    /// </summary>
    public class ReportRepository : GenericRepository<ReportResponse>, IReportRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReportRepository" /> class
        /// </summary>
        /// <param name="connectionString">Carrier connection string</param>
        public ReportRepository(string connectionString) : base(connectionString)
        {
        }

        /// <summary>
        /// Get report result using filters
        /// </summary>
        /// <param name="carrierId">Carrier id</param>
        /// <param name="documentType">Docuemnt type id</param>
        /// <param name="carrierIdF">Carrier box car id</param>
        /// <param name="carrierIdV">Carrier vehicle id</param>
        /// <param name="carrierIdP">Carrier pilot id</param>
        /// <param name="applyFor">Apply for specific document</param>
        /// <returns>A carrier report response</returns>
        public async Task<IQueryable<ReportResponse>> GetReport(int carrierId, int? documentType = null, int? carrierIdF = null, int? carrierIdV = null, int? carrierIdP = null, string applyFor = " ")
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = ConstantsHelper.CarrierReportSP;

                command.Parameters.Add(new SqlParameter("@Carrierd_ID_Transportista", carrierId));

                command.Parameters.Add(new SqlParameter("@Carrierdt_Id", documentType));

                command.Parameters.Add(new SqlParameter("@Carrierd_ID_TransportistaF", carrierIdF));

                command.Parameters.Add(new SqlParameter("@Carrierd_ID_TransportistaV", carrierIdV));

                command.Parameters.Add(new SqlParameter("@Carrierd_ID_TransportistaP", carrierIdP));

                command.Parameters.Add(new SqlParameter("@Carrierdt_Apply", applyFor));

                return await GetRecords(command);
            }
        }

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Carrier Document</returns>
        public override ReportResponse PopulateRecord(DbDataReader reader) => SqlReaderHelper.GetPopulateObject<ReportResponse>((SqlDataReader)reader);
    }
}