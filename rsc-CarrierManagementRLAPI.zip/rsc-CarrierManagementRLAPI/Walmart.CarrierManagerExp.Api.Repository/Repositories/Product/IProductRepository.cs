﻿//---------------------------------------------------------------------------------------
// <copyright file="IProductRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    #region Using

    using System.Collections.ObjectModel;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;

    #endregion Using

    /// <summary>
    /// Product repository interface
    /// </summary>
    public interface IProductRepository
    {
        /// <summary>
        /// Example for get all records
        /// </summary>
        /// <returns>Product collection</returns>
        Task<IQueryable<Product>> GetAll();

        /// <summary>
        /// Example to get paginated records from a Stored Procedure
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="limit"></param>
        /// <returns></returns>
        Task<(int total, IQueryable<Product> result)> GetPaginatedRecords(int offset, int limit);

        /// <summary>
        /// Example to get paginated records from a simple select query
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="limit"></param>
        /// <returns></returns>
        Task<(int total, IQueryable<Product> result)> GetPaged(int offset, int limit);

        /// <summary>
        ///  Example for add specific record
        /// </summary>
        /// <param name="product">Product entity</param>
        /// <returns>Affected value</returns>
        Task<int> Add(Product product);

        /// <summary>
        ///  Example for delete specific record
        /// </summary>
        /// <param name="id">Product key</param>
        /// <returns>Affected value</returns>
        Task<int> Delete(string id);

        /// <summary>
        ///  Example for get specific record
        /// </summary>
        /// <param name="id">Product key</param>
        /// <returns>Product entity</returns>
        Task<Product> GetItem(string id);

        /// <summary>
        /// Populate record
        /// </summary>
        /// <param name="reader">Data reader</param>
        /// <returns>Product entity</returns>
        Product PopulateRecord(DbDataReader reader);

        /// <summary>
        ///  Example for update specific record
        /// </summary>
        /// <param name="product">Product entity</param>
        /// <returns>Affected value</returns>
        Task<int> Update(Product product);

        /// <summary>
        ///  Example for update collection record
        /// </summary>
        /// <param name="products">Product entity</param>
        /// <returns>Affected value</returns>
        Task<int> UpdateProducts(Collection<Product> products);

      
    }
}