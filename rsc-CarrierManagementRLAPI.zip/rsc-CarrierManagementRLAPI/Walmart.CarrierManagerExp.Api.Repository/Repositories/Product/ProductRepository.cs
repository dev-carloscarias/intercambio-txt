﻿//---------------------------------------------------------------------------------------
// <copyright file="ProductRepository.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    #region Using

    using System.Collections.ObjectModel;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Diagnostics.CodeAnalysis;
    using System.Globalization;
    using System.Linq;
    using System.Threading.Tasks;
    using Common.Helpers;
    using Common.Repositories;

    #endregion Using

    /// <summary>
    /// Product repository class
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class ProductRepository : GenericRepository<Product>, IProductRepository
    {
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductRepository" /> class
        /// </summary>
        /// <param name="connectionString"></param>
        public ProductRepository(string connectionString) : base(connectionString)
        {
        }

        #endregion Constructor

        #region Get methods

        /// <summary>
        /// Example for get all records
        /// </summary>
        /// <returns>Products collection</returns>
        public async Task<IQueryable<Product>> GetAll()
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = @"SELECT * FROM Products";
                return await this.GetRecords(command);
            }
        }

        /// <summary>
        /// Example for get all records paged for SQLServer-2016+
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="limit"></param>
        /// <returns></returns>
        public async Task<(int total, IQueryable<Product> result)> GetPaged(int offset, int limit)
        {
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = $"SELECT *, __total = COUNT(*) OVER() FROM Products ORDER BY ProductId OFFSET {offset} ROWS FETCH NEXT {limit} ROWS ONLY;";
                return await this.GetPagedRecords(command);
            }
        }

        /// <summary>
        /// Example for function use for product entity.
        /// Get paginated records
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="limit"></param>
        /// <returns></returns>
        public async Task<(int total, IQueryable<Product> result)> GetPaginatedRecords(int offset, int limit)
        {
            using (var command = new SqlCommand())
            {
                command.CommandText = "dbo.spGetPaginatedProducts";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@offset", offset));
                command.Parameters.Add(new SqlParameter("@limit", limit));
                return await this.GetPagedRecords(command);
            }
        }

        /// <summary>
        /// Example for get specific record
        /// </summary>
        /// <param name="id">Record key</param>
        /// <returns>Product data</returns>
        public async Task<Product> GetItem(string id)
        {
            // Parametirized queries
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = @"SELECT * FROM Products WHERE ProductId = @id";
                command.Parameters.Add(new SqlParameter("@id", int.Parse(id, CultureInfo.InvariantCulture)));
                return await this.GetRecord(command);
            }
        }

        #endregion Get methods

        #region Modify methods

        /// <summary>
        /// Example for add product
        /// </summary>
        /// <param name="product">Entity product</param>
        /// <returns>Rows affected</returns>
        public async Task<int> Add(Product product)
        {
            var affected = 0;
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = @"dbo.spInsertProduct";
                command.Parameters.Add(new SqlParameter("@id", product.ProductId));
                command.Parameters.Add(new SqlParameter("@productName", product.ProductName));

                affected = await this.ExecuteCommand(command);
            }

            return affected;
        }

        /// <summary>
        /// Example for update product
        /// </summary>
        /// <param name="product">Entity product for update</param>
        /// <returns>Rows affected</returns>
        public async Task<int> Update(Product product)
        {
            var affected = 0;
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = @"dbo.spUpdateProduct";
                command.Parameters.Add(new SqlParameter("@id", product.ProductId));
                affected = await this.ExecuteCommand(command);
            }

            return affected;
        }

        /// <summary>
        /// Example for delete product
        /// </summary>
        /// <param name="id">Product key</param>
        /// <returns>Rows affected</returns>
        public async Task<int> Delete(string id)
        {
            var affected = 0;
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = @"dbo.spDeleteProduct";
                command.Parameters.Add(new SqlParameter("@id", id));
                affected = await this.ExecuteCommand(command);
            }

            return affected;
        }

        /// <summary>
        /// Update batch product
        /// </summary>
        /// <param name="products">Batch type product update</param>
        /// <returns>Rows affected</returns>
        public async Task<int> UpdateProducts(Collection<Product> products)
        {
            var affected = 0;
            var productRow = ListToDataTableConverter.ClassListToDataTable(products);

            var transactionTypeParameter = new SqlParameter("@updateCollectionProduct", SqlDbType.Structured)
            {
                Value = productRow,
                TypeName = "dbo.Products"
            };
            using (var command = new SqlCommand())
            {
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = @"spUpdateCollectionProduct";
                command.Parameters.Add(transactionTypeParameter);
                affected = await this.ExecuteCommand(command);
            }

            return affected;
        }

        #endregion Modify methods

        /// <summary>
        /// Populate entity Example
        /// </summary>
        /// <param name="reader">Represents a way of reading a forward-only stream of rows from a SQL Server database</param>
        /// <returns>Entity example product</returns>
        public override Product PopulateRecord(DbDataReader reader)
        {
            return SqlReaderHelper.GetPopulateObject<Product>((SqlDataReader)reader);
        }
    }
}