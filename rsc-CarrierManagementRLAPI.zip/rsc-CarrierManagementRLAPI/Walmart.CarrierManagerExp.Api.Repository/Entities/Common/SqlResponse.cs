﻿//-----------------------------------------------------------------------
// <copyright file="SqlResponse.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//-----------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    /// <summary>
    /// Sql response with extra if exists, data like error messages or procedures response.
    /// </summary>
    public class SqlResponse
    {
        /// <summary>
        /// Gets or sets a value indicating whether errors has occured
        /// </summary>
        public bool? Error { get; set; }

        /// <summary>
        /// Store procedure int response, like 1 if ist all ok, or 0 if not
        /// </summary>
        public int? ProcedureIntResponse { get; set; }

        /// <summary>
        /// Error message
        /// </summary>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Object procedure response like sql sentence, datasets.
        /// </summary>
        public object ObjReponse { get; set; }

    }
}
