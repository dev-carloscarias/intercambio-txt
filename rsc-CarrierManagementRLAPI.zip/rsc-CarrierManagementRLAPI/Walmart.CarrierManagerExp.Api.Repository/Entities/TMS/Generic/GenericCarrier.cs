﻿//---------------------------------------------------------------------------------------
// <copyright file="GenericCarrier.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.ComponentModel;

    /// <summary>
    /// Vehicule entity
    /// </summary>
    public class GenericCarrier
    {
        /// <summary>
        /// Gets or sets Vehicule id
        /// </summary>
        public string Identifier { get; set; }

        /// <summary>
        /// Gets or sets vehicule code
        /// </summary>
        public string CarrierCode { get; set; }

        /// <summary>
        /// Gets or sets carrier name
        /// </summary>
        public string CarrierName { get; set; }

        /// <summary>
        /// Gets or sets code
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets decription
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets carrier email
        /// </summary>
        public string CarrierEmail { get; set; }
        
    }
}
