﻿//---------------------------------------------------------------------------------------
// <copyright file="TmsCarrier.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.ComponentModel;

    /// <summary>
    /// Tms carrier information entity
    /// </summary>
    public class TmsCarrier
    {
        /// <summary>
        /// Gets or sets carrier id
        /// </summary>
        [DisplayName("Id_Transportista")]
        public int? CarrierId { get; set; }

        /// <summary>
        /// Gets or sets country id
        /// </summary>
        [DisplayName("Fk_Pais")]
        public int? CountryId { get; set; }

        /// <summary>
        /// Gets or sets carrier code
        /// </summary>
        [DisplayName("Transportista_code")]
        public string CarrierCode { get; set; }

        /// <summary>
        /// Gets or sets carrier name
        /// </summary>
        [DisplayName("Nombre_nm")]
        public string CarrierName { get; set; }

        /// <summary>
        /// Gets or sets carrier owner name
        /// </summary>
        [DisplayName("Nombre_Propietario_nm")]
        public string CarrierOwnerName { get; set; }

        /// <summary>
        /// Gets or sets carrier owner DNI
        /// </summary>
        [DisplayName("Cedula_Propietario_nbr")]
        public string CarrierOwnerCode { get; set; }

        /// <summary>
        /// Gets or sets contract date
        /// </summary>
        [DisplayName("Fecha_Contrato_dt")]
        public DateTime? ContractDate { get; set; }

        /// <summary>
        /// Gets or sets carrier email
        /// </summary>
        [DisplayName("Email_txt")]
        public string CarrierEmail { get; set; }

        /// <summary>
        /// Gets or sets carrier state
        /// </summary>
        [DisplayName("Estado_ind")]
        public string CarrierState { get; set; }

        /// <summary>
        /// Gets or sets business name
        /// </summary>
        [DisplayName("Razon_Social")]
        public string BusinessName { get; set; }
    }
}