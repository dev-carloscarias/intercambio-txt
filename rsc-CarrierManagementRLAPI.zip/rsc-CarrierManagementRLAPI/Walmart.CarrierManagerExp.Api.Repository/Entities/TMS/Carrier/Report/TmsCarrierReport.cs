//---------------------------------------------------------------------------------------
// <copyright file="TmsCarrierReport.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
using System.ComponentModel;

namespace Walmart.CarrierManagerExp.Api.Repository
{
    /// <summary>
    /// TMS carrier report response
    /// </summary>
    public class TmsCarrierReport
    {
        /// <summary>
        /// Gets or sets identifier
        /// </summary>
        [DisplayName("identificador")]
        public string Identifier { get; set; }

        /// <summary>
        /// Gets or sets code
        /// </summary>
        [DisplayName("codigo")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets description
        /// </summary>
        [DisplayName("descripcion")]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets country name
        /// </summary>
        [DisplayName("Pais_nm")]
        public string CountryName { get; set; }

        /// <summary>
        /// Gets or sets carrier name
        /// </summary>
        [DisplayName("Nombre_nm")]
        public string Name { get; set; }
    }
}
