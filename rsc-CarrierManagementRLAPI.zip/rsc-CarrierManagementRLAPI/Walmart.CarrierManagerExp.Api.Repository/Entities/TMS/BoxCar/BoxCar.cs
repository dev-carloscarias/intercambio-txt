﻿//---------------------------------------------------------------------------------------
// <copyright file="BoxCar.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.ComponentModel;

    /// <summary>
    /// Box car entity
    /// </summary>
    public class BoxCar
    {
        /// <summary>
        /// Gets or sets box car id
        /// </summary>
        [DisplayName("ID_Furgon")]
        public int BoxCarId { get; set; }

        /// <summary>
        /// Gets or sets box card code
        /// </summary>
        [DisplayName("Furgon_code")]
        public string BoxCarCode { get; set; }

        /// <summary>
        /// Gets or sets box card decription
        /// </summary>
        [DisplayName("Descripcion_desc")]
        public string BoxCarDescription { get; set; }

        /// <summary>
        /// Gets or sets box cat plate number
        /// </summary>
        [DisplayName("Placa_txt")]
        public string BoxCarPlateNumber { get; set; }

        /// <summary>
        /// Gets or sets if bo car is active or not
        /// </summary>
        [DisplayName("Tipo_txt")]
        public string Active { get; set; }

    }
}
