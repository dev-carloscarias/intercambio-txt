﻿//---------------------------------------------------------------------------------------
// <copyright file="TmsCarrier.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.ComponentModel;

    /// <summary>
    /// Vehicle entity
    /// </summary>
    public class Vehicle
    {
        /// <summary>
        /// Gets or sets vehicle id
        /// </summary>
        [DisplayName("ID_Vehiculo")]
        public int VehicleId { get; set; }

        /// <summary>
        /// Gets or sets vehicle code
        /// </summary>
        [DisplayName("Vehiculo_code")]
        public string VehicleCode { get; set; }

        /// <summary>
        /// Gets or sets licence plate
        /// </summary>
        [DisplayName("Placa_txt")]
        public string LicencePlate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether vehicle is active
        /// </summary>
        [DisplayName("Estado_ind")]
        public bool Active { get; set; }
    }
}
