﻿//---------------------------------------------------------------------------------------
// <copyright file="Pilot.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.ComponentModel;

    /// <summary>
    /// Pilot entity
    /// </summary>
    public class Pilot
    {
        /// <summary>
        /// Gets or sets pilot id
        /// </summary>
        [DisplayName("ID_Piloto")]
        public int PilotId { get; set; }

        /// <summary>
        /// Gets or sets pilot code
        /// </summary>
        [DisplayName("Piloto_code")]
        public string PilotCode { get; set; }

        /// <summary>
        /// Gets or sets pilot name
        /// </summary>
        [DisplayName("Nombre_nm")]
        public string PilotName { get; set; }

        /// <summary>
        /// Gets or sets if pilot idf active or not
        /// </summary>
        [DisplayName("Estado_txt")]
        public string Active { get; set; }
    }
}
