//-----------------------------------------------------------------------
// <copyright file="Product.cs" company="Walmart M�xico y Centroam�rica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Ag�ero Fallas</author>
//-----------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    #region Using

    using System;
    using System.Diagnostics.CodeAnalysis;

    #endregion Using

    /// <summary>
    /// Product data entity
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Product
    {
        /// <summary>
        /// Gets or sets product key
        /// </summary>
        public int ProductId { get; set; }

        /// <summary>
        /// Gets or sets order key
        /// </summary>
        public int OrderId { get; set; }

        /// <summary>
        /// Gets or sets order date
        /// </summary>
        public DateTime OrderDate { get; set; }

        /// <summary>
        /// Gets or sets order priority
        /// </summary>
        public string OrderPriority { get; set; }

        /// <summary>
        /// Gets or sets sales property
        /// </summary>
        public decimal Sales { get; set; }

        /// <summary>
        /// Gets or sets discount property
        /// </summary>
        public decimal Discount { get; set; }

        /// <summary>
        /// Gets or sets ship mode property
        /// </summary>
        public string ShipMode { get; set; }

        /// <summary>
        /// Gets or sets profit property
        /// </summary>
        public decimal Profit { get; set; }

        /// <summary>
        /// Gets or sets product price
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// Gets or sets shipping cost
        /// </summary>
        public decimal ShippingCost { get; set; }

        /// <summary>
        /// Gets or sets customer name
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets province property
        /// </summary>
        public string Province { get; set; }

        /// <summary>
        /// Gets or sets region property
        /// </summary>
        public string Region { get; set; }

        /// <summary>
        /// Gets or sets customer segment
        /// </summary>
        public string CustomerSegment { get; set; }

        /// <summary>
        /// Gets or sets product category
        /// </summary>
        public string ProductCategory { get; set; }

        /// <summary>
        /// Gets or sets product sub category
        /// </summary>
        public string ProductsubCategory { get; set; }

        /// <summary>
        /// Gets or sets product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets product container
        /// </summary>
        public string ProductContainer { get; set; }

        /// <summary>
        /// Gets or sets product base margin
        /// </summary>
        public decimal ProductBaseMargin { get; set; }

        /// <summary>
        /// Gets or sets shipping date
        /// </summary>
        public DateTime ShipDate { get; set; }
    }
}