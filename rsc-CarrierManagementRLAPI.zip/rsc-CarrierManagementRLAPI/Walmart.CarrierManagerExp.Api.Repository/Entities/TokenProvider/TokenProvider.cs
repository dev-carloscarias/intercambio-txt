//-----------------------------------------------------------------------    
// <copyright file="TokenProvider.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Julio Barquero Valerio</author>    
//----------------------------------------------------------------------- 
namespace Walmart.CarrierManagerExp.Api.Repository
{
    #region Using
    using System;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Diagnostics.CodeAnalysis;
    using Newtonsoft.Json;
    #endregion

    /// <summary>
    /// Product data entity
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class TokenProvider
    {
        /// <summary>
        /// Gets or sets AccessToken
        /// </summary>
        [Key]
        public string AccessToken { get; set; }

        /// <summary>
        /// Gets or sets ExpiresIn
        /// </summary>
        [JsonProperty("LifeTime")]
        public long ExpiresIn { get; set; }

    }
}