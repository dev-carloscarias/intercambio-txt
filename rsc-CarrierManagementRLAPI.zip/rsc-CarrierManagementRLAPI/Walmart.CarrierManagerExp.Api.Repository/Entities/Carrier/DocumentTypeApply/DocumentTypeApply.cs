
//---------------------------------------------------------------------------------------
// <copyright file="DocumentTypeDocumentTypeApplycs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.ComponentModel;

    /// <summary>
    /// Document type apply entity
    /// </summary>
    public class DocumentTypeApply
    {
        /// <summary>
        /// Gets or sets document type apply id
        /// </summary>
        [DisplayName("Carrier_Doc_Type_Apply_Id")]
        public int DocumentTypeApplyId { get; set; }

        /// <summary>
        /// Gets or sets document type apply name
        /// </summary>
        [DisplayName("Carrier_Doc_Type_Apply_Name")]
        public string DocumentTypeApplyName { get; set; }

        /// <summary>
        /// Gets or sets document type name in english
        /// </summary>
        [DisplayName("Carrier_Doc_Type_Apply_Name_En")]
        public string DocumentTypeApplyNameEn { get; set; }

        /// <summary>
        /// Gets or sets a vulue indicationg whether record is or not active
        /// </summary>
        [DisplayName("Carrier_Doc_Type_Apply_Active")]
        public bool Active { get; set; }
    }
}
