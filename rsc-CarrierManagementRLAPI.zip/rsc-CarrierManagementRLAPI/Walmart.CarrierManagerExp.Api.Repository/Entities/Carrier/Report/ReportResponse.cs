//---------------------------------------------------------------------------------------
// <copyright file="ReportResponse.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.ComponentModel;

    /// <summary>
    /// Carrier report response
    /// </summary>
    public class ReportResponse : TmsCarrierReport
    {
        /// <summary>
        /// Gets or sets carrier identifier
        /// </summary>
        [DisplayName("identificador")]
        public string CarrierIdentifier { get; set; }

        /// <summary>
        /// Gets or sets docuemnt type description
        /// </summary>
        [DisplayName("Carrierdt_Description")]
        public string DocumentTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets expiration date
        /// </summary>
        [DisplayName("Carrierd_Expiration_Date")]
        public DateTime ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets carrier id
        /// </summary>
        [DisplayName("Carrierd_ID_Transportista")]
        public int CarrierId { get; set; }
    }
}
