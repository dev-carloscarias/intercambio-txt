//---------------------------------------------------------------------------------------
// <copyright file="ReportRequest.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{ 
    /// <summary>
    /// Request report data
    /// </summary>
    public class ReportRequest
    {
        /// <summary>
        /// Gets or sets carrier id
        /// </summary>
        public int CarrrierId { get; set; }

        /// <summary>
        /// Gets or sets carrier box car
        /// </summary>
        public int? CarrierIdF { get; set; }

        /// <summary>
        /// Gets or sets carrier vehicle
        /// </summary>
        public int? CarrierIdV { get; set; }

        /// <summary>
        /// Gets or sets carrier pilot
        /// </summary>
        public int? CarrierIdP { get; set; }

        /// <summary>
        /// Gets or sets apply for filter
        /// </summary>
        public string ApplyFor { get; set; }
    }
}