
//---------------------------------------------------------------------------------------
// <copyright file="TmsCarrier.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.ComponentModel;
    using Microsoft.AspNetCore.Http;
    using Newtonsoft.Json;

    /// <summary>
    /// Document entity
    /// </summary>
    public class CarrierDocument : DocumentType
    {
        /// <summary>
        /// Gets or sets carrier document id
        /// </summary>
        [DisplayName("Carrierd_ID")]
        public int? CarrierDocumentId { get; set; }

        /// <summary>
        /// Gets or sets carrier id
        /// </summary>
        [DisplayName("Carrierd_ID_Transportista")]
        public int? CarrierId { get; set; }

        /// <summary>
        /// Gets or sets document type id
        /// </summary>
        [DisplayName("Carrierd_Carrierdt_Id")]
        public new int? DocumentTypeId { get; set; }

        /// <summary>
        /// Gets or sets carrier id use vehicule
        /// </summary>
        [DisplayName("Carrierd_ID_TransportistaV")]
        public int? CarrierIdV { get; set; }

        /// <summary>
        /// Gets or sets carrier id using trailer
        /// </summary>
        [DisplayName("Carrierd_ID_TransportistaF")]
        public int? CarrierIdF { get; set; }

        /// <summary>
        /// Gets or sets carrier id using pilot
        /// </summary>
        [DisplayName("Carrierd_ID_TransportistaP")]
        public int? CarrierIdP { get; set; }

        /// <summary>
        /// Gets or sets expiration date
        /// </summary>
        [DisplayName("Carrierd_Expiration_Date")]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets notification date
        /// </summary>
        [DisplayName("Carrierd_Notification_Date")]
        public DateTime? NotificationDate { get; set; }

        /// <summary>
        /// Gets or sets file share token
        /// </summary>
        [DisplayName("Carrierd_Token_FileShare")]
        public string TokenFileShare { get; set; }

        /// <summary>
        /// Gets or sets a value indicating a value whether document is active or not
        /// </summary>
        [DisplayName("Carrierd_Active")]
        public new bool? Active { get; set; }

        /// <summary>
        /// Gets or sets carrier document email
        /// </summary>
        [DisplayName("Carrierd_Email")]
        public string CarrierDocumentEmail { get; set; }

        /// <summary>
        /// Gets or sets creation date
        /// </summary>
        [DisplayName("Carrierd_Creation_Date")]
        public DateTime? CreationDate { get; set; }

        /// <summary>
        /// Gets or sets file byte array
        /// </summary>
        public IFormFile File { get; set; }

        /// <summary>
        /// Gets or sets user how save or update data
        /// </summary>
        public string ActionUser { get; set; }

        /// <summary>
        /// Gets literal acive 
        /// </summary>
        public string LiteralActive { get; set; }

        /// <summary>
        /// Gets or sets literal carrier
        /// </summary>
        public string LiteralCarrier { get; set; }

        /// <summary>
        /// Gets or sets literal transports
        /// </summary>
        public string LiteralTransports { get; set; }

        /// <summary>
        /// Gets or sets literal unit and box car
        /// </summary>
        public string LiteralUnitBoxCar{ get; set; }

        /// <summary>
        /// Gets or sets literal unit
        /// </summary>
        public string LiteralUnit { get; set; }

        /// <summary>
        /// Gets or sets literal box car
        /// </summary>
        public string LiteralBoxCar { get; set; }

        /// <summary>
        /// Gets or sets literal pilot 
        /// </summary>
        public string LiteralPilot { get; set; }

        /// <summary>
        /// Gets or sets literal expiration date
        /// </summary>
        public string LiteralExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets literal notification date
        /// </summary>
        public string LiteralNotificationDate { get; set; }

        /// <summary>
        /// Gets or sets literal creation date
        /// </summary>
        public string LiteralCreationDate { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether is approve
        /// </summary>
        [DisplayName("Carrierd_Approve")]
        public int IsApprove { get; set; }

        /// <summary>
        /// Get or sets status document
        /// </summary>
        public string StatusDocument { get; set; }
    }
}