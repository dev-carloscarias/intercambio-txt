
//---------------------------------------------------------------------------------------
// <copyright file="DocumentType.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System.ComponentModel;

    /// <summary>
    /// Document type entity
    /// </summary>
    public class DocumentType
    {
        /// <summary>
        /// Gets or sets document type id
        /// </summary>
        [DisplayName("Carrierdt_Id")]
        public int? DocumentTypeId { get; set; }

        /// <summary>
        /// Gets or sets document description
        /// </summary>
        [DisplayName("Carrierdt_Description")]
        public string DocumentTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets document type apply to
        /// </summary>
        [DisplayName("Carrierdt_Apply")]
        public string ApplyTo { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether document type is active or not
        /// </summary>
        [DisplayName("Carrierdt_Active")]
        public bool? Active { get; set; }

        /// <summary>
        /// Gets or sets document type country code using country id
        /// </summary>
        [DisplayName("Carrierdtc_Country_Code")]
        public int? CountryId { get; set; }

        /// <summary>
        /// Gets or sets document type allowed days
        /// </summary>
        [DisplayName("Carrierdtc_Allowed_Days")]
        public int? DocumentTypeAllowedDays { get; set; }

        /// <summary>
        /// Gets or sets allowed days
        /// </summary>
        [DisplayName("AllowedDays")]
        public int? AllowedDays { get; set; }

        /// <summary>
        /// Gets or sets apply 
        /// </summary>
        public DocumentTypeApply ApplyToEntity { get; set; }
    }
}