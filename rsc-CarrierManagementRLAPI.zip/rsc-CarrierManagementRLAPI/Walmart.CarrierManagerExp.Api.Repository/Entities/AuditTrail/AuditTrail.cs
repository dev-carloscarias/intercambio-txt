﻿//-----------------------------------------------------------------------
// <copyright file="AuditTrail.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//-----------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.Repository
{
    #region Using

    using System.ComponentModel.DataAnnotations;
    using System.Diagnostics.CodeAnalysis;

    #endregion Using

    /// <summary>
    /// Audit trail data entity
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class AuditTrail
    {
        /// <summary>
        /// Gets or sets audit trail key
        /// </summary>
        [Key]
        public int AuditTrailId { get; set; }

        /// <summary>
        /// Gets or sets audit trail user
        /// </summary>
        public string AuditTrailUserId { get; set; }

        /// <summary>
        /// Gets or sets audit trail user domain
        /// </summary>
        public string AuditTrailUserDomain { get; set; }
    }
}