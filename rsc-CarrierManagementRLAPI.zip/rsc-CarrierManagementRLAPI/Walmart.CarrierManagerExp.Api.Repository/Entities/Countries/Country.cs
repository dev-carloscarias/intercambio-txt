//-----------------------------------------------------------------------    
// <copyright file="Country.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Esteban Barboza Muñoz</author>    
//----------------------------------------------------------------------- 
namespace Walmart.CarrierManagerExp.Api.Repository
{
    using System;
    using System.ComponentModel;

    /// <summary>
    /// Country model class
    /// </summary>
    public class Country
    {
        /// <summary>
        /// Gets or sets country id
        /// </summary>
        [DisplayName("ID_Pais")]
        public int? Id { get; set; }

        /// <summary>
        /// Gets or sets country name
        /// </summary>
        [DisplayName("Pais_nm")]
        public string CountryName { get; set; }

        /// <summary>
        /// Gets or sets country ISO code
        /// </summary>
        public int? CountryIsoCode { get; set; }

        /// <summary>
        /// Gets or sets country alpha 2 code
        /// </summary>
        public string CountryAlpha2 { get; set; }

        /// <summary>
        /// Gets or sets country alpha 3 code
        /// </summary>
        public string CountryAlpha3 { get; set; }

        /// <summary>
        /// Gets or sets country currency code
        /// </summary>
        public string CountryCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether country is enabled
        /// </summary>
        public bool? CountryStatus { get; set; }
    }
}
