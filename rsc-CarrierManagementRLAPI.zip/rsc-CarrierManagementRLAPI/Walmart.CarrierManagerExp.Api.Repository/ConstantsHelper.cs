// <copyright file="ConstantsHelper.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Repositories
{
    /// <summary>
    /// Constans helper class
    /// </summary>
    public static class ConstantsHelper
    {
        #region TMS

        #region SP

        /// <summary>
        /// Get carrier using code procedure name
        /// </summary>
        public const string GetCarrierByCodeSP = "Carrier_Exp_GetByCode_SP";

        /// <summary>
        /// Get carrier using email procedure name
        /// </summary>
        public const string GetCarrierByEmail = "Carrier_Exp_GetByCMUser_SP";
        
        /// <summary>
        /// Validate if TMS carrier exist or not
        /// </summary>
        public const string ValidateCarrierSP = "CM_Validate_Carrier";

        /// <summary>
        /// Get generic carrier info procedure
        /// </summary>
        public const string GetGenericCarrierSP = "CM_Carrier_Information_By_Identifier";

        /// <summary>
        /// Send notification procedure name
        /// </summary>
        public const string SendNotificationsSP = "Upload_Notification_SP";

        /// <summary>
        /// Get box car procedure name
        /// </summary>
        public const string GetBoxCarByCodesSP = "CM_Get_Box_Car_By_Codes";

        /// <summary>
        /// Get vehicle procedure name
        /// </summary>
        public const string GetVehicleByCodesSP = "CM_Get_Carrier_Vehicle_ByCodes_SP";

        /// <summary>
        /// Get pilot procedure name
        /// </summary>
        public const string GetPilotbyCodesSP = "CM_Get_Pilot_By_Codes_SP";
        
        /// <summary>
        /// Get carrier by id procedure name
        /// </summary>
        public const string GetCarrierByIdSP = "CM_GetCarrier_SP";

        /// <summary>
        /// Get TMS carrier report part
        /// </summary>
        public const string GetTMSCarrierReportSP = "uspCarrierInformationByIdentifierJustValidateLink";

        /// <summary>
        /// Get TMS country catalog
        /// </summary>
        public const string GetTMSCountries = "uspGetCountry_SP";

        #endregion SP

        #endregion TMS

        #region CarrierManager

        #region SP

        // <summary>
        /// Get document type procedure name
        /// </summary>
        public const string GetDocumentTypeSP = "Get_Document_TypeSP";
        
        // <summary>
        /// Get document allowed days
        /// </summary>
        public const string GetDocumentAllowedDaysSP = "uspGetAllowedDays";

        /// <summary>
        /// Get document procedure name
        /// </summary>
        public const string GetDocumentSP = "Get_Carrier_Document_SP";

        /// <summary>
        /// Inser document procedure name
        /// </summary>
        public const string InsertDocumentSP = "Insert_CarrierDocument_SP";

        /// <summary>
        /// Update docuement SP
        /// </summary>
        public const string UpdateDocumentSP = "Update_Carrier_Document_SP";

        /// <summary>
        /// Carrier report procedure name
        /// </summary>
        public const string CarrierReportSP = "uspGetInformationReport";

        /// <summary>
        /// Carrier type apply procedure name
        /// </summary>
        public const string CarrierTypeApplySP = "Get_Carrier_Document_Type_Apply_SP";

        #endregion SP

        #endregion CarrierManager
    }
}