#!/bin/bash
#Segundo plano
bash /app/renew.sh &
#CRON
#crontab /app/crontab
#App principal
dotnet Walmart.CarrierManagerExp.Api.dll