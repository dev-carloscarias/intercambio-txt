//---------------------------------------------------------------------------------------
// <copyright file="CommonUtilities.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Linq;

    /// <summary>
    /// Utilities class
    /// </summary>
    public static class CommonUtilities
    {
        /// <summary>
        /// Create a SQL parameters list for object were value is not null using display name property
        /// </summary>
        /// <param name="value">Object to create SQL parameters</param>
        /// <param name="sqlParameter">SQL parameters list</param>
        /// <returns>A SQL parameters array</returns>
        public static SqlParameter[] CreateSqlParameters(object value, List<SqlParameter> sqlParameter = null)
        {
            List<SqlParameter> sqlParams = sqlParameter ?? new List<SqlParameter>();

            foreach (var item in value.GetType().GetProperties())
            {
                if (value.GetType().IsGenericType) continue;
                object val = item.GetValue(value, null);
                string displayName = null;
                if (val == null) continue;
                if (val.GetType().GetProperties().Any() && !(val is string))
                {
                    CreateSqlParameters(val, sqlParams);
                    continue;
                }
                if (item.GetCustomAttributes(typeof(DisplayNameAttribute), true).Any())
                {
                    displayName = item.GetCustomAttributes(typeof(DisplayNameAttribute), true).Cast<DisplayNameAttribute>().Single().DisplayName;
                    sqlParams.Add(new SqlParameter($"@{displayName}", val));
                }

            }

            return sqlParams.ToArray();
        }


        /// <summary>
        /// Class list to data table
        /// </summary>
        /// <typeparam name="T">Generic property</typeparam>
        /// <param name="list">Generic object property</param>
        /// <returns>Data table object</returns>
        public static DataTable ClassListToDataTable<T>(IList<T> list) where T : class
        {
            var table = CreateTable<T>();
            var entityType = typeof(T);
            var properties = TypeDescriptor.GetProperties(entityType);

            foreach (T item in list)
            {
                var row = table.NewRow();

                foreach (PropertyDescriptor prop in properties)
                {
                    row[prop.DisplayName ?? prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                }

                table.Rows.Add(row);
            }

            return table;
        }

        /// <summary>
        /// Create table object
        /// </summary>
        /// <typeparam name="T">Generic property</typeparam>
        /// <returns>Data table object</returns>
        public static DataTable CreateTable<T>() where T : class
        {
            var entityType = typeof(T);
            DataTable dataTable = null;

            using (var table = new DataTable(entityType.Name))
            {
                table.Locale = CultureInfo.InvariantCulture;

                var properties = TypeDescriptor.GetProperties(entityType);

                foreach (PropertyDescriptor prop in properties)
                {
                    table.Columns.Add(prop.DisplayName ?? prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
                }

                dataTable = table;
            }

            return dataTable;
        }
    }
}