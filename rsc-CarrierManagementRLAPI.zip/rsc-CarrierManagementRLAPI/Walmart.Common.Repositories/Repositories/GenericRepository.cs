﻿//---------------------------------------------------------------------------------------    
// <copyright file="GenericRepository.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Repositories
{
    #region Using
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Linq;
    using System.Threading.Tasks;
    #endregion

    /// <summary>
    /// Base repository pattern
    /// </summary>
    /// <typeparam name="T">Generic base type</typeparam>
    public abstract class GenericRepository<T> : IDisposable where T : class
    {
      

        #region Fields

        /// <summary>
        /// Connection database value
        /// </summary>
        private readonly string connectionString;

        #endregion     

        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="GenericRepository{T}" /> class
        /// </summary>
        /// <param name="connectionString">Data base connection string</param>
        protected GenericRepository(string connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
                throw new ArgumentNullException("Connection string cannot be empty", nameof(connectionString));

            this.connectionString = connectionString;
        }
        #endregion

        #region Properties
        /// <summary>
        /// Gets connection to a SQL Server database
        /// </summary>
        public SqlConnection Connection
        {
            get
            {
                return new SqlConnection(
                new SqlConnectionStringBuilder(this.connectionString).ToString());
            }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Dispose Api.Resources
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Virtual method to populate entities
        /// </summary>
        /// <param name="reader">Represents a way of reading a forward-only stream of rows from a SQL Server database</param>
        /// <returns>Generic object</returns>
        public virtual T PopulateRecord(DbDataReader reader)
        {
            return null;
        }

        /// <summary>
        /// Get all records
        /// </summary>
        /// <param name="command">Represents a Transact-SQL statement or stored procedure to execute against a SQL Server database</param>
        /// <returns>Generic Collection</returns>                         
        protected virtual async Task<IQueryable<T>> GetRecords(SqlCommand command)
        {
            var list = new List<T>();
            command.Connection = this.Connection;
            await command.Connection.OpenAsync();

            try
            {
                var reader = await command.ExecuteReaderAsync();
                try
                {
                    while (reader.Read())
                    {
                        list.Add(this.PopulateRecord(reader));
                    }
                }
                finally
                {
                    // Always call Close when done reading.
                    reader.Close();
                }
            }
            finally
            {
                command.Connection.Close();
            }

            return list.AsQueryable();
        }

        /// <summary>
        /// Get all records paginated and specifies the total of records.
        /// </summary>
        /// <param name="command">Represents a Transact-SQL statement or stored procedure to execute against a SQL Server database</param>
        /// <returns>Generic Collection</returns>                         
        protected virtual async Task<(int total, IQueryable<T> result)> GetPagedRecords(SqlCommand command)
        {
            var list = new List<T>();
            command.Connection = this.Connection;
            await command.Connection.OpenAsync();
            int totalRecords = 0;
            bool totalRecordsSet = false;
            try
            {
                var reader = await command.ExecuteReaderAsync();
                try
                {
                    while (reader.Read())
                    {
                        if (!totalRecordsSet)
                        {
                            totalRecords = Convert.ToInt32(reader["__total"]);
                            totalRecordsSet = true;
                        }
                        list.Add(this.PopulateRecord(reader));
                    }
                }
                finally
                {
                    // Always call Close when done reading.
                    reader.Close();
                }
            }
            finally
            {
                command.Connection.Close();
            }

            return (totalRecords, list.AsQueryable());
        }

        /// <summary>
        /// Get specific record
        /// </summary>
        /// <param name="command">Represents a Transact-SQL statement or stored procedure to execute against a SQL Server database</param>
        /// <returns>Generic object</returns>
        protected virtual async Task<T> GetRecord(SqlCommand command)
        {
            T record = null;
            command.Connection = this.Connection;
            await command.Connection.OpenAsync();
            try
            {
                var reader = await command.ExecuteReaderAsync();
                try
                {
                    if (await reader.ReadAsync())
                    {
                        record = this.PopulateRecord(reader);
                    }
                }
                finally
                {
                    // Always call Close when done reading.
                    reader.Close();
                }
            }
            finally
            {
                command.Connection.Close();
            }

            return record;
        }

        /// <summary>
        /// Initiates the asynchronous execution of the Transact-SQL statement or stored procedure
        /// </summary>
        /// <param name="command">Represents a Transact-SQL statement or stored procedure to execute against a SQL Server database</param>
        /// <returns>Object list</returns>
        protected virtual async Task<IQueryable<T>> ExecuteStoredProc(SqlCommand command)
        {
            var list = new List<T>();
            command.Connection = this.Connection;
            command.CommandType = CommandType.StoredProcedure;

            await command.Connection.OpenAsync();

            try
            {
                var reader = await command.ExecuteReaderAsync();
                try
                {
                    while (reader.Read())
                    {
                        var record = this.PopulateRecord(reader);
                        if (record != null)
                        {
                            list.Add(record);
                        }
                    }
                }
                finally
                {
                    reader.Close();
                }
            }
            finally
            {
                command.Connection.Close();
            }

            return list.AsQueryable();
        }

        /// <summary>
        /// Executes a Transact-SQL statement against the connection and returns the number of rows affected
        /// </summary>
        /// <param name="command">Represents a Transact-SQL statement or stored procedure to execute against a SQL Server database</param>
        /// <returns>Rows affected by the command</returns>
        protected virtual async Task<int> ExecuteCommand(SqlCommand command)
        {
            command.Connection = this.Connection; 
            int affected;

            await command.Connection.OpenAsync();

            try
            {               
                affected = await command.ExecuteNonQueryAsync();
            }
            finally
            {
                command.Connection.Close();
            }

            return affected;
        }

        /// <summary>
        /// Executes a Transact-SQL function statement against the connection and returns the value
        /// </summary>
        /// <param name="command">Represents a Transact-SQL statement or stored procedure to execute against a SQL Server database</param>
        /// <returns>Object affected by the command</returns>
        protected virtual async Task<object> ExecuteFunction(SqlCommand command)
        {
            command.Connection = this.Connection;
            object affected;
            await command.Connection.OpenAsync();

            try
            {
                affected = await command.ExecuteScalarAsync();
            }
            finally
            {
                command.Connection.Close();
            }

            return affected;
        }

        /// <summary>
        /// Executes a Transact-SQL bulk copy process
        /// </summary>
        /// <param name="command">Represents a SQL bulk copy entity</param>
        /// <returns>Task result</returns> 
        protected virtual async Task<bool> ExecuteBulkCopy(BulkCopy command)
        {
            bool affected = false;
            var bulkCopyConnection = this.Connection;
            await bulkCopyConnection.OpenAsync();
            var transaction = bulkCopyConnection.BeginTransaction();

            using (var sqlBulk = new SqlBulkCopy(bulkCopyConnection, SqlBulkCopyOptions.Default, transaction))
            {
                sqlBulk.BulkCopyTimeout = command.BulkCopyTimeout;
                sqlBulk.BatchSize = command.BatchSize;
                sqlBulk.DestinationTableName = command.DestinationTableName;

                try
                {
                    await sqlBulk.WriteToServerAsync(command.TableRows);
                    transaction.Commit();
                    affected = true;
                }
                catch (SqlException)
                {

                    transaction.Rollback();
                }
                catch (Exception)
                {
                    transaction.Rollback();
                }
                finally
                {
                    bulkCopyConnection.Close();
                }
            }
            return affected;
        }        

        /// <summary>
        /// Gets true if We can access the database by openning a SQL connection.
        /// </summary>
        /// <returns></returns>
        protected virtual async Task<bool> TestConnection()
        {
            await this.Connection.OpenAsync();
            this.Connection.Close();
            return true;
        }

        /// <summary>
        /// Dispose _connection resource
        /// </summary>
        /// <param name="disposing">Flag to free native Api.Resources</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // dispose managed Api.Resources
                this.Connection.Close();
            }

            //// free native Api.Resources
        }
        #endregion
    }
}
