﻿//---------------------------------------------------------------------------------------    
// <copyright file="BulkCopy.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Repositories
{
    using System;
    using System.Data;

    /// <summary>
    /// Bulk copy class
    /// </summary>
    public class BulkCopy : IDisposable
    {
        /// <summary>
        /// Disposed value
        /// </summary>
        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// Gets or sets bulk copy timeout
        /// </summary>
        public int BulkCopyTimeout { get; set; }

        /// <summary>
        /// Gets or sets bulk copy batch size
        /// </summary>
        public int BatchSize { get; set; }

        /// <summary>
        /// Gets or sets destination table name
        /// </summary>
        public string DestinationTableName { get; set; }

        /// <summary>
        /// Gets or sets table rows
        /// </summary>
        public DataTable TableRows { get; set; }

        #region IDisposable Support 
        /// <summary>
        /// Dispose method
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        /// <param name="disposing">Dispose property</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposedValue)
            {
                if (disposing)
                {
                    //// TODO: dispose managed state (managed objects).
                }

                this.disposedValue = true;
            }
        }
        #endregion
    }
}
