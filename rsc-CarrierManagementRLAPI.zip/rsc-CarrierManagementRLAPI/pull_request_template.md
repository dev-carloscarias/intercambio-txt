    ## [TICKET DE JIRA]
    [Enlace de Jira](url)

    ¿Qué tipo de cambio introduce este PR?
    ```
    [ ] Corrección de errores
    [ ] Característica
    [ ] Actualización de estilo de código (formato, variables locales)
    [ ] Refactorización (sin cambios funcionales, sin cambios en la API)
    [ ] Cambios relacionados con la compilación
    [ ] Cambios relacionados con CI/CD
    [ ] Cambios en el contenido de la documentación
    [ ] Pruebas
    [ ] Otro
    ```

    ## Detalles del cambio
    <!-- Ej: 
    Este PR introduce una nueva característica que permite a los usuarios buscar productos por nombre en nuestra página de comercio electrónico. La búsqueda se realiza en tiempo real a medida que el usuario escribe en el campo de búsqueda, mejorando así la experiencia del usuario al permitirle encontrar rápidamente el producto que está buscando.
    -->

    ## Como fue testado
    <!-- Esta característica fue probada en varios navegadores (Chrome, Firefox, Safari) y dispositivos (PC, Mac, iPhone, Android) para asegurar su correcto funcionamiento. También se realizaron pruebas de carga para verificar que la búsqueda en tiempo real no sobrecargue nuestro servidor. Todos los tests pasaron satisfactoriamente. -->

    ## Capturas de pantalla / cURL (opcional)
    N/A