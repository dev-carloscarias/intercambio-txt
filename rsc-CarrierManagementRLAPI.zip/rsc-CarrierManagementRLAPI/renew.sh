#!/bin/bash
while true; do
    PP=$(cat "$PASSWORD_DIR")
    USER=$(cat "$USER_DIR")
    echo "$PP" | kinit "$USER"
    echo "renew kerberos"
    sleep "2h"
done