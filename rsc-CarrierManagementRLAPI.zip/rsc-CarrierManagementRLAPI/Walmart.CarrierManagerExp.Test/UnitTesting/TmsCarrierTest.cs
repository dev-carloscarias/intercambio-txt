﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class TmsCarrierTest
    {
        [TestMethod]
        public void TmsCarrier_ShouldInitializeCorrectly() {

            var tmsCarrier = new TmsCarrier
            {
                CarrierId = 1,
                CountryId = 2,
                CarrierCode = "Test",
                CarrierName = "Test",
                CarrierOwnerName = "Test",
                CarrierOwnerCode = "Test",
                ContractDate = DateTime.Now.AddDays(5),
                CarrierEmail = "Test",
                CarrierState = "Test",
                BusinessName = "Test"
            };

            Assert.AreEqual(1, tmsCarrier.CarrierId);
            Assert.AreEqual(2, tmsCarrier.CountryId);
            Assert.AreEqual("Test", tmsCarrier.CarrierCode);
            Assert.AreEqual("Test", tmsCarrier.CarrierName);
            Assert.AreEqual("Test", tmsCarrier.CarrierOwnerName);
            Assert.IsTrue(tmsCarrier.ContractDate > DateTime.Now);
            Assert.AreEqual("Test", tmsCarrier.CarrierEmail);
            Assert.AreEqual("Test", tmsCarrier.CarrierState);
            Assert.AreEqual("Test", tmsCarrier.BusinessName);
        }
    }
}
