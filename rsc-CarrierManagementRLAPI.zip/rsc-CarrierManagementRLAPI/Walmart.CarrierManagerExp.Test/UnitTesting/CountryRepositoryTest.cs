﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.SqlClient;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    
    public class FakeCountryRepository : CountryRepository
    { 
    
        public SqlCommand LastCommand { get; private set; }
        private readonly IQueryable<Country> _fakeResult;        

        public FakeCountryRepository(string connectionString, IQueryable<Country> fakeResult) : base(connectionString)
        {
            _fakeResult = fakeResult;            
        }        

        protected override async Task<IQueryable<Country>> GetRecords(SqlCommand command) { 
        
            LastCommand = command;
            if(_fakeResult != null)
                return await Task.FromResult(_fakeResult);
            else
                return await Task.FromResult(new List<Country>().AsQueryable());
        }        
    }

    [TestClass]
    public class FakeCountryRepositoryTest
    {
        private const string connectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";        

        [TestMethod]
        public async Task GetAll_WithDefaultParameters_ShouldNotAddParameters() {
            
            var fakeResult = new List<Country> ().AsQueryable();
            var repo = new FakeCountryRepository(connectionString, fakeResult);
            var result = await repo.GetAll();

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetTMSCountries, repo.LastCommand.CommandText);
            Assert.AreEqual(0, repo.LastCommand.Parameters.Count);
            Assert.AreEqual(fakeResult, result);
            
        }        
    }
}
