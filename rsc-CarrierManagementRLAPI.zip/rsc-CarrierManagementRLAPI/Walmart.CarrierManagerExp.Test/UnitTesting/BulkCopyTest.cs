﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Reflection.Metadata.Ecma335;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class BulkCopyTest
    {
        [TestMethod]
        public void BulkCopy_ShouldInitializeCorrectly() {
            
            var table = new DataTable();
            var bulk = new BulkCopy
            {                
                BulkCopyTimeout = 1,
                BatchSize = 1,
                DestinationTableName = "Test",
                TableRows = table,
            };
            
            Assert.AreEqual(1, bulk.BulkCopyTimeout);
            Assert.AreEqual(1, bulk.BatchSize);
            Assert.AreEqual("Test", bulk.DestinationTableName);
            Assert.IsNotNull(bulk.TableRows);
        }        
    }
}
