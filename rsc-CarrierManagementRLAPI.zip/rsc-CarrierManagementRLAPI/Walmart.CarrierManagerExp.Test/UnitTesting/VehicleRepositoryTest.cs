﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.SqlClient;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    
    public class FakeVehicleRepository : VehicleRepository
    {
        public SqlCommand LastCommand { get; private set; }
        private readonly IQueryable<Vehicle> _fakeResult;                

        public FakeVehicleRepository(string connectionString, IQueryable<Vehicle> fakeResult) : base(connectionString)
        {
            _fakeResult = fakeResult;
        }        

        protected override async Task<IQueryable<Vehicle>> GetRecords(SqlCommand command)
        {

            LastCommand = command;
            if (_fakeResult != null)
                return await Task.FromResult(_fakeResult);
            else
                return await Task.FromResult(new List<Vehicle>().AsQueryable());
        }
    }

    [TestClass]
    public class FakeVehicleRepositoryTest
    {
        private const string connectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";        

        [TestMethod]
        public async Task GetItem_ShouldBeOk() {
            
            var fakeResult = new List<Vehicle>().AsQueryable();
            var repo = new FakeVehicleRepository(connectionString, fakeResult);

            string carrierCode = "123";
            string code = "Test";
            int id = 123;            

            var result = await repo.Get(carrierCode, code, id);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetVehicleByCodesSP, repo.LastCommand.CommandText);
            Assert.AreEqual(3, repo.LastCommand.Parameters.Count);
            AssertParameter(repo.LastCommand, "@carrierCode", carrierCode);
            AssertParameter(repo.LastCommand, "@code", code);
            AssertParameter(repo.LastCommand, "@id", id);            
            Assert.AreEqual(fakeResult, result);
        }       

        private void AssertParameter(SqlCommand command, string paramName, object expectedValue)
        {

            Assert.IsTrue(command.Parameters.Contains(paramName), $"El parámetro {paramName} debe existir");
            var param = command.Parameters[paramName];
            if (expectedValue == DBNull.Value)
                Assert.AreEqual(DBNull.Value, param.Value);
            else
                Assert.AreEqual(expectedValue, param.Value);
        }
    }
}
