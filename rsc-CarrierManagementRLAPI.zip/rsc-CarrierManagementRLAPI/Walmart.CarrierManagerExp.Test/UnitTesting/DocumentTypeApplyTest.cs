﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class DocumentTypeApplyTest
    {
        [TestMethod]
        public void DocumentTypeApply_ShouldInitializeCorrectly() {

            var documentTypeApply = new DocumentTypeApply
            {
                DocumentTypeApplyId = 1,                
                DocumentTypeApplyName= "Test Name",
                DocumentTypeApplyNameEn = "Test Name En",
                Active = true,                
            };

            Assert.AreEqual(1, documentTypeApply.DocumentTypeApplyId);
            Assert.AreEqual("Test Name", documentTypeApply.DocumentTypeApplyName);
            Assert.AreEqual("Test Name En", documentTypeApply.DocumentTypeApplyNameEn);
            Assert.AreEqual(true, documentTypeApply.Active);

        }
    }
}
