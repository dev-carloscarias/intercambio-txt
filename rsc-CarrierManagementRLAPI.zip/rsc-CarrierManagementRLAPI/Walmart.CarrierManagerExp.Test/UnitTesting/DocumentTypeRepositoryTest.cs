﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.SqlClient;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    
    public class FakeDocumentTypeRepository : DocumentTypeRepository
    { 
    
        public SqlCommand LastCommand { get; private set; }
        private readonly IQueryable<DocumentType> _fakeResult;
        private readonly DocumentType _fakeRecord;

        public FakeDocumentTypeRepository(string connectionString, IQueryable<DocumentType> fakeResult) : base(connectionString)
        {
            _fakeResult = fakeResult;
            _fakeRecord = null;
        }
        public FakeDocumentTypeRepository(string connectionString, DocumentType fakeRecord) : base(connectionString)
        {
            _fakeResult = null;
            _fakeRecord = fakeRecord;
        }
        protected override async Task<DocumentType> GetRecord(SqlCommand command)
        {
            LastCommand = command;
            return await Task.FromResult(_fakeRecord);
        }

        protected override async Task<IQueryable<DocumentType>> GetRecords(SqlCommand command) { 
        
            LastCommand = command;
            if(_fakeResult != null)
                return await Task.FromResult(_fakeResult);
            else
                return await Task.FromResult(new List<DocumentType>().AsQueryable());
        }                
    }

    [TestClass]
    public class DocumentTypeRepositoryTest
    {
        private const string connectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";        

        [TestMethod]
        public async Task GetItems_WithDefaultParameters_ShouldNotAddParameters() {
            
            var fakeResult = new List<DocumentType> ().AsQueryable();
            var repo = new FakeDocumentTypeRepository(connectionString, fakeResult);

            int countryCode = 1;
            string applyTo = "Test";
            int documentType = 123;
            
            var result = await repo.GetItems(countryCode, applyTo, documentType);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetDocumentTypeSP, repo.LastCommand.CommandText);
            Assert.AreEqual(3, repo.LastCommand.Parameters.Count);
            Assert.AreEqual(fakeResult, result);
            
        }
        [TestMethod]
        public async Task GetItems_WithNonDefaultParameters_ShouldAddAppropiateParameters()
        {
            var fakeRecordaux = new DocumentType { DocumentTypeId = 10, ApplyTo = "Test", Active = true };
            var fakeResult = new List<DocumentType>() { fakeRecordaux }.AsQueryable();
            var repo = new FakeDocumentTypeRepository(connectionString, fakeResult);
            
            int countryCode = 1;
            string applyTo = "Test";
            int documentType = 123;

            var result = await repo.GetItems(countryCode, applyTo, documentType);
            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetDocumentTypeSP, repo.LastCommand.CommandText);

            Assert.AreEqual(3, repo.LastCommand.Parameters.Count);

            AssertParameter(repo.LastCommand, "@CountryId", countryCode);
            AssertParameter(repo.LastCommand, "@ApplyTo", applyTo);
            AssertParameter(repo.LastCommand, "@Id", documentType);

            Assert.AreEqual(fakeResult, result);
        }

        [TestMethod]
        public async Task GetAllowedDays_ShouldReturnApproiateParameters() {

            var fakeRecordaux = new DocumentType { DocumentTypeId = 10, ApplyTo = "Test", Active = true };            
            var repo = new FakeDocumentTypeRepository(connectionString, fakeRecordaux);

            int carrierId = 1;
            int pilotId = 2;

            var result = await repo.GetIAllowedDays(carrierId, pilotId);
            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetDocumentAllowedDaysSP, repo.LastCommand.CommandText);

            Assert.AreEqual(2, repo.LastCommand.Parameters.Count);

            AssertParameter(repo.LastCommand, "@CarrierId", carrierId);
            AssertParameter(repo.LastCommand, "@PilotId", pilotId);            

            Assert.AreEqual(fakeRecordaux, result);
        }

        private void AssertParameter(SqlCommand command, string paramName, object expectedValue)
        {

            Assert.IsTrue(command.Parameters.Contains(paramName));
            var param = command.Parameters[paramName];
            if (expectedValue == DBNull.Value)
                Assert.AreEqual(DBNull.Value, param.Value);
            else
                Assert.AreEqual(expectedValue, param.Value);
        }
    }
}
