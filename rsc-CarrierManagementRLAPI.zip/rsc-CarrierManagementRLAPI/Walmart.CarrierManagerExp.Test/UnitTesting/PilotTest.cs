﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class PilotTest
    {
        [TestMethod]
        public void Pilot_ShouldInitializeCorrectly() {

            var pilot = new Pilot
            {
                PilotId = 1,
                PilotCode = "Test",
                PilotName = "Test",
                Active = "True"
            };
            
            Assert.AreEqual(1, pilot.PilotId);
            Assert.AreEqual("Test", pilot.PilotCode);
            Assert.AreEqual("Test", pilot.PilotName);
            Assert.AreEqual("True", pilot.Active);            
            
        }
    }
}
