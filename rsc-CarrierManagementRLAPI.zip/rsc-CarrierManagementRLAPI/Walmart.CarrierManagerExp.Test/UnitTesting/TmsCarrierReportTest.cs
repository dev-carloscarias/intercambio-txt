﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class TmsCarrierReportTest
    {
        [TestMethod]
        public void TmsCarrierReport_ShouldInitializeCorrectly() {

            var tmsCarrier = new TmsCarrierReport
            {
                Identifier = "1234",
                Code = "TestCode",
                Description = "TestDescription",
                CountryName = "TestCountry",
                Name = "TestName"

            };

            Assert.AreEqual("1234", tmsCarrier.Identifier);
            Assert.AreEqual("TestCode", tmsCarrier.Code);
            Assert.AreEqual("TestDescription", tmsCarrier.Description);
            Assert.AreEqual("TestCountry", tmsCarrier.CountryName);
            Assert.AreEqual("TestName", tmsCarrier.Name);

        }
    }
}
