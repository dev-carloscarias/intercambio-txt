﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class DocumentTypeTest
    {
        [TestMethod]
        public void DocumentType_ShouldInitializeCorrectly() {
            
            var documentType = new DocumentType
            {                
                DocumentTypeDescription = "Test Description",
                ApplyTo = "Test Apply",
                Active = true,
                CountryId = 123,
                AllowedDays = 30,
                DocumentTypeId = 1,
                DocumentTypeAllowedDays = 30,
            };
            
            Assert.AreEqual(1, documentType.DocumentTypeId);
            Assert.AreEqual(30, documentType.DocumentTypeAllowedDays);
            Assert.AreEqual("Test Description", documentType.DocumentTypeDescription);
            Assert.AreEqual("Test Apply", documentType.ApplyTo);
            Assert.AreEqual(true, documentType.Active);
            Assert.AreEqual(123, documentType.CountryId);
            Assert.AreEqual(30, documentType.AllowedDays);

        }
    }
}
