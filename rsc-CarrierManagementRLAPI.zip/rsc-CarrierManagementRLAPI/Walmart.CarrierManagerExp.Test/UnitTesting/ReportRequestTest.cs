﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class ReportRequestTest
    {
        [TestMethod]
        public void ReportRequest_ShouldInitializeCorrectly() {

            var reportRequest = new ReportRequest
            {                
                CarrierIdF = 2,
                CarrierIdV = 3,
                CarrierIdP = 4, 
                ApplyFor = "Test Apply",
                CarrrierId = 5,

            };

            Assert.AreEqual(5, reportRequest.CarrrierId);
            Assert.AreEqual(2, reportRequest.CarrierIdF);
            Assert.AreEqual(3, reportRequest.CarrierIdV);
            Assert.AreEqual(4, reportRequest.CarrierIdP);
            Assert.AreEqual("Test Apply", reportRequest.ApplyFor);
        }
    }
}
