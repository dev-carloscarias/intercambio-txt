﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Walmart.CarrierManagerExp.Api;
using Walmart.CarrierManagerExp.Api.Common.Middlewares.Authorization;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.CarrierManagerExp.Api.V1;
using Walmart.Common.Helpers.Handlers;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class DocumentsControllerTest
    {
        private Mock<IDocumentsRepository> mockIDocumentsRepository;
        private Mock<IGenericRepository> mockIGenericRepository;        
        private Mock<ICarrierRepository> mockICarrierRepository;        
        private Mock<IBoxCarRepository> mockIBoxCarRepository;        
        private Mock<IPilotRepository> mockIPilotRepository;        
        private Mock<IVehicleRepository> mockIVehicleRepository;        
        private Mock<ICountryRepository> mockICountryRepository;
        private Mock<IDocumentTypeRepository> mockIDocumentTypeRepository;        
        private Mock<IOptions<AppSettings>> mockIOptions;//Configuration
        private Mock<ILogger<DocumentsController>> mockLogger;        
        private Mock<ISftpClient> mockISftpClient;        
        private Mock<IAuthorizationMiddleware> mockIAuthorizationMiddleware;        
        private Mock<IMemoryCacheHelper> mockMemoryCacheHelper;
        private Mock<ISecretHelper> mockSecretHelper;
        
        private DocumentsController controller;

        [TestInitialize]
        public void Setup()
        {
            mockIDocumentsRepository = new Mock<IDocumentsRepository>();
            mockIGenericRepository = new Mock<IGenericRepository>();
            mockICarrierRepository = new Mock<ICarrierRepository>();
            mockIBoxCarRepository = new Mock<IBoxCarRepository>();
            mockIPilotRepository = new Mock<IPilotRepository>();
            mockIVehicleRepository = new Mock<IVehicleRepository>();
            mockICountryRepository = new Mock<ICountryRepository>();
            mockIDocumentTypeRepository = new Mock<IDocumentTypeRepository>();
            mockLogger = new Mock<ILogger<DocumentsController>>();
            mockIOptions = new Mock<IOptions<AppSettings>>();            
            mockISftpClient = new Mock<ISftpClient>();
            mockMemoryCacheHelper = new Mock<IMemoryCacheHelper>();
            mockSecretHelper = new Mock<ISecretHelper>();
            mockIAuthorizationMiddleware = new Mock<IAuthorizationMiddleware>();

            controller = new DocumentsController(mockIDocumentsRepository.Object, mockIGenericRepository.Object, mockICarrierRepository.Object,mockIBoxCarRepository.Object, mockIPilotRepository.Object, mockIVehicleRepository.Object, 
                mockICountryRepository.Object, mockIDocumentTypeRepository.Object,mockLogger.Object, mockIOptions.Object, mockISftpClient.Object, (IMemoryCacheHelper)mockMemoryCacheHelper, (ISecretHelper)mockSecretHelper,mockIAuthorizationMiddleware.Object);
        }

        //[TestMethod]  
        //[TestMethod]
    }
}
