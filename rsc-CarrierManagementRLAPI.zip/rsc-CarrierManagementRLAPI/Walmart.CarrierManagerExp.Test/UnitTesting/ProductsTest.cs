﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.CarrierManagerExp.Api.V1;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class ProductsTest
    {
        private Mock<IProductRepository> mockProductRepository;
        private Mock<ILogger<ProductsWTController>> mockLogger;
        private ProductsController controller;

        [TestInitialize]
        public void Setup()
        {
            mockProductRepository = new Mock<IProductRepository>();
            mockLogger = new Mock<ILogger<ProductsWTController>>();
            controller = new ProductsController(mockProductRepository.Object, mockLogger.Object);
        }

        #region Test Delete
        [TestMethod]
        public async Task Delete_ReturnsBadRequest_WhenModelStatesIsInvalid()
        {

            controller.ModelState.AddModelError("Id", "Invalid model");
            var result = await controller.Delete(1);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Delete_ReturnsOk_WhenDeletesIsSuccessful()
        {

            int id = 1;
            mockProductRepository.Setup(repo => repo.Delete(id.ToString())).ReturnsAsync(1);

            var result = await controller.Delete(id);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            var okResult = result as OkObjectResult;
            Assert.AreEqual(1, okResult?.Value);
        }
        [TestMethod]
        public async Task Delete_ReturnsBadRequest_WhenRecordNotFound()
        {

            int id = 1;
            mockProductRepository.Setup(repo => repo.Delete(id.ToString())).ReturnsAsync(0);

            var result = await controller.Delete(id);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Delete_ReturnsBadRequest_WhenSqlExceptionOccurs()
        {

            int id = 1;
            mockProductRepository.Setup(repo => repo.Delete(id.ToString())).ThrowsAsync(new Exception("Simulated SQL Exception!"));

            var result = await controller.Delete(id);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Delete_ReturnsBadRequest_WhenGeneralExceptionOccurs()
        {

            int id = 1;
            mockProductRepository.Setup(repo => repo.Delete(id.ToString())).ThrowsAsync(new Exception("Simulated General Exception!"));

            var result = await controller.Delete(id);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        #endregion Test Delete

        #region Test Post
        [TestMethod]
        public async Task Post_ReturnsBadRequest_WhenModelsStateIsInvalid()
        {
            controller.ModelState.AddModelError("Name", "The Name field is requiered.");
            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            var result = await controller.Post(product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Post_ReturnsOkResult_WhenProductIsAdded()
        {
            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            mockProductRepository.Setup(repo => repo.Add(product)).ReturnsAsync(1);

            var result = await controller.Post(product);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            var okResult = result as OkObjectResult;
            Assert.AreEqual(1, okResult?.Value);
        }

        [TestMethod]
        public async Task Post_ReturnedBadRequest_WhenAddFails()
        {
            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            mockProductRepository.Setup(repo => repo.Add(product)).ReturnsAsync(0);

            var result = await controller.Post(product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Post_ReturnsBadRequest_WhenSqlExceptionOccurs()
        {

            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            mockProductRepository.Setup(repo => repo.Add(product)).ThrowsAsync(new Exception("Simulated SQL Exception!"));

            var result = await controller.Post(product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        #endregion Test Post

        #region Test Put
        [TestMethod]
        public async Task Put_ReturnsOkResult_WhenProductIsUpdated()
        {

            var product = new Product { ProductId = 1, CustomerName = "Updated Product" };
            mockProductRepository.Setup(repo => repo.Update(product)).ReturnsAsync(1);

            var result = await controller.Put(1, product);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            var okResult = result as OkObjectResult;
            Assert.AreEqual(1, okResult?.Value);
        }


        [TestMethod]
        public async Task Put_ReturnsBadRequest_WhenProductField()
        {
            var product = new Product { ProductId = 1, CustomerName = "Updated Product" };
            mockProductRepository.Setup(repo => repo.Update(product)).ReturnsAsync(0);

            var result = await controller.Put(1, product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Put_ReturnsBadRequest_whenModelStateIsInvalid()
        {

            controller.ModelState.AddModelError("Name", "The name fields is required.");
            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            var result = await controller.Put(1, product);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Put_ReturnsBadRequest_WhenSqlExceptionOccurs()
        {

            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            mockProductRepository.Setup(repo => repo.Update(product)).ThrowsAsync(new Exception("Simulated SQL Exception!"));

            var result = await controller.Put(1, product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        #endregion Test Put
    }
}
