﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class VehicleTest
    {
        [TestMethod]
        public void Vehicle_ShouldInitializeCorrectly() {

            var vehicle = new Vehicle
            {
                VehicleId = 1,
                VehicleCode = "Test",
                LicencePlate = "Test",
                Active = true
            };
            
            Assert.AreEqual(1, vehicle.VehicleId);
            Assert.AreEqual("Test", vehicle.VehicleCode);
            Assert.AreEqual("Test", vehicle.LicencePlate);
            Assert.AreEqual(true, vehicle.Active);            
            
        }
    }
}
