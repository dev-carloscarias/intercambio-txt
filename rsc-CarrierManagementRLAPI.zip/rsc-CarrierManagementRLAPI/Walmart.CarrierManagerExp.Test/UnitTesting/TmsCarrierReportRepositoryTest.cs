﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.SqlClient;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    
    public class FakeTmsCarrierReportRepository : TmsCarrierReportRepository
    { 
    
        public SqlCommand LastCommand { get; private set; }
        private readonly IQueryable<TmsCarrierReport> _fakeResult;        

        public FakeTmsCarrierReportRepository(string connectionString, IQueryable<TmsCarrierReport> fakeResult) : base(connectionString)
        {
            _fakeResult = fakeResult;
        }        

        protected override async Task<IQueryable<TmsCarrierReport>> GetRecords(SqlCommand command) { 
        
            LastCommand = command;
            if(_fakeResult != null)
                return await Task.FromResult(_fakeResult);
            else
                return await Task.FromResult(new List<TmsCarrierReport>().AsQueryable());
        }               
    }

    [TestClass]
    public class TmsCarrierReportRepositoryTest
    {
        private const string connectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";        

        [TestMethod]
        public async Task GetReportByIdentifiers_WithDefaultParameters_ShouldNotAddParameters() {
            
            var fakeResult = new List<TmsCarrierReport> ().AsQueryable();
            var repo = new FakeTmsCarrierReportRepository(connectionString, fakeResult);
            
            string identifiers = "Test";
            
            var result = await repo.GetReportByIdentifiers(identifiers);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetTMSCarrierReportSP, repo.LastCommand.CommandText);
            Assert.AreEqual(1, repo.LastCommand.Parameters.Count);
            Assert.AreEqual(fakeResult, result);
            
        }
        [TestMethod]
        public async Task GetReportByIdentifiers_WithNonDefaultParameters_ShouldAddAppropiateParameters() {

            var fakeRecordaux = new TmsCarrierReport { Identifier = "Test", Code = "Test" };
            var fakeResult = new List<TmsCarrierReport>() { fakeRecordaux }.AsQueryable();
            var repo = new FakeTmsCarrierReportRepository(connectionString, fakeResult);

            string identifiers = "Test";

            var result = await repo.GetReportByIdentifiers(identifiers);
            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetTMSCarrierReportSP, repo.LastCommand.CommandText);

            Assert.AreEqual(1, repo.LastCommand.Parameters.Count);

            AssertParameter(repo.LastCommand, "@identificador", identifiers);            

            Assert.AreEqual(fakeResult, result);
        }        

        private void AssertParameter(SqlCommand command, string paramName, object expectedValue)
        {

            Assert.IsTrue(command.Parameters.Contains(paramName), $"El parámetro {paramName} debe existir");
            var param = command.Parameters[paramName];
            if (expectedValue == DBNull.Value)
                Assert.AreEqual(DBNull.Value, param.Value);
            else
                Assert.AreEqual(expectedValue, param.Value);
        }
    }
}
