﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.CarrierManagerExp.Api.V1;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Walmart.Common.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Security.Principal;

namespace Walmart.CarrierManagerExp.Test.UnitTesting {

    [TestClass]
    public class ProductsWTControllerTests
    {
        private Mock<IProductRepository> mockProductRepository;
        private Mock<ILogger<ProductsWTController>> mockLogger;
        private ProductsWTController controller;

        [TestInitialize]
        public void Setup()
        {            
            mockProductRepository = new Mock<IProductRepository>();
            mockLogger = new Mock<ILogger<ProductsWTController>>();            
            controller = new ProductsWTController(mockProductRepository.Object, mockLogger.Object);
        }

        #region Test Delete
        [TestMethod]
        public async Task Delete_ReturnsBadRequest_WhenModelStatesIsInvalid() {

            controller.ModelState.AddModelError("Id", "Invalid model");
            var result = await controller.Delete(1);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Delete_ReturnsOk_WhenDeletesIsSuccessful() {

            int id = 1;
            mockProductRepository.Setup(repo => repo.Delete(id.ToString())).ReturnsAsync(1);

            var result = await controller.Delete(id);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            var okResult = result as OkObjectResult;
            Assert.AreEqual(1, okResult?.Value);
        }
        [TestMethod]
        public async Task Delete_ReturnsBadRequest_WhenRecordNotFound()
        {

            int id = 1;
            mockProductRepository.Setup(repo => repo.Delete(id.ToString())).ReturnsAsync(0);

            var result = await controller.Delete(id);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Delete_ReturnsBadRequest_WhenSqlExceptionOccurs()
        {

            int id = 1;
            mockProductRepository.Setup(repo => repo.Delete(id.ToString())).ThrowsAsync(new Exception("Simulated SQL Exception!"));

            var result = await controller.Delete(id);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Delete_ReturnsBadRequest_WhenGeneralExceptionOccurs()
        {

            int id = 1;
            mockProductRepository.Setup(repo => repo.Delete(id.ToString())).ThrowsAsync(new Exception("Simulated General Exception!"));

            var result = await controller.Delete(id);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        #endregion Test Delete

        #region Test Post

        [TestMethod]
        public async Task Post_ReturnsBadRequest_WhenModelsStateIsInvalid() {
            controller.ModelState.AddModelError("Name", "The Name field is requiered.");
            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            var result = await controller.Post(product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Post_ReturnsOkResult_WhenProductIsAdded() {
            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            mockProductRepository.Setup(repo => repo.Add(product)).ReturnsAsync(1);

            var result = await controller.Post(product);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            var okResult = result as OkObjectResult;
            Assert.AreEqual(1, okResult?.Value);
        }

        [TestMethod]
        public async Task Post_ReturnedBadRequest_WhenAddFails() {
            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            mockProductRepository.Setup(repo => repo.Add(product)).ReturnsAsync(0);

            var result = await controller.Post(product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Post_ReturnsBadRequest_WhenSqlExceptionOccurs() {

            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            mockProductRepository.Setup(repo => repo.Add(product)).ThrowsAsync(new Exception("Simulated SQL Exception!"));

            var result = await controller.Post(product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        #endregion Test Post

        #region Test Put
        [TestMethod]
        public async Task Put_ReturnsOkResult_WhenProductIsUpdated() {

            var product = new Product { ProductId = 1, CustomerName = "Updated Product" };
            mockProductRepository.Setup(repo => repo.Update(product)).ReturnsAsync(1);

            var result = await controller.Put(1, product);
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            var okResult = result as OkObjectResult;
            Assert.AreEqual(1, okResult?.Value);
        }


        [TestMethod]
        public async Task Put_ReturnsBadRequest_WhenProductField() {
            var product = new Product { ProductId = 1, CustomerName = "Updated Product" };
            mockProductRepository.Setup(repo => repo.Update(product)).ReturnsAsync(0);

            var result = await controller.Put(1, product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));            
        }

        [TestMethod]
        public async Task Put_ReturnsBadRequest_whenModelStateIsInvalid() {

            controller.ModelState.AddModelError("Name", "The name fields is required.");
            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            var result = await controller.Put(1, product);

            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Put_ReturnsBadRequest_WhenSqlExceptionOccurs()
        {

            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            mockProductRepository.Setup(repo => repo.Update(product)).ThrowsAsync(new Exception("Simulated SQL Exception!"));

            var result = await controller.Put(1,product);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        #endregion Test Put

        #region Test Get
        [TestMethod]
        public async Task Get_ReturnsOkResult_WhenDataExists()
        {
            var result = await controller.Get(0, 500);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            var okResult = result as OkObjectResult;
            Assert.IsInstanceOfType(okResult?.Value, typeof(PagedResult<Product>));
        }

        [TestMethod]
        public async Task Get_ReturnsOk_WhenRecordsAreRetrieved() { 
        
            var products = new List<Product>
            {
                new Product { ProductId = 1, CustomerName = "Product #1"},
                new Product { ProductId = 2, CustomerName = "Product #2"}
            };

            var pageResult = new { result = products, total = 2 };
            mockProductRepository.Setup(repo => repo.GetPaginatedRecords(0, 500));

            var result = await controller.Get();
            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
        }

        [TestMethod]
        public async Task Get_returnsBadRequest_WhenExceptionOccurs() {

            mockProductRepository.Setup(repo => repo.GetPaginatedRecords(0, 500)).ThrowsAsync(new Exception("Simulated Exception!"));
            var result = await controller.Get();
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task GetById_ReturnsOk_WhenProductExist() {

            var product = new Product { ProductId = 1, CustomerName = "Test Product" };
            mockProductRepository.Setup(repo => repo.GetItem("1")).ReturnsAsync(product);
            var result = await controller.GetById(1);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            var okResult = result as OkObjectResult;
            Assert.AreEqual(product, okResult?.Value);
        }

        [TestMethod]
        public async Task GetById_ReturnsBadRequest_WhenProductNotFound()
        {
            mockProductRepository.Setup(repo => repo.GetItem("1")).ReturnsAsync((Product)null);

            var result = await controller.GetById(1);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task GetById_ReturnsBadRequest_WhenSqlExceptionOccurs() {
            mockProductRepository.Setup(repo => repo.GetItem("1")).ThrowsAsync(new Exception("Simulated SqlException"));

            var result = await controller.GetById(1);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        //[TestMethod]
        //public async Task GetCompressed_ReturnsOk_WhenRecordsAreCompressed() {

        //    var products = new List<Product>
        //    {
        //        new Product { ProductId = 1, CustomerName = "Product 1"}                
        //    };

        //    mockProductRepository.Setup(repo => repo.GetAll());
        //    var result = await controller.GetCompressed();

        //    Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            
        //    var okResult = result as OkObjectResult;
        //    var returnedProducts = okResult.Value as List<Product>;

        //    Assert.AreEqual(products.Count * 3, returnedProducts.Count);
        //}

        [TestMethod]
        public async Task GetCompressed_ReturnsBadRequest_WhenSqlExceptionOccurs() {

            mockProductRepository.Setup(repo => repo.GetAll()).ThrowsAsync(new Exception("Simulated SqlException"));
            var result = await controller.GetCompressed();
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task GetCompressed_ReturnsBadRequest_WhenGeneralExceptionOccurs()
        {

            mockProductRepository.Setup(repo => repo.GetAll()).ThrowsAsync(new Exception("Simulated General Exception"));
            var result = await controller.GetCompressed();
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        #endregion Test Get

    }

}