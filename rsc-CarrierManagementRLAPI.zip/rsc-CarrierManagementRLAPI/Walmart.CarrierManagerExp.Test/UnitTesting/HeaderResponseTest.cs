﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.SecureFtpClient;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class HeaderResponseTest : IHeaderResponse
    {
        int IHeaderResponse.ReturnedResults { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        HttpStatusCode IHeaderResponse.StatusCode { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        DateTime IHeaderResponse.Timestamp { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        int IHeaderResponse.TotalResults { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IHeaderResponse.Version { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        [TestMethod]
        public void HeaderResponse_ShouldInitializeCorrectly() {

            var header = new HeaderResponse
            {
                Version = "Test",
                StatusCode = HttpStatusCode.OK,
                TotalResults = 10,
                ReturnedResults = 10,
                Timestamp = DateTime.Now.AddDays(1)
            };
                        
            Assert.AreEqual("Test", header.Version);
            Assert.AreEqual(HttpStatusCode.OK, header.StatusCode);
            Assert.AreEqual(10, header.TotalResults);
            Assert.AreEqual(10, header.ReturnedResults);
            Assert.IsTrue(header.Timestamp > DateTime.Now);            
            
        }
    }
}
