﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class ReportResponseTest
    {
        [TestMethod]
        public void ReportResponse_ShouldInitializeCorrectly() {

            var reportResponse = new ReportResponse
            {
                CarrierIdentifier = "Carrier123",
                DocumentTypeDescription = "Test Document",
                ExpirationDate = DateTime.Now.AddDays(10),
                CarrierId = 5
            };

            
            Assert.AreEqual("Carrier123", reportResponse.CarrierIdentifier);
            Assert.AreEqual("Test Document", reportResponse.DocumentTypeDescription);
            Assert.IsTrue(reportResponse.ExpirationDate > DateTime.Now);
            Assert.AreEqual(5, reportResponse.CarrierId);
        }
    }
}
