﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Models;
using Walmart.Common.SecureFtpClient;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class BlobUploadRequestTest : IBlobUploadRequest, IBlobCredentials
    {     
        string IBlobCredentials.SftpHost { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        int IBlobCredentials.SftpPort { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobCredentials.SftpUserName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobCredentials.SftpSecret { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobCredentials.SftpShareFolder { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }        
        string IBlobUploadRequest.FileId { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        byte[] IBlobUploadRequest.File { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobUploadRequest.FileName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobUploadRequest.UserName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        bool IBlobUploadRequest.SensitiveData { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        [TestMethod]
        public void BlobUploadRequest_ShouldInitializeCorrectly()
        {

            var blobData = Encoding.UTF8.GetBytes("Test");
            
            var blobUpload = new BlobUploadRequest
            {
                FileId = "Test",
                File = blobData,
                FileName = "Test",
                UserName = "Test",
                SensitiveData = true,
                SftpHost = "localhost",
                SftpPort = 8080,
                SftpUserName = "Test",
                SftpSecret = "Test",
                SftpShareFolder = "Test",
                
            };

            Assert.AreEqual("Test", blobUpload.FileId);
            Assert.IsNotNull(blobUpload.File);
            Assert.AreEqual(blobData.Length, blobUpload.File.Length);
            Assert.AreEqual("Test", blobUpload.FileName);
            Assert.AreEqual("Test", blobUpload.UserName);
            Assert.AreEqual(true, blobUpload.SensitiveData);
            Assert.AreEqual("localhost", blobUpload.SftpHost);
            Assert.AreEqual(8080, blobUpload.SftpPort);
            Assert.AreEqual("Test", blobUpload.SftpUserName);
            Assert.AreEqual("Test", blobUpload.SftpSecret);
            Assert.AreEqual("Test", blobUpload.SftpShareFolder);

        }
    }
}
