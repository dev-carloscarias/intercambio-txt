﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class SqlResponseTest
    {
        [TestMethod]
        public void Pilot_ShouldInitializeCorrectly() {

            var sql = new SqlResponse
            {
                Error = true,
                ProcedureIntResponse = 1,
                ErrorMessage = "Test",
                ObjReponse = "Test",
            };
            
            Assert.AreEqual(true, sql.Error);
            Assert.AreEqual(1, sql.ProcedureIntResponse);
            Assert.AreEqual("Test", sql.ErrorMessage);
            Assert.AreEqual("Test", sql.ObjReponse);            
            
        }
    }
}
