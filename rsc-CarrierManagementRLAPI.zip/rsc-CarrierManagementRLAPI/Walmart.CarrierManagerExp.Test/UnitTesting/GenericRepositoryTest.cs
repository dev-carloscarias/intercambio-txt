﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Reflection.Metadata.Ecma335;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting    
{    
    public class FakeGenericRepository<T> : GenericRepository<T> where T : class, new()
    {

        private readonly IQueryable<T> _fakeRecords;
        private readonly T _fakeRecord;
        private readonly int _fakeTotal;
        //private readonly object _fakeScalar;
        //private readonly bool _fakeBool;

        public FakeGenericRepository(string connectionString, IQueryable<T> fakeRecords, int fakeTotal = 0) : base(connectionString)
        {
            _fakeRecords = fakeRecords;
            _fakeTotal = fakeTotal;
        }        

        public override T PopulateRecord(DbDataReader reader) { 
            var record = new T();
            var prop = typeof(T).GetProperty("Value");
            if (prop != null && reader["Value"] != null) {
                prop.SetValue(record, reader["Value"].ToString());
            }
            return record;
        }

        protected override async Task<IQueryable<T>> GetRecords(SqlCommand command)
        {
            return await Task.FromResult(_fakeRecords ?? new List<T>().AsQueryable());
        }
        public Task<IQueryable<T>> PublicGetRecords(SqlCommand command)
        {
            return GetRecords(command);
        }
        
        protected override async Task<(int total, IQueryable<T> result)> GetPagedRecords(SqlCommand command) {
            return await Task.FromResult((_fakeTotal, _fakeRecords ?? new List<T>().AsQueryable()));
        }

        public Task<(int total, IQueryable<T> result)> PublicGetPagedRecords(SqlCommand command) { 
            return GetPagedRecords(command);
        }

        //protected override async Task<T> GetRecord(SqlCommand command) {
        //    return await Task.FromResult(_fakeRecord);
        //}

        //public Task<T> PublicGetRecord(SqlCommand command) {
        //    return GetRecord(command);
        //}

        //protected override async Task<IQueryable<T>> ExecuteStoredProc(SqlCommand command) {
        //    return await Task.FromResult(_fakeRecords ?? new List<T>().AsQueryable());
        //}

        //protected override async Task<int> ExecuteCommand(SqlCommand command) { 
        //    return await Task.FromResult(_fakeInt);
        //}
        //protected override async Task<object> ExecuteFunction(SqlCommand command) {
        //    return await Task.FromResult(_fakeScalar);
        //}
        //protected override async Task<bool> ExecuteBulkCopy(BulkCopy command) {
        //    return await Task.FromResult(_fakeBool);
        //}
        //protected override async Task<bool> TestConnection() {
        //    return await Task.FromResult(true);
        //}
    }
    [TestClass]
    public class GenericRepositoryTest {

        private const string fakeconnectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";

        public class DummyRecord
        {
            public DummyRecord() { }
            public string Value { get; set; }
        }

        [TestMethod]
        public void ConnectionProperty_ReturnsValidSqlConnection() {
            var repo = new FakeGenericRepository<object>(fakeconnectionString, null);
            var connection = repo.Connection;
            Assert.IsNotNull(connection);            
        }

        [TestMethod]
        public async Task GetRecords_ReturnsFakeQueryable()
        {
            var rows = new List<Dictionary<string, object>>
            {
                new Dictionary<string, object>{ { "Value", "A"} },
                new Dictionary<string, object>{ { "Value", "B"} },
                new Dictionary<string, object>{ { "Value", "C"} }
            };

            var fakeList = new List<DummyRecord>
            {
                new DummyRecord{ Value = "A"},
                new DummyRecord{ Value = "B"},
                new DummyRecord{ Value = "C"}
            }.AsQueryable();

            var repo = new FakeGenericRepository<DummyRecord>(fakeconnectionString, fakeList);
            var command = new SqlCommand();
            var result = await repo.PublicGetRecords(command);

            Assert.IsNotNull(result);
            Assert.AreEqual(3, result.Count());
            CollectionAssert.AreEqual(fakeList.Select(r => r.Value).ToList(), result.Select(r=> r.Value).ToList());
        }

        [TestMethod]
        public async Task GetPagedRecords_ReturnsFakeTyple() {
            var fakeList = new List<DummyRecord>
            {
                new DummyRecord{ Value = "X"},
                new DummyRecord{ Value = "Y"}                
            }.AsQueryable();

            int expectedTotal = 10;
            var repo = new FakeGenericRepository<DummyRecord>(fakeconnectionString, fakeList, expectedTotal);
            var command = new SqlCommand();
            var (total, result) = await repo.PublicGetPagedRecords(command);

            Assert.AreEqual(expectedTotal, total);
            Assert.IsNotNull(result);
            Assert.AreEqual(fakeList.Count(), result.Count());
            CollectionAssert.AreEqual(fakeList.Select(r => r.Value).ToList(), result.Select(r => r.Value).ToList());
        }
    }
}
