﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Walmart.Common.Helpers;
using System.Globalization;
using System.Data;
using System.Reflection.Metadata.Ecma335;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class ListToDataTableConverterTest
    {
        [TestMethod]
        public void ShouldConvertLIstToDataTable()
        {

            var list = new List<TestEntity> {
                new TestEntity { Id = 1, Name = "Test1"},
                new TestEntity { Id = 2, Name = "Test2"}
            };

            DataTable result = ListToDataTableConverter.ClassListToDataTable(list);
            Assert.AreEqual(2, result.Rows.Count);
            //Assert.AreEqual(2, result.Columns.Count);
            Assert.AreEqual("Test1", result.Rows[0]["Name"]);
            Assert.AreEqual("Test2", result.Rows[1]["Name"]);

        }

        [TestMethod]
        public void ShouldCreateDataTable()
        {

            DataTable result = ListToDataTableConverter.CreateTable<TestEntity>();
            Assert.AreEqual(2, result.Columns.Count);
            Assert.IsTrue(result.Columns.Contains("Id"));
        }
    }
}