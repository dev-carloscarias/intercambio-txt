﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Walmart.Common.Helpers;


namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    public class PersonTest
    {
        public int Id { get; set; }
        public string Name { get; set; }        
    }

    public class TestEntityWithDisplayName {

        [DisplayName("CustomName")]
        public string Name { get; set; }
    }
    public class TestEntityIntConversion { 
    
        public int Id { get; set; }
    }

    [TestClass]
    public class SqlReadHelperTest
    {        
        [TestMethod]
        public void GetPopulateObject_ReturnsNewInstanceWithDefaultValues() {

            DbDataReader? reader = null;
            var result = SqlReaderHelper.GetPopulateObject<PersonTest>(reader);
            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Id);
            Assert.IsNull(result.Name);
        }

        [TestMethod]
        public void GetPopulateObjecto_ReturnsReaderWithNoColumns() { 
        
            DataTable dt = new DataTable();
            DbDataReader? reader = dt.CreateDataReader();

            var result = SqlReaderHelper.GetPopulateObject<PersonTest>(reader);
            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Id);
            Assert.IsNull(result.Name);

        }

        [TestMethod]
        public void GetPopulateObject_ReturnsValidReader() { 
        
            DataTable dt = new DataTable();
            dt.Columns.Add("Id", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            DataRow row = dt.NewRow();
            row["Id"] = 42;
            row["Name"] = "Test";
            dt.Rows.Add(row);
            DbDataReader reader = dt.CreateDataReader();
            reader.Read();            

            var result = SqlReaderHelper.GetPopulateObject<PersonTest>(reader);

            Assert.IsNotNull(result);
            Assert.AreEqual(42, result.Id);
            Assert.AreEqual("Test", result.Name);
        }

        [TestMethod]
        public void GetPopulateObject_WithDisplayName() { 
        
            DataTable dt = new DataTable();          
            dt.Columns.Add("CustomName", typeof(string));
            DataRow row = dt.NewRow();
            row["CustomName"] = "DisplayTest";
            dt.Rows.Add(row);
            DbDataReader reader = dt.CreateDataReader();
            reader.Read();

            var result = SqlReaderHelper.GetPopulateObject<TestEntityWithDisplayName>(reader);

            Assert.IsNotNull(result);
            Assert.AreEqual("DisplayTest", result.Name);
        }

        [TestMethod]
        public void GetPopulateObject_ConvertionStringToInt()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Id", typeof(string));
            DataRow row = dt.NewRow();
            row["Id"] = "123";
            dt.Rows.Add(row);
            DbDataReader reader = dt.CreateDataReader();
            reader.Read();

            var result = SqlReaderHelper.GetPopulateObject<TestEntityIntConversion>(reader);

            Assert.IsNotNull(result);
            Assert.AreEqual(123, result.Id);
        }

        [TestMethod]
        public void GetPopulateObject_DBNullValue()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Id", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            DataRow row = dt.NewRow();
            row["Id"] = DBNull.Value;
            row["Name"] = DBNull.Value;
            dt.Rows.Add(row);
            DbDataReader reader = dt.CreateDataReader();
            reader.Read();

            var result = SqlReaderHelper.GetPopulateObject<PersonTest>(reader);

            Assert.IsNotNull(result);
            Assert.AreEqual(0, result.Id);
            Assert.IsNull(result.Name);
        }
    }
}
