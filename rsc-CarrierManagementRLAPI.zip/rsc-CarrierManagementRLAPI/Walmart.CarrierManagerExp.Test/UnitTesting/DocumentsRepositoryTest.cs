﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.SqlClient;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    
    public class FakeDocumentRepository : DocumentsRepository { 
    
        public SqlCommand LastCommand { get; private set; }
        private readonly IQueryable<CarrierDocument> _fakeResult;
        private readonly int? _simulatedReturnValue;
        private readonly CarrierDocument _fakeRecord;

        public FakeDocumentRepository(string connectionString, IQueryable<CarrierDocument> fakeResult) : base(connectionString)
        {
            _fakeResult = fakeResult;
            _simulatedReturnValue = null;
            _fakeRecord = null;
        }

        public FakeDocumentRepository(string connectionString, int simulatedReturnValue) : base(connectionString) 
        {
            _simulatedReturnValue = simulatedReturnValue;
            _fakeResult = null;
            _fakeRecord = null;            
        }

        public FakeDocumentRepository(string connectionString, CarrierDocument fakeRecord) : base(connectionString)
        {
            _fakeRecord = fakeRecord;
            _simulatedReturnValue = null;
            _fakeResult = null;  
        }

        public FakeDocumentRepository(string connectionString, IQueryable<CarrierDocument> fakeResult, int simulatedReturnValue, CarrierDocument fakeRecord) : base(connectionString) 
        { 
            _fakeResult = fakeResult;
            _simulatedReturnValue = simulatedReturnValue;
            _fakeRecord = fakeRecord;
        }


        protected override async Task<IQueryable<CarrierDocument>> GetRecords(SqlCommand command) { 
        
            LastCommand = command;
            if(_fakeResult != null)
                return await Task.FromResult(_fakeResult);
            else
                return await Task.FromResult(new List<CarrierDocument>().AsQueryable());
        }

        protected override async Task<CarrierDocument> GetRecord(SqlCommand command) { 
        
            LastCommand = command;
            return await Task.FromResult(_fakeRecord);
        }

        protected override async Task<int> ExecuteCommand(SqlCommand command) {
            LastCommand = command;
            if (_simulatedReturnValue.HasValue) {
                command.Parameters["@result"].Value = _simulatedReturnValue.Value;
                return await Task.FromResult(_simulatedReturnValue.Value);
            }
            return await Task.FromResult(0);
            
        }
    }

    [TestClass]
    public class DocumentsRepositoryTest
    {
        private const string connectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";        

        [TestMethod]
        public async Task GetItems_WithDefaultParameters_ShouldNotAddParameters() {
            
            var fakeResult = new List<CarrierDocument> ().AsQueryable();
            var repo = new FakeDocumentRepository(connectionString, fakeResult);
            var result = await repo.GetItems();

            Assert.IsNotNull(repo.LastCommand, "El comando no debe ser nulo.");
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType, "El CommandType debe ser StoredProcedure.");
            Assert.AreEqual(ConstantsHelper.GetDocumentSP, repo.LastCommand.CommandText, "El CommandText debe coincidir con el SP definido.");
            Assert.AreEqual(0, repo.LastCommand.Parameters.Count, "No se debe agregar parámetros cuando se usan valores por defecto.");
            Assert.AreEqual(fakeResult, result, "EL resultado debe ser el dummy  (fakeResult).");
            
        }
        [TestMethod]
        public async Task GetItems_WithNonDefaultParameters_ShouldAddAppropiateParameters() {

            var fakeRecordaux = new CarrierDocument { CarrierDocumentId = 10, CarrierId = 20 };
            var fakeResult = new List<CarrierDocument>() { fakeRecordaux }.AsQueryable();
            var repo = new FakeDocumentRepository(connectionString, fakeResult);

            int id = 1;
            int countryId = 2;
            int carrierId = 3;
            int documentTypeId = 4;
            string documenTypeDescription = "Test";

            var result = await repo.GetItems(id, countryId, carrierId, documentTypeId, documenTypeDescription);
            Assert.IsNotNull(repo.LastCommand, "El comando no debe ser nulo.");
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType, "El CommandType debe ser StoredProcedure.");
            Assert.AreEqual(ConstantsHelper.GetDocumentSP, repo.LastCommand.CommandText, "El CommandText debe coincidir con el SP definido.");

            Assert.AreEqual(5, repo.LastCommand.Parameters.Count, "Se debe agregar 5 parametros.");

            AssertParameter(repo.LastCommand, "@DocumentId", id);
            AssertParameter(repo.LastCommand, "@CountryId", countryId);
            AssertParameter(repo.LastCommand, "@CarrierId", carrierId);
            AssertParameter(repo.LastCommand, "@DocumentTypeId", documentTypeId);
            AssertParameter(repo.LastCommand, "@DocumentTypeDescription", documenTypeDescription);

            Assert.AreEqual(fakeResult, result, "El resultado debe ser el dummy (fakeResult).");
        }        

        [TestMethod]
        public async Task Add_ShouldReturnSimulatedValueAndConfigureCommandProperly() {
            var document = new CarrierDocument
            {
                CarrierId = 123,
                DocumentTypeId = 456,
                CarrierIdV = 0,
                CarrierIdF = null,
                CarrierIdP = 789,
                ExpirationDate = new DateTime(2025, 3, 1),
                TokenFileShare = "Test",
                ActionUser = "Test",
                CarrierDocumentEmail = "Test",
                CountryId = 901
            };

            var repo = new FakeDocumentRepository(connectionString, simulatedReturnValue: 1);
            var result = await repo.Add(document);
            Assert.AreEqual(1, result);
            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.InsertDocumentSP, repo.LastCommand.CommandText);

            AssertParameter(repo.LastCommand, "@Carrierd_ID_Transportista", document.CarrierId);
            AssertParameter(repo.LastCommand, "@Carrierd_Carrierdt_Id", document.DocumentTypeId);
            AssertParameter(repo.LastCommand, "@Carrierd_ID_TransportistaV", DBNull.Value);
            AssertParameter(repo.LastCommand, "@Carrierd_ID_TransportistaF", DBNull.Value);
            AssertParameter(repo.LastCommand, "@Carrierd_ID_TransportistaP", document.CarrierIdP);
            AssertParameter(repo.LastCommand, "@Carrierd_Expiration_Date", document.ExpirationDate);
            AssertParameter(repo.LastCommand, "@Carrierd_Token_FileShare", document.TokenFileShare);
            AssertParameter(repo.LastCommand, "@DocumentCreatoruser", document.ActionUser);
            AssertParameter(repo.LastCommand, "@Carrierd_Email", document.CarrierDocumentEmail);
            AssertParameter(repo.LastCommand, "@CountryId", document.CountryId);
            AssertParameter(repo.LastCommand, "@result", 1);
        }

        [TestMethod]
        public async Task GetBy_ShouldReturnFakeRecordAndConfigureCommandProperty() {

            var fakeRecordaux = new CarrierDocument 
            {
                CarrierId = 123,
                DocumentTypeId = 456,
                CarrierIdV = 0,
                CarrierIdF = null,
                CarrierIdP = 789,
                ExpirationDate = new DateTime(2025, 3, 1),
                TokenFileShare = "Test",
                ActionUser = "Test",
                CarrierDocumentEmail = "Test",
                CountryId = 901
            };
            var repo = new FakeDocumentRepository(connectionString, fakeRecordaux);

            int testCarrierId = 123;
            var result = await repo.GetById(testCarrierId);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetDocumentSP, repo.LastCommand.CommandText);
            Assert.AreEqual(1, repo.LastCommand.Parameters.Count);
            AssertParameter(repo.LastCommand, "@DocumentId", testCarrierId);
            Assert.AreEqual(fakeRecordaux, result);
        }

        [TestMethod]
        public async Task Update_ShouldReturnSimulatedValueAndConfigureCommandProperly()
        {
            var document = new CarrierDocument
            {
                CarrierDocumentId = 001,                
                DocumentTypeId = 456,                
                ExpirationDate = new DateTime(2025, 3, 2),
                TokenFileShare = "Test",
                ActionUser = "Test",                
                CountryId = 901
            };

            var repo = new FakeDocumentRepository(connectionString, simulatedReturnValue: 1);
            var result = await repo.Update(document);
            Assert.AreEqual(1, result);
            Assert.IsNotNull(repo.LastCommand);

            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.UpdateDocumentSP, repo.LastCommand.CommandText);

            AssertParameter(repo.LastCommand, "@CarrierdId", document.CarrierDocumentId);
            AssertParameter(repo.LastCommand, "@ExpirationDate", document.ExpirationDate);
            AssertParameter(repo.LastCommand, "@TokenFileShare", document.TokenFileShare);
            AssertParameter(repo.LastCommand, "@DocumentLastUserUpdate", document.ActionUser);
            AssertParameter(repo.LastCommand, "@CountryId", document.CountryId);
            AssertParameter(repo.LastCommand, "@DocumentTypeId", document.DocumentTypeId);
            AssertParameter(repo.LastCommand, "@result", 1);
        }

        [TestMethod]
        public async Task GetByTokenFileShare_ShouldReturnFakeRecord() {

            var fakeRecord = new CarrierDocument
            {
                CarrierDocumentId = 100,
                TokenFileShare = "Test"
            };

            var repo = new FakeDocumentRepository(connectionString, fakeRecord);
            string testToken = "TestToken";
            var result = await repo.GetByTokenFileShare(testToken);
            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetDocumentSP, repo.LastCommand.CommandText);
            Assert.AreEqual(1, repo.LastCommand.Parameters.Count);
            AssertParameter(repo.LastCommand, "@TokenFileShare", testToken);
            Assert.AreEqual(fakeRecord, result);
        }        

        private void AssertParameter(SqlCommand command, string paramName, object expectedValue)
        {

            Assert.IsTrue(command.Parameters.Contains(paramName), $"El parámetro {paramName} debe existir");
            var param = command.Parameters[paramName];
            if (expectedValue == DBNull.Value)
                Assert.AreEqual(DBNull.Value, param.Value);
            else
                Assert.AreEqual(expectedValue, param.Value);
        }
    }
}
