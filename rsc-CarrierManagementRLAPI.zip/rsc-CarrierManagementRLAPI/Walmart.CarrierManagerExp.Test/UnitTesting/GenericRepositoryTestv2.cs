﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.SqlClient;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    
    public class FakeGenericRepository : GenericRepository
    {

        public SqlCommand LastCommand { get; private set; }
        private readonly IQueryable<GenericCarrier> _fakeResult;
        private readonly int? _simulatedReturnValue;
        private readonly GenericCarrier _fakeRecord;

        public FakeGenericRepository(string connectionString) : base(connectionString)
        {
            _fakeResult = null;
            _simulatedReturnValue = null;
            _fakeRecord = null;
        }

        public FakeGenericRepository(string connectionString, IQueryable<GenericCarrier> fakeResult) : base(connectionString)
        {
            _fakeResult = fakeResult;
            _simulatedReturnValue = null;
            _fakeRecord = null;
        }

        public FakeGenericRepository(string connectionString, int simulatedReturnValue) : base(connectionString)
        {
            _simulatedReturnValue = simulatedReturnValue;
            _fakeResult = null;
            _fakeRecord = null;
        }

        public FakeGenericRepository(string connectionString, GenericCarrier fakeRecord) : base(connectionString)
        {
            _fakeRecord = fakeRecord;
            _simulatedReturnValue = null;
            _fakeResult = null;
        }

        public FakeGenericRepository(string connectionString, IQueryable<GenericCarrier> fakeResult, int simulatedReturnValue, GenericCarrier fakeRecord) : base(connectionString)
        {
            _fakeResult = fakeResult;
            _simulatedReturnValue = simulatedReturnValue;
            _fakeRecord = fakeRecord;
        }        

        protected override async Task<GenericCarrier> GetRecord(SqlCommand command)
        {

            LastCommand = command;
            return await Task.FromResult(_fakeRecord);
        }

        protected override async Task<IQueryable<GenericCarrier>> ExecuteStoredProc(SqlCommand command)
        {
            LastCommand = command;
            if (_fakeResult != null)
                return await Task.FromResult(_fakeResult);
            else
                return await Task.FromResult(new List<GenericCarrier>().AsQueryable());
        }

        protected override async Task<int> ExecuteCommand(SqlCommand command)
        {
            LastCommand = command;
            if (_simulatedReturnValue.HasValue)
            {
                command.Parameters["@result"].Value = _simulatedReturnValue.Value;
                return await Task.FromResult(_simulatedReturnValue.Value);
            }
            return await Task.FromResult(0);

        }
    }

    [TestClass]
    public class FakeGenericRepositoryTest
    {
        private const string connectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";        

        [TestMethod]
        public async Task GetItem_ShouldBeOk() {

            var fakeRecordaux = new GenericCarrier
            {
                Code = "Test",
                CarrierCode = "Test"                
            };
            var repo = new FakeGenericRepository(connectionString, fakeRecordaux);

            string identifier = "123";
            var result = await repo.GetItem(identifier);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetGenericCarrierSP, repo.LastCommand.CommandText);
            Assert.AreEqual(1, repo.LastCommand.Parameters.Count);
            AssertParameter(repo.LastCommand, "@identifier", identifier);
            Assert.AreEqual(fakeRecordaux, result);
        }

        [TestMethod]
        public void GetIdentifier_ShouldReturnCorectLInkedIds()
        {
            var document = new CarrierDocument
            {
                CarrierId = 1,
                CarrierIdV = 0,
                CarrierIdF = 0,
                CarrierIdP = 0,
            };
            var repo = new FakeGenericRepository(connectionString);            
            var result = repo.GetIdentifier(document);
                                                
            Assert.AreEqual("1T", result);
        }

        [TestMethod]
        public void GetIdentifier_ShouldReturnCorectLInkedIdsV2()
        {
            var document = new CarrierDocument
            {
                CarrierId = 1,
                CarrierIdV = 2,
                CarrierIdF = 0,
                CarrierIdP = 0,
            };
            var repo = new FakeGenericRepository(connectionString);
            var result = repo.GetIdentifier(document);

            Assert.AreEqual("12V", result);
        }

        [TestMethod]
        public void GetIdentifier_ShouldReturnCorectLInkedIdsV3()
        {
            var document = new CarrierDocument
            {
                CarrierId = 1,
                CarrierIdV = 0,
                CarrierIdF = 3,
                CarrierIdP = 0,
            };
            var repo = new FakeGenericRepository(connectionString);
            var result = repo.GetIdentifier(document);

            Assert.AreEqual("13F", result);
        }

        [TestMethod]
        public void GetIdentifier_ShouldReturnCorectLInkedIdsV4()
        {
            var document = new CarrierDocument
            {
                CarrierId = 1,
                CarrierIdV = 0,
                CarrierIdF = 0,
                CarrierIdP = 4,
            };
            var repo = new FakeGenericRepository(connectionString);
            var result = repo.GetIdentifier(document);

            Assert.AreEqual("14P", result);
        }

        private void AssertParameter(SqlCommand command, string paramName, object expectedValue)
        {

            Assert.IsTrue(command.Parameters.Contains(paramName), $"El parámetro {paramName} debe existir");
            var param = command.Parameters[paramName];
            if (expectedValue == DBNull.Value)
                Assert.AreEqual(DBNull.Value, param.Value);
            else
                Assert.AreEqual(expectedValue, param.Value);
        }
    }
}
