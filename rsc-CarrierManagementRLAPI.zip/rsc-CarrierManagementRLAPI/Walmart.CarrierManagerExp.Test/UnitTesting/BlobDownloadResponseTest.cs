﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.SecureFtpClient;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class BlobUploadResponseTest : IBlobUploadResponse
    {
        string IBlobUploadResponse.FileId { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        bool IBlobUploadResponse.Success { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobUploadResponse.Messages { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        [TestMethod]
        public void BlobUploadResponse_ShouldInitializeCorrectly() {

            var blobUpload = new BlobUploadResponse
            {
                FileId = "Test",
                Success = true,
                Messages = "Test"
            };
                        
            Assert.AreEqual("Test", blobUpload.FileId);
            Assert.AreEqual("Test", blobUpload.Messages);
            Assert.AreEqual(true, blobUpload.Success);            
            
        }
    }
}
