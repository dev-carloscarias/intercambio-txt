﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Helpers;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class TokenConfigurationTest: ITokenConfiguration
    {
        string ITokenConfiguration.STSTokenEndpoint { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string ITokenConfiguration.ClientId { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string ITokenConfiguration.ClientSecret { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string ITokenConfiguration.ImageUserInfoPath { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        [TestMethod]
        public void TokenConfiguration_ShouldInitializeCorrectly() {

            var token = new TokenConfiguration
            {
                STSTokenEndpoint = "Test",
                ClientId = "Test",
                ClientSecret = "Test",
                ImageUserInfoPath = "Test",
            };
                        
            Assert.AreEqual("Test", token.STSTokenEndpoint);
            Assert.AreEqual("Test", token.ClientId);
            Assert.AreEqual("Test", token.ClientSecret);
            Assert.AreEqual("Test", token.ImageUserInfoPath);

        }
    }
}
