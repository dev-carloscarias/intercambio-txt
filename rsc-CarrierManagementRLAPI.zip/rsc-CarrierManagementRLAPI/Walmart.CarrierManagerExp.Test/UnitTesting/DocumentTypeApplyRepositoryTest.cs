﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.SqlClient;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    
    public class FakeDocumentTypeApplyRepository : DocumentTypeApplyRepository
    { 
    
        public SqlCommand LastCommand { get; private set; }
        private readonly IQueryable<DocumentTypeApply> _fakeResult;               

        public FakeDocumentTypeApplyRepository(string connectionString, IQueryable<DocumentTypeApply> fakeResult) : base(connectionString)
        {
            _fakeResult = fakeResult;            
        }                        

        protected override async Task<IQueryable<DocumentTypeApply>> GetRecords(SqlCommand command) { 
        
            LastCommand = command;
            if(_fakeResult != null)
                return await Task.FromResult(_fakeResult);
            else
                return await Task.FromResult(new List<DocumentTypeApply>().AsQueryable());
        }                
    }

    [TestClass]
    public class DocumentTypeApplyRepositoryTest
    {
        private const string connectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";        

        [TestMethod]
        public async Task GetItems_WithDefaultParameters_ShouldNotAddParameters() {
            
            var fakeResult = new List<DocumentTypeApply> ().AsQueryable();
            var repo = new FakeDocumentTypeApplyRepository(connectionString, fakeResult);
            var result = await repo.GetItems();

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.CarrierTypeApplySP, repo.LastCommand.CommandText);
            Assert.AreEqual(0, repo.LastCommand.Parameters.Count);
            Assert.AreEqual(fakeResult, result);
            
        }
        [TestMethod]
        public async Task GetItems_WithNonDefaultParameters_ShouldAddAppropiateParameters()
        {
            var fakeRecordaux = new DocumentTypeApply { DocumentTypeApplyId = 10, DocumentTypeApplyName = "Test", DocumentTypeApplyNameEn = "Test" };
            var fakeResult = new List<DocumentTypeApply>() { fakeRecordaux }.AsQueryable();
            var repo = new FakeDocumentTypeApplyRepository(connectionString, fakeResult);

            int id = 1;
            string applyTo = "Test";
            string applyToEn = "Test";
            bool active = true;

            var result = await repo.GetItems(id, applyTo, applyToEn, active);
            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.CarrierTypeApplySP, repo.LastCommand.CommandText);

            Assert.AreEqual(4, repo.LastCommand.Parameters.Count);

            AssertParameter(repo.LastCommand, "@Carrier_Doc_Type_Apply_Id", id);
            AssertParameter(repo.LastCommand, "@Carrier_Doc_Type_Apply_Name", applyTo);
            AssertParameter(repo.LastCommand, "@Carrier_Doc_Type_Apply_Name_En", applyToEn);
            AssertParameter(repo.LastCommand, "@Carrier_Doc_Type_Apply_Active", active);           

            Assert.AreEqual(fakeResult, result);
        }

        private void AssertParameter(SqlCommand command, string paramName, object expectedValue)
        {

            Assert.IsTrue(command.Parameters.Contains(paramName));
            var param = command.Parameters[paramName];
            if (expectedValue == DBNull.Value)
                Assert.AreEqual(DBNull.Value, param.Value);
            else
                Assert.AreEqual(expectedValue, param.Value);
        }
    }
}
