﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Walmart.Common.Helpers;
using System.Globalization;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class ErrorMessageManagementTest
    {        
        [TestMethod]
        public void SetsErrorMessages_ReturnsModelStateDictionary_WithUserMessage() {

            string userMessage = "Test User Message";
            
            ModelStateDictionary result = ErrorMessageManagement.SetsErrorMessages(userMessage);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.ContainsKey("userMessage"));
            Assert.AreEqual(userMessage, result["userMessage"]?.Errors[0].ErrorMessage);
        }

        [TestMethod]
        public void SetsErrorMessages_ReturnsModelStateDictionary_WithAllMessages()
        {

            string userMessage = "Test User Message";
            string exceptionMessage = "Test exception Message";
            string helpLink = "Test HelpLink";
            ModelStateDictionary result = ErrorMessageManagement.SetsErrorMessages(userMessage, exceptionMessage, helpLink);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.ContainsKey("userMessage"));
            Assert.AreEqual(userMessage, result["userMessage"]?.Errors[0].ErrorMessage);
        }

        [TestMethod]
        public void SetsErrorMessages_ReturnsModelStateDictionary_WithAllMessagesv4()
        {

            string userMessage = "Test User Message";
            string exceptionMessage = "Test exception Message";
            int errorCode = 500;

            ModelStateDictionary result = ErrorMessageManagement.SetsErrorMessages(userMessage, exceptionMessage, errorCode);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.ContainsKey("userMessage"));
            Assert.AreEqual(userMessage, result["userMessage"]?.Errors[0].ErrorMessage);
        }

        [TestMethod]
        public void SetsErrorMessages_ReturnsModelStateDictionary_WithMessagesv2()
        {

            string userMessage = "Test User Message";
            string exceptionMessage = "Test exception Message";
            string helpLink = "Test HelpLink";
            var testObject = new { id = 1, Name = "Test" };
            ModelStateDictionary result = ErrorMessageManagement.SetsErrorMessages(userMessage, exceptionMessage, helpLink, testObject);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.ContainsKey("userMessage"));
            Assert.AreEqual(userMessage, result["userMessage"]?.Errors[0].ErrorMessage);
        }

        [TestMethod]
        public void SetErrorMessage_ReturnsModelStateDictionary_WithGenericObject() {

            string userMessage = "Test User Message";
            var testObject = new { id = 1, Name = "Test" };
            ModelStateDictionary result = ErrorMessageManagement.SetsErrorMessages(userMessage, testObject);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.ContainsKey("userMessage"));
            Assert.AreEqual(userMessage, result["userMessage"]?.Errors[0].ErrorMessage);
        }

        [TestMethod]
        public void SetErrorMessage_ReturnsModelStateDictionary_WithGenericObjectIsNll()
        {

            string userMessage = "Test User Message";            
            ModelStateDictionary result = ErrorMessageManagement.SetsErrorMessages<Object>(userMessage, null);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.ContainsKey("userMessage"));
            Assert.AreEqual(userMessage, result["userMessage"]?.Errors[0].ErrorMessage);
        }


        [TestMethod]
        public void SetErrorMessages_ShouldReturnModelStateDictionary_WithCorrectErrors() {

            string userMessage = "Test User Message";
            var testObject = new { id = 1, Name = "Test" };
            int errorCode = 500;

            ModelStateDictionary result = ErrorMessageManagement.SetsErrorMessages(userMessage, errorCode, testObject);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.ContainsKey("userMessage"));
            Assert.AreEqual(userMessage, result["userMessage"]?.Errors[0].ErrorMessage);
        }

        [TestMethod]
        public void SetErrorMessages_ShouldReturnModelStateDictionary_WithCorrectErrorsV3()
        {

            string userMessage = "Test User Message";
            var testObject = new { id = 1, Name = "Test" };
            int errorCode = 500;
            string helpLink = "Test HelpLink";
            string exceptionMessage = "Test ExceptionMessage";


            ModelStateDictionary result = ErrorMessageManagement.SetsErrorMessages(userMessage, exceptionMessage, helpLink, errorCode);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.ContainsKey("userMessage"));
            Assert.AreEqual(userMessage, result["userMessage"]?.Errors[0].ErrorMessage);
        }

        [TestMethod]
        public void SetErrorMessages_ShouldReturnModelStateDictionary_WithExceptionMessageErrors()
        {

            string userMessage = "Test User Message";
            var testObject = new { id = 1, Name = "Test" };
            string exceptionMessage = "InternalError";

            ModelStateDictionary result = ErrorMessageManagement.SetsErrorMessages(userMessage, exceptionMessage,0, testObject);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.ContainsKey("userMessage"));
            Assert.AreEqual(userMessage, result["userMessage"]?.Errors[0].ErrorMessage);
        }
    }
}
