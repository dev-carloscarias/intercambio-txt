﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Models;
using Walmart.Common.SecureFtpClient;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class BlobDownloadRequestTest: IBlobDownloadRequest, IBlobCredentials
    {
        string IBlobDownloadRequest.FileId { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobCredentials.SftpHost { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        int IBlobCredentials.SftpPort { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobCredentials.SftpUserName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobCredentials.SftpSecret { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IBlobCredentials.SftpShareFolder { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        [TestMethod]
        public void blobDownloadRequest_ShouldInitializeCorrectly() {

            var blobDownload = new BlobDownloadRequest
            {
                FileId = "Test",
                SftpHost  = "Test",
                SftpPort = 1,
                SftpUserName = "Test",
                SftpSecret = "Test",
                SftpShareFolder = "Test",

            };
                        
            Assert.AreEqual("Test", blobDownload.FileId);
            Assert.AreEqual("Test", blobDownload.SftpHost);
            Assert.AreEqual(1, blobDownload.SftpPort);
            Assert.AreEqual("Test", blobDownload.SftpUserName);
            Assert.AreEqual("Test", blobDownload.SftpSecret);
            Assert.AreEqual("Test", blobDownload.SftpShareFolder);

        }
    }
}
