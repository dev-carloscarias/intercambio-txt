﻿using Elasticsearch.Net;
using log4net.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NuGet.Frameworks;
using System.Configuration.Internal;
using System.Net;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Models;
using Walmart.Common.SecureFtpClient;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class WebApiResponseTest
    {                   

        [TestMethod]
        public void ModelsHeaderResponse_ShouldInitializeCorrectly() {

            var webapi = new WebApiResponse
            {
                Results = "Test",
                Errors = new ErrorMessages
                { 
                    Code = 404,
                    UserMessage = "Test",
                    InternalMessage = "Not Found",
                    Link = "Test"
                },
                Header = new Common.Models.HeaderResponse
                {
                    Version = "Test",
                    StatusCode = HttpStatusCode.OK,
                    TotalResults = 1,
                    ReturnedResults = 1,
                    Timestamp = DateTime.Now.AddDays(5),
                }
            };


            Assert.AreEqual("Test", webapi.Results);

            //Testing ErrorMessages
            Assert.AreEqual(404, webapi.Errors.Code);
            Assert.AreEqual("Test", webapi.Errors.UserMessage);
            Assert.AreEqual("Not Found", webapi.Errors.InternalMessage);
            Assert.AreEqual("Test", webapi.Errors.Link);

            //Testing Headers
            Assert.AreEqual("Test", webapi.Header.Version);
            Assert.AreEqual(HttpStatusCode.OK, webapi.Header.StatusCode);
            Assert.AreEqual(1, webapi.Header.TotalResults);
            Assert.AreEqual(1, webapi.Header.ReturnedResults);
            Assert.IsTrue(webapi.Header.Timestamp > DateTime.Now);
        }
    }
}
