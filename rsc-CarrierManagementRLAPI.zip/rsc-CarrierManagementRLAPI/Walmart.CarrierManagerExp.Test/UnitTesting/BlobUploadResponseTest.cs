﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.SecureFtpClient;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class BlobloadResponseTest :  BlobUploadResponse, IBlobUploadResponse
    {
        
        string IBlobUploadResponse.Messages { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        [TestMethod]
        public void BlobDownLoadResponse_ShouldInitializeCorrectly()
        {

            var blobData = Encoding.UTF8.GetBytes("Test");
            var blobDown = new BlobDownloadResponse
            {
                FileId = "Test",
                BlobStream = blobData,
                BlobFileName = "Test",
                Success = true,
                Messages = "Test"
            };

            Assert.AreEqual("Test", blobDown.FileId);
            Assert.IsNotNull(blobDown.BlobStream);
            Assert.AreEqual(blobData.Length, blobDown.BlobStream.Length);
            Assert.AreEqual("Test", blobDown.BlobFileName);
            Assert.AreEqual(true, blobDown.Success);
            Assert.AreEqual("Test", blobDown.Messages);

        }
    }
}
