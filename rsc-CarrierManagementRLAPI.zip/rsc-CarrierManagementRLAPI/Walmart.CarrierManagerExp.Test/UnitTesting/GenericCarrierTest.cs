﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class GenericCarrierTest
    {
        [TestMethod]
        public void GenericCarrier_ShouldInitializeCorrectly() {

            var genericCarrier = new GenericCarrier
            {
                Identifier = "1234",                
                CarrierCode = "Test",
                CarrierName = "Test",
                Code = "Test",
                Description = "Test",
                CarrierEmail = "Test",                
            };
            
            Assert.AreEqual("1234", genericCarrier.Identifier);
            Assert.AreEqual("Test", genericCarrier.CarrierCode);
            Assert.AreEqual("Test", genericCarrier.CarrierName);
            Assert.AreEqual("Test", genericCarrier.CarrierName);
            Assert.AreEqual("Test", genericCarrier.Code);
            Assert.AreEqual("Test", genericCarrier.Description);
            Assert.AreEqual("Test", genericCarrier.CarrierEmail);
            
        }
    }
}
