﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class CarrierDocumentTest
    {
        [TestMethod]
        public void CarrierDocument_ShouldInitializeCorrectly() {

            var carrierDocument = new CarrierDocument
            {
                CarrierDocumentId = 1001,
                CarrierId = 10,
                DocumentTypeId = 20,
                CarrierIdV = 30,
                CarrierIdF = 40,
                CarrierIdP = 50,
                ExpirationDate = DateTime.Now.AddDays(10),
                NotificationDate = DateTime.Now.AddDays(5),
                TokenFileShare = "Test_Token",
                Active = true,
                CarrierDocumentEmail = "test@test.com",
                CreationDate = DateTime.Now,
                IsApprove = 1,
                StatusDocument = "Approved",
                ActionUser = "Test ActionUser",
                LiteralActive = "Test LiteralActive",
                LiteralCarrier = "Test LiteralCarrier",
                LiteralTransports = "Test LiteralTransports",
                LiteralUnitBoxCar = "Test LiteralUnitBoxCar",
                LiteralUnit = "Test LiteralUnit",
                LiteralBoxCar = "Test LiteralBoxCar",
                LiteralPilot = "Test LiteralPilot",
                LiteralExpirationDate = "Test LiteralExpirationDate",
                LiteralNotificationDate = "Test LiteralNotificationDate",
                LiteralCreationDate = "Test LiteralCreationDate",

            };

            Assert.AreEqual(1001, carrierDocument.CarrierDocumentId);
            Assert.AreEqual(10, carrierDocument.CarrierId);
            Assert.AreEqual(20, carrierDocument.DocumentTypeId);
            Assert.AreEqual(30, carrierDocument.CarrierIdV);
            Assert.AreEqual(40, carrierDocument.CarrierIdF);
            Assert.AreEqual(50, carrierDocument.CarrierIdP);
            Assert.IsTrue(carrierDocument.ExpirationDate > DateTime.Now);
            Assert.IsTrue(carrierDocument.NotificationDate > DateTime.Now);
            Assert.AreEqual("Test_Token", carrierDocument.TokenFileShare);
            Assert.AreEqual("test@test.com", carrierDocument.CarrierDocumentEmail);
            Assert.AreEqual(true, carrierDocument.Active);
            Assert.AreEqual("Approved", carrierDocument.StatusDocument);
            Assert.AreEqual("Test ActionUser", carrierDocument.ActionUser);
            Assert.AreEqual("Test LiteralActive", carrierDocument.LiteralActive);
            Assert.AreEqual("Test LiteralCarrier", carrierDocument.LiteralCarrier);
            Assert.AreEqual("Test LiteralTransports", carrierDocument.LiteralTransports);
            Assert.AreEqual("Test LiteralUnitBoxCar", carrierDocument.LiteralUnitBoxCar);
            Assert.AreEqual("Test LiteralUnit", carrierDocument.LiteralUnit);
            Assert.AreEqual("Test LiteralBoxCar", carrierDocument.LiteralBoxCar);
            Assert.AreEqual("Test LiteralPilot", carrierDocument.LiteralPilot);
            Assert.AreEqual("Test LiteralExpirationDate", carrierDocument.LiteralExpirationDate);
            Assert.AreEqual("Test LiteralNotificationDate", carrierDocument.LiteralNotificationDate);
            Assert.AreEqual("Test LiteralCreationDate", carrierDocument.LiteralCreationDate);


        }
    }
}
