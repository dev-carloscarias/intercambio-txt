﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Models;
using Walmart.Common.SecureFtpClient;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class ErrorMessagesTest : IErrorMessages
    {        
        int IErrorMessages.Code { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IErrorMessages.UserMessage { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IErrorMessages.Link { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        string IErrorMessages.InternalMessage { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        [TestMethod]
        public void HeaderResponse_ShouldInitializeCorrectly() {

            var errorMessage = new ErrorMessages
            {
                Code = 404,
                UserMessage = "Test",
                InternalMessage = "Test",
                Link = "Test"
            };
                        
            Assert.AreEqual(404, errorMessage.Code);
            Assert.AreEqual("Test", errorMessage.UserMessage);
            Assert.AreEqual("Test", errorMessage.InternalMessage);
            Assert.AreEqual("Test", errorMessage.Link);

        }
    }
}
