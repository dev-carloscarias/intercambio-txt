﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class CountryTest
    {
        [TestMethod]
        public void Pilot_ShouldInitializeCorrectly() {

            var country = new Country
            {
                Id = 1,
                CountryName = "Test",
                CountryIsoCode = 1,
                CountryAlpha2 = "Test",
                CountryAlpha3 = "Test",
                CountryCurrencyCode = "Test",
                CountryStatus = true
            };
                        
            Assert.AreEqual(1, country.Id);
            Assert.AreEqual("Test", country.CountryName);
            Assert.AreEqual("Test", country.CountryAlpha2);
            Assert.AreEqual("Test", country.CountryAlpha3);
            Assert.AreEqual("Test", country.CountryCurrencyCode);
            Assert.AreEqual(true, country.CountryStatus);
        }
    }
}
