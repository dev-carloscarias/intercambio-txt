﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.CarrierManagerExp.Api.V1;


namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class AuditTrailControllerTest
    {
        private Mock<IAuditTrailRepository> mockAuditTrailRepository;
        private Mock<ILogger<ProductsWTController>> mockLogger;
        private AuditTrailController controller;

        [TestInitialize]
        public void Setup()
        {
            mockAuditTrailRepository = new Mock<IAuditTrailRepository>();
            mockLogger = new Mock<ILogger<ProductsWTController>>();
            controller = new AuditTrailController(mockAuditTrailRepository.Object, mockLogger.Object);
        }

        #region Test Get

        //[TestMethod]
        //public async Task Get_ReturnsOk_WhenRecordsExist() { 
            
        //}
        #endregion Test Get

        #region Test Post
        [TestMethod]
        public async Task Post_ReturnsBadRequest_WhenModelsStateIsInvalid() {
            controller.ModelState.AddModelError("Name", "The Name field is requiered.");
            var audit = new AuditTrail { AuditTrailId = 1, AuditTrailUserId = "Test UserId" };
            var result = await controller.Post(audit);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Post_ReturnsOkResult_WhenAuditIsAdded()
        {
            var audit = new AuditTrail { AuditTrailId = 1, AuditTrailUserId = "Test UserId" };
            mockAuditTrailRepository.Setup(repo => repo.Add(audit)).ReturnsAsync(1);

            var result = await controller.Post(audit);

            Assert.IsInstanceOfType(result, typeof(OkObjectResult));
            var okResult = result as OkObjectResult;
            Assert.AreEqual(1, okResult?.Value);
        }

        [TestMethod]
        public async Task Post_ReturnedBadRequest_WhenAddFails()
        {
            var audit = new AuditTrail { AuditTrailId = 1, AuditTrailUserId = "Test UserId" };
            mockAuditTrailRepository.Setup(repo => repo.Add(audit)).ReturnsAsync(0);

            var result = await controller.Post(audit);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }

        [TestMethod]
        public async Task Post_ReturnsBadRequest_WhenSqlExceptionOccurs()
        {

            var audit = new AuditTrail { AuditTrailId = 1, AuditTrailUserId = "Test audit" };
            mockAuditTrailRepository.Setup(repo => repo.Add(audit)).ThrowsAsync(new Exception("Simulated SQL Exception!"));

            var result = await controller.Post(audit);
            Assert.IsInstanceOfType(result, typeof(BadRequestObjectResult));
        }
        #endregion Test Post
    }
}
