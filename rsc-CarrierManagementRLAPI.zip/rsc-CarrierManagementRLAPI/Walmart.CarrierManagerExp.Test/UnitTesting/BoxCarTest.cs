﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Xml.Linq;
using Walmart.CarrierManagerExp.Api.Repository;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class BoxCarTest
    {
        [TestMethod]
        public void BoxCar_ShouldInitializeCorrectly() {

            var boxCar = new BoxCar
            {
                BoxCarId = 1,
                BoxCarCode = "TestCode",
                BoxCarDescription = "TestDescription",
                BoxCarPlateNumber = "TestPlateNumber",
                Active = "true"

            };
            
            Assert.AreEqual(1, boxCar.BoxCarId);
            Assert.AreEqual("TestCode", boxCar.BoxCarCode);
            Assert.AreEqual("TestDescription", boxCar.BoxCarDescription);
            Assert.AreEqual("TestPlateNumber", boxCar.BoxCarPlateNumber);
            Assert.AreEqual("true", boxCar.Active);
        }
    }
}
