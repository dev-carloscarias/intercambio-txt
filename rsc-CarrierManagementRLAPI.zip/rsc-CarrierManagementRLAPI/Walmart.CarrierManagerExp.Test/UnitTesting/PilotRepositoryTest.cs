﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.SqlClient;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    
    public class FakePilotRepository : PilotRepository
    {

        public SqlCommand LastCommand { get; private set; }
        private readonly IQueryable<Pilot> _fakeResult;                

        public FakePilotRepository(string connectionString, IQueryable<Pilot> fakeResult) : base(connectionString)
        {
            _fakeResult = fakeResult;
        }        

        protected override async Task<IQueryable<Pilot>> GetRecords(SqlCommand command)
        {

            LastCommand = command;
            if (_fakeResult != null)
                return await Task.FromResult(_fakeResult);
            else
                return await Task.FromResult(new List<Pilot>().AsQueryable());
        }
    }

    [TestClass]
    public class FakePilotRepositoryTest
    {
        private const string connectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";        

        [TestMethod]
        public async Task GetItem_ShouldBeOk() {
            
            var fakeResult = new List<Pilot>().AsQueryable();
            var repo = new FakePilotRepository(connectionString, fakeResult);

            string carrierCode = "123";
            string code = "Test";
            int id = 123;
            int carrierId = 456;

            var result = await repo.Get(carrierCode, code, id, carrierId);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetPilotbyCodesSP, repo.LastCommand.CommandText);
            Assert.AreEqual(4, repo.LastCommand.Parameters.Count);
            AssertParameter(repo.LastCommand, "@carrierCode", carrierCode);
            AssertParameter(repo.LastCommand, "@code", code);
            AssertParameter(repo.LastCommand, "@id", id);
            AssertParameter(repo.LastCommand, "@carrierId", carrierId);
            Assert.AreEqual(fakeResult, result);
        }       

        private void AssertParameter(SqlCommand command, string paramName, object expectedValue)
        {

            Assert.IsTrue(command.Parameters.Contains(paramName), $"El parámetro {paramName} debe existir");
            var param = command.Parameters[paramName];
            if (expectedValue == DBNull.Value)
                Assert.AreEqual(DBNull.Value, param.Value);
            else
                Assert.AreEqual(expectedValue, param.Value);
        }
    }
}
