﻿using Elasticsearch.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using System.Data.SqlClient;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Repositories;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    
    public class FakeCarrierRepository : CarrierRepository
    {

        public SqlCommand LastCommand { get; private set; }
        private readonly IQueryable<TmsCarrier> _fakeResult;
        private readonly int? _simulatedReturnValue;
        private readonly TmsCarrier _fakeRecord;        

        public FakeCarrierRepository(string connectionString, IQueryable<TmsCarrier> fakeResult) : base(connectionString)
        {
            _fakeResult = fakeResult;
            _simulatedReturnValue = null;
            _fakeRecord = null;
        }

        public FakeCarrierRepository(string connectionString, int simulatedReturnValue) : base(connectionString)
        {
            _simulatedReturnValue = simulatedReturnValue;
            _fakeResult = null;
            _fakeRecord = null;
        }

        public FakeCarrierRepository(string connectionString, TmsCarrier fakeRecord) : base(connectionString)
        {
            _fakeRecord = fakeRecord;
            _simulatedReturnValue = null;
            _fakeResult = null;
        }

        public FakeCarrierRepository(string connectionString, IQueryable<TmsCarrier> fakeResult, int simulatedReturnValue, TmsCarrier fakeRecord) : base(connectionString)
        {
            _fakeResult = fakeResult;
            _simulatedReturnValue = simulatedReturnValue;
            _fakeRecord = fakeRecord;
        }        

        protected override async Task<TmsCarrier> GetRecord(SqlCommand command)
        {

            LastCommand = command;
            return await Task.FromResult(_fakeRecord);
        }

        protected override async Task<IQueryable<TmsCarrier>> ExecuteStoredProc(SqlCommand command)
        {
            LastCommand = command;
            if (_fakeResult != null)
                return await Task.FromResult(_fakeResult);
            else
                return await Task.FromResult(new List<TmsCarrier>().AsQueryable());
        }

        protected override async Task<int> ExecuteCommand(SqlCommand command)
        {
            LastCommand = command;
            if (_simulatedReturnValue.HasValue)
            {
                command.Parameters["@result"].Value = _simulatedReturnValue.Value;
                return await Task.FromResult(_simulatedReturnValue.Value);
            }
            return await Task.FromResult(0);

        }
    }

    [TestClass]
    public class FakeCarrierRepositoryTest
    {
        private const string connectionString = "Server=localhost;Database=FakeDataBase;Integrated Security=True;";        

        [TestMethod]
        public async Task GetItem_WithDefaultParameters_ShouldNotAddParameters() {

            var fakeRecordaux = new TmsCarrier
            {
                CarrierId = 123,
                CountryId = 345,
                CarrierCode = "Test"                
            };
            var repo = new FakeCarrierRepository(connectionString, fakeRecordaux);

            string carrierCode = "123";
            var result = await repo.GetItem(carrierCode);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetCarrierByCodeSP, repo.LastCommand.CommandText);
            Assert.AreEqual(1, repo.LastCommand.Parameters.Count);
            AssertParameter(repo.LastCommand, "@Transportista_code", carrierCode);
            Assert.AreEqual(fakeRecordaux, result);
        }

        [TestMethod]
        public async Task GetByCarrierId_WithDefaultParameters_ShouldNotAddParameters()
        {

            var fakeRecordaux = new TmsCarrier
            {
                CarrierId = 123,
                CountryId = 345,
                CarrierCode = "Test"
            };
            var repo = new FakeCarrierRepository(connectionString, fakeRecordaux);

            int id = 123;
            var result = await repo.GetByCarrierId(id);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetCarrierByIdSP, repo.LastCommand.CommandText);
            Assert.AreEqual(1, repo.LastCommand.Parameters.Count);
            AssertParameter(repo.LastCommand, "@CarrierId", id);
            Assert.AreEqual(fakeRecordaux, result);
        }

        [TestMethod]
        public async Task GetByEmail_WithDefaultParameters_ShouldNotAddParameters()
        {                        
            var fakeRecordaux = new TmsCarrier
            {
                CarrierId = 123,
                CountryId = 345,
                CarrierCode = "Test"
            };
            var fakeResult = new List<TmsCarrier>() { fakeRecordaux }.AsQueryable();
            var repo = new FakeCarrierRepository(connectionString, fakeResult);

            string email = "Test";
            var result = await repo.GetByEmail(email);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.GetCarrierByEmail, repo.LastCommand.CommandText);
            Assert.AreEqual(1, repo.LastCommand.Parameters.Count);
            AssertParameter(repo.LastCommand, "@CMUser", email);
            Assert.AreEqual(fakeResult, result);            
        }

        [TestMethod]
        public async Task ValidateCarries_WithDefaultParameters_ShouldNotAddParameters()
        {           
            var repo = new FakeCarrierRepository(connectionString, simulatedReturnValue:1);

            string carrierCode = "Test";
            string filter = "Test";
            string filterCode = "Test";

            var result = await repo.ValidateCarriers(carrierCode,filter,filterCode);

            Assert.IsNotNull(repo.LastCommand);
            Assert.AreEqual(CommandType.StoredProcedure, repo.LastCommand.CommandType);
            Assert.AreEqual(ConstantsHelper.ValidateCarrierSP, repo.LastCommand.CommandText);
            Assert.AreEqual(4, repo.LastCommand.Parameters.Count);
            AssertParameter(repo.LastCommand, "@carrierCode", carrierCode);
            AssertParameter(repo.LastCommand, "@code", filterCode);
            AssertParameter(repo.LastCommand, "@filter", filter);
            AssertParameter(repo.LastCommand, "@result", 1);            
        }

        private void AssertParameter(SqlCommand command, string paramName, object expectedValue)
        {

            Assert.IsTrue(command.Parameters.Contains(paramName), $"El parámetro {paramName} debe existir");
            var param = command.Parameters[paramName];
            if (expectedValue == DBNull.Value)
                Assert.AreEqual(DBNull.Value, param.Value);
            else
                Assert.AreEqual(expectedValue, param.Value);
        }
    }
}
