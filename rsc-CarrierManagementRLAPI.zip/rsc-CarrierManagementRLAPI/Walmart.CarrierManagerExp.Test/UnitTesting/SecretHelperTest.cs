﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Walmart.Common.Helpers;
using System.IO;
using Walmart.Common.Helpers.Handlers;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    [TestClass]
    public class SecretHelperTest
    {
        private SecretHelper secretHelper;

        [TestInitialize]
        public void Setup()
        {
            secretHelper = new SecretHelper("development");
        }

        [TestMethod]
        public void isdevelopmentEnvironmentTest()
        {
            SecretHelper secretHelper = new SecretHelper("development");

            Assert.AreEqual(secretHelper.IsDevelopmentEnvironment(), true);
        }
        [TestMethod]
        public void isNotdevelopmentEnvironmentTest()
        {
            SecretHelper secretHelper = new SecretHelper("production");

            Assert.AreEqual(secretHelper.IsDevelopmentEnvironment(), false);
        }

        [TestMethod]
        public void GetDBCarrierConnection_ReturnsFileContents_WhenFileExist() {

            string filePath = Path.Combine("/etc/secrets/dev/", "database_carrier.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getDBCarrierConnection();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void GetDBCarrierConnection_ReturnsError_WhenFileNotFound() {

            var secrectHelper = new SecretHelper("developmnet");
            string result = secrectHelper.getDBCarrierConnection();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void GetDBTMSConnection_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "database_tms.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getDBTMSConnection();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void GetDBTMSConnection_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("developmnet");
            string result = secrectHelper.getDBTMSConnection();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getElasticSearchUrl_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "elasticsearch-url.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getElasticSearchUrl();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getElasticSearchUrl_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getElasticSearchUrl();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getElasticSearchFormat_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "elasticsearch-indexFormat.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getElasticSearchFormat();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getElasticSearchFormat_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getElasticSearchFormat();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getElasticSearchTemplate_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "elasticsearch-templateName.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getElasticSearchTemplate();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getElasticSearchTemplate_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getElasticSearchTemplate();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getElasticSearchType_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "elasticsearch-typeName.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getElasticSearchType();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getElasticSearchType_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getElasticSearchType();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getApiBaseUrl_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "api_base_url.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getApiBaseUrl();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getApiBaseUrl_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getApiBaseUrl();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getItemFileClientId_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "item_file_client_id.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getItemFileClientId();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getItemFileClientId_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getItemFileClientId();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getItemFileClientSec_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "item_file_client_sec.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getItemFileClientSec();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getItemFileClientSec_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getItemFileClientSec();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getItemFileTokenScopes_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "item_file_token_scopes.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getItemFileTokenScopes();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getItemFileTokenScopes_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getItemFileTokenScopes();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getSTFPServer_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "stfp_server.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getSTFPServer();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getSTFPServer_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getSTFPServer();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getFalconBaseUrl_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "falcon_base_url.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getFalconBaseUrl();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getFalconBaseUrl_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getFalconBaseUrl();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getFalconClientId_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "falcon_client_id.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getFalconClientId();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getFalconClientId_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getFalconClientId();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getFalconType_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "falcon_client_type.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getFalconType();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getFalconType_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getFalconType();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

        [TestMethod]
        public void getSTSTokenProvider_ReturnsFileContents_WhenFileExist()
        {

            string filePath = Path.Combine("/etc/secrets/dev/", "sts_token_provider.txt");
            Directory.CreateDirectory("/etc/secrets/dev/");
            File.WriteAllText(filePath, "DatabaseConnectionString");

            var secretHelper = new SecretHelper("development");

            string result = secretHelper.getSTSTokenProvider();

            Assert.AreEqual("DatabaseConnectionString", result);

            File.Delete(filePath);
        }

        [TestMethod]
        public void getSTSTokenProvider_ReturnsError_WhenFileNotFound()
        {

            var secrectHelper = new SecretHelper("development");
            string result = secrectHelper.getSTSTokenProvider();
            Assert.IsTrue(result.StartsWith("Not Found File"));
        }

    }
}
