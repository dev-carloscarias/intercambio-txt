﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Walmart.Common.Helpers;
using System.Globalization;
using System.Data.SqlClient;
using Walmart.Common.Repositories;
using Elasticsearch.Net.Specification.MachineLearningApi;
using System.Data.Common;

namespace Walmart.CarrierManagerExp.Test.UnitTesting
{
    public class TestRepository : GenericRepository<TestEntity>
    {

        public TestRepository(string connectionString) : base(connectionString) { }

        //public override SqlConnection Connection => new TestDBConnection();

        public override TestEntity PopulateRecord(DbDataReader reader)
        {
            return new TestEntity
            {
                Id = reader.GetInt32(reader.GetOrdinal("Id")),
                Name = reader.GetString(reader.GetOrdinal("Name"))
            };
        }

        public async Task<IQueryable<TestEntity>> TestGetRecords(DbCommand command)
        {

            var testData = new List<TestEntity> {

                new TestEntity { Id = 1, Name = "Test 1" },
                new TestEntity { Id = 2, Name = "Test 2"}
            };

            return await Task.FromResult(testData.AsQueryable());
        }

        public async Task<(int total, IQueryable<TestEntity> result)> TestGetPagedRecords(DbCommand command)
        {

            var testData = new List<TestEntity> {

                new TestEntity { Id = 1, Name = "Test 1" },
                new TestEntity { Id = 2, Name = "Test 2"}
            };

            int totalRecords = testData.Count;

            return await Task.FromResult((totalRecords, testData.AsQueryable()));
        }
    }

    public class TestEntity
    {

        public int Id { get; set; }
        public string Name { get; set; }
    }
}