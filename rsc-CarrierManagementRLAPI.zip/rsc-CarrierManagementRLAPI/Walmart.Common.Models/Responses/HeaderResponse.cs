﻿//---------------------------------------------------------------------------------------    
// <copyright file="HeaderResponse.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Models
{
    #region Using
    using System;
    using System.Net;
    using System.Runtime.Serialization;
    #endregion

    /// <summary>
    /// Header response class
    /// </summary>
    [DataContract]
    public class HeaderResponse : IHeaderResponse
    {
        /// <summary>
        /// Gets or sets object version
        /// </summary>
        [DataMember]
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets status code
        /// </summary>
        [DataMember]
        public HttpStatusCode StatusCode { get; set; }

        /// <summary>
        /// Gets or sets total results
        /// </summary>        
        [DataMember]
        public int TotalResults { get; set; }

        /// <summary>
        /// Gets or sets returned results
        /// </summary>       
        [DataMember]
        public int ReturnedResults { get; set; }

        /// <summary>
        /// Gets or sets timestamp response
        /// </summary>       
        [DataMember]
        public DateTime Timestamp { get; set; }
    }
}
