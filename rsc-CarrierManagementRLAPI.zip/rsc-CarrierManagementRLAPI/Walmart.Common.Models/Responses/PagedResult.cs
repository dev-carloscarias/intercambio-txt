﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Walmart.Common.Models
{
    public class PagedResult<T> : IPagedResult
    {
        /// <summary>
        /// Gets or sets the paged data
        /// </summary>
        [DataMember]
        public List<T> Data { get; set; }

        /// <summary>
        /// Gets or sets the offset of records to skip
        /// </summary>        
        [DataMember]
        public int Offset { get; set; }

        /// <summary>
        /// Gets or sets the limit of records to retrieve
        /// </summary>        
        [DataMember]
        public int Limit { get; set; }

        /// <summary>
        /// Gets or sets total of records in the datasource
        /// </summary>        
        [DataMember]
        public int Total { get; set; }
    }
}
