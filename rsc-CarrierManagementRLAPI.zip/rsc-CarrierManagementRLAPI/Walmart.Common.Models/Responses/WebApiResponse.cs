﻿//---------------------------------------------------------------------------------------    
// <copyright file="WebApiResponse.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Models
{
    #region Using
    using System.Runtime.Serialization;
    #endregion

    /// <summary>
    /// Generic response model
    /// </summary>
    [DataContract]
    public class WebApiResponse : IWebApiResponse
    {
        /// <summary>
        /// Gets or sets result response
        /// </summary>
        [DataMember]
        public object Results { get; set; }

        /// <summary>
        /// Gets or sets error response
        /// </summary>
        [DataMember]
        public ErrorMessages Errors { get; set; }

        /// <summary>
        /// Gets or sets header response
        /// </summary>
        [DataMember]
        public HeaderResponse Header { get; set; }
    }
}