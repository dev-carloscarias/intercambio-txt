﻿//---------------------------------------------------------------------------------------    
// <copyright file="IWebApiResponse.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Models
{
    #region Using
    #endregion

    /// <summary>
    /// Generic response interface
    /// </summary>
    public interface IWebApiResponse
    {
        /// <summary>
        /// Gets or sets result response
        /// </summary>
        object Results { get; set; }

        /// <summary>
        /// Gets or sets error response
        /// </summary>
        ErrorMessages Errors { get; set; }

        /// <summary>
        /// Gets or sets header response
        /// </summary>
        HeaderResponse Header { get; set; }
    }
}