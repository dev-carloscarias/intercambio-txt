﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Walmart.Common.Models
{
    /// <summary>
    /// 
    /// </summary>
    public interface IPagedResult
    {
        int Offset { get; set; }
        int Limit { get; set; }
        int Total { get; set; }
    }
}
