﻿//---------------------------------------------------------------------------------------    
// <copyright file="IErrorMessages.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.Common.Models
{
    /// <summary>
    /// Generic entity interface
    /// </summary>
    public interface IErrorMessages
    {
        /// <summary>
        /// Gets or sets error code
        /// </summary>
        int Code { get; set; }

        /// <summary>
        /// Gets or sets error description
        /// </summary>
        string UserMessage { get; set; }

        /// <summary>
        /// Gets or sets link to help
        /// </summary>
        string Link { get; set; }

        /// <summary>
        /// Gets or sets error internal message
        /// </summary>
        string InternalMessage { get; set; }
    }
}