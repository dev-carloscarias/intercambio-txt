﻿//---------------------------------------------------------------------------------------    
// <copyright file="ErrorMessages.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
using System.Runtime.Serialization;

namespace Walmart.Common.Models
{
    #region Using
    #endregion

    /// <summary>
    /// Generic error entity
    /// </summary>
    [DataContract]
    public class ErrorMessages : IErrorMessages
    {
        #region Properties
        /// <summary>
        /// Gets or sets error code
        /// </summary>
        [DataMember]
        public int Code { get; set; }

        /// <summary>
        /// Gets or sets error message
        /// </summary>
        [DataMember]
        public string UserMessage { get; set; }

        /// <summary>
        /// Gets or sets error description
        /// </summary>
        [DataMember]
        public string InternalMessage { get; set; }

        /// <summary>
        /// Gets or sets link to help
        /// </summary>
        [DataMember]
        public string Link { get; set; }
        #endregion
    }
}