﻿using Microsoft.IdentityModel.Tokens;
using System.Collections.Generic;

namespace Walmart.CarrierManagerExp.Api
{
    /// <summary>
    /// Custom Parameters for the token validation
    /// </summary>
    public class CustomTokenValidationParameters : TokenValidationParameters
    {
        /// <summary>
        ///
        /// </summary>
        public bool ValidateScopes { get; set; }

        /// <summary>
        ///
        /// </summary>
        public List<string> ValidScopes { get; set; }
    }
}