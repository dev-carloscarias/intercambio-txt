﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;

namespace Walmart.CarrierManagerExp.Api
{
    /// <summary>
    /// Custom validator for the access token
    /// </summary>
    public class CustomValidatorHandler : JwtSecurityTokenHandler, ISecurityTokenValidator
    {
        private CustomTokenValidationParameters validationParameters;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="validationParameters"></param>
        public CustomValidatorHandler(CustomTokenValidationParameters validationParameters)
        {
            this.validationParameters = validationParameters;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="claimedId"></param>
        /// <returns></returns>
        public SecurityKey GetKeyForClaimedId(string claimedId)
        {
            //Here's where we would have the logic to go look up the key in our database.
            //Omitted for brevity.
            throw new NotImplementedException();
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="token"></param>
        /// <param name="validationParams"></param>
        /// <param name="validatedToken"></param>
        /// <returns></returns>
        public override ClaimsPrincipal ValidateToken(string token, TokenValidationParameters validationParams, out SecurityToken validatedToken)
        {
            //We can read the token before we've begun validating it.
            JwtSecurityToken incomingToken = ReadJwtToken(token);
            //Extract the external system ID from the token.
            var claimScope = incomingToken.Claims.First(claim => claim.Type == "scope");
            var claimIssuer = incomingToken.Claims.First(claim => claim.Type == "iss");
            if (validationParameters.ValidateScopes)
            {
                if (claimScope == null)
                    throw new SecurityTokenException("no_scope");
                var scopes = claimScope.Value;
                if (scopes != string.Join(" ", validationParameters.ValidScopes))
                {
                    throw new SecurityTokenException("different_scopes");
                }
            }
            if (validationParameters.ValidateIssuer)
            {
                if (claimIssuer == null)
                    throw new SecurityTokenException("no_issuer");
                var issuer = claimIssuer.Value;
                if (issuer != validationParameters.ValidIssuer)
                {
                    throw new SecurityTokenException("different_issuer");
                }
            }
            ////Retrieve the corresponding Public Key from our data store
            //SecurityKey publicKeyForExternalSystem = GetKeyForClaimedId(externalSystemId);
            ////Set our parameters to use the public key we've looked up
            //validationParameters.IssuerSigningKey = publicKeyForExternalSystem;
            //And let the framework take it from here.
            return base.ValidateToken(token, validationParams, out validatedToken);
        }
    }
}