﻿//---------------------------------------------------------------------------------------
// <copyright file="Get.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using

    /// <summary>
    /// Carrier get controller
    /// </summary>
    public partial class CarrierController : BaseApiController
    {
        /// <summary>
        /// Get TMS carrier using code.
        /// </summary>
        /// <param name="code">Carrier code</param>
        /// GET api/v1/products/1
        /// <returns>Specific product</returns>
        [Route("{code}", Name = "GetByCode")]
        [HttpGet]
        [ProducesResponseType(typeof(TmsCarrier), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetByCode(string code)
        {
            try
            {
                if (string.IsNullOrEmpty(code))
                {
                    return this.BadRequest(
                   ErrorMessageManagement.SetsErrorMessages(
                       Messages.InvalidDataUserMessage,
                    (int)System.Net.HttpStatusCode.BadRequest));
                }

                var carrier = await carrierRepository.GetItem(code);

                if (carrier == null)
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }
                if (!await this.authorizationMiddleware.checkEmail(Request, carrier.CarrierEmail)) return this.Unauthorized();

                return Ok(carrier);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        /// <summary>
        /// Get TMS carrier using code.
        /// </summary>
        /// <param name="email">Carrier logued user email</param>
        /// Get carrier TMS information
        /// <returns>Specific product</returns>
        [Route("getbyemail/{email}", Name = "getbyemail")]
        [HttpGet]
        [ProducesResponseType(typeof(TmsCarrier), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetByEmail(string email)
        {
            try
            {

                if (string.IsNullOrEmpty(email))
                {
                    return this.BadRequest(
                   ErrorMessageManagement.SetsErrorMessages(
                       Messages.InvalidDataUserMessage,
                    (int)System.Net.HttpStatusCode.BadRequest));
                }
                if (!await this.authorizationMiddleware.checkEmail(Request, email))
                {
                    return this.Unauthorized();
                }

                var carrier = await carrierRepository.GetByEmail(email);

                if (carrier == null)
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                return Ok(carrier);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        /// <summary>
        /// Get TMS carrier box car using codes
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="code">box card code</param>
        /// <returns>Specific box car entity</returns>
        [Route("boxcar/{carrierCode}", Name = "getboxcar")]
        [HttpGet]
        [ProducesResponseType(typeof(BoxCar), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetBoxCar(string carrierCode, string code)
        {
            try
            {
                if (string.IsNullOrEmpty(carrierCode))
                {
                    return this.BadRequest(
                   ErrorMessageManagement.SetsErrorMessages(
                       Messages.InvalidDataUserMessage,
                    (int)System.Net.HttpStatusCode.BadRequest));
                }
                if (!await this.authorizationMiddleware.validateUserByCode(Request, carrierCode)) return this.Unauthorized();
                var carrier = await boxCarRepository.Get(carrierCode, code, null);

                if (carrier == null || !carrier.Any())
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                return Ok(carrier);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        /// <summary>
        /// Get TMS carrier vehicle using codes
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="code">Vehicle code</param>
        /// <returns>Specific vehicle entity</returns>
        [Route("vehicle/{carrierCode}", Name = "getvehicle")]
        [HttpGet]
        [ProducesResponseType(typeof(Vehicle), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetVehicle(string carrierCode, string code)
        {
            try
            {
                if (string.IsNullOrEmpty(carrierCode))
                {
                    return this.BadRequest(
                   ErrorMessageManagement.SetsErrorMessages(
                       Messages.InvalidDataUserMessage,
                    (int)System.Net.HttpStatusCode.BadRequest));
                }
                
                if (!await this.authorizationMiddleware.validateUserByCode(Request, carrierCode)) return this.Unauthorized();

                var carrier = await vehicleRepository.Get(carrierCode, code, null);

                if (carrier == null || !carrier.Any())
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                return Ok(carrier);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        /// <summary>
        /// Get TMS carrier vehicle using codes
        /// </summary>
        /// <param name="carrierCode">Carrier code</param>
        /// <param name="code">Pilot code</param>
        /// <returns>Specific pilot entity</returns>
        [Route("pilot/{carrierCode}", Name = "getpilot")]
        [HttpGet]
        [ProducesResponseType(typeof(Vehicle), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetPilot(string carrierCode, string code)
        {
            try
            {
                if (string.IsNullOrEmpty(carrierCode))
                {
                    return this.BadRequest(
                   ErrorMessageManagement.SetsErrorMessages(
                       Messages.InvalidDataUserMessage,
                    (int)System.Net.HttpStatusCode.BadRequest));
                }
                if (!await this.authorizationMiddleware.validateUserByCode(Request, carrierCode)) return this.Unauthorized();
                var carrier = await pilotRepository.Get(carrierCode, code, null, null);

                if (carrier == null || !carrier.Any())
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                return Ok(carrier);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }


        /////// <summary>
        /////// Get TMS carrier vehicle.
        /////// </summary>
        /////// <param name="code">Carrier code</param>
        /////// <param name="filterCode">Filter code</param>
        /////// <returns>validate vehicle</returns>
        ////[Route("validations/vehicle", Name = nameof(ValidateVehicle))]
        ////[HttpGet]
        ////[ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        ////public async Task<IActionResult> ValidateVehicle(string carrierCode, string filterCode)
        ////{
        ////    try
        ////    {
        ////        if (string.IsNullOrEmpty(carrierCode) && string.IsNullOrEmpty(filterCode))
        ////        {
        ////            return BadRequest(
        ////           ErrorMessageManagement.SetsErrorMessages(
        ////               Messages.InvalidDataUserMessage,
        ////            (int)System.Net.HttpStatusCode.BadRequest));
        ////        }

        ////        var carrier = await carrierRepository.ValidateCarriers(carrierCode, "CarrierIdV", filterCode);

        ////        return Ok(carrier);
        ////    }
        ////    catch (SqlException ex)
        ////    {
        ////        logger.LogDebug(ex.ToString());
        ////        return BadRequest(
        ////            ErrorMessageManagement.SetsErrorMessages(
        ////                Messages.SqlExceptionUserMessage));
        ////    }
        ////    catch (System.Exception ex)
        ////    {
        ////        logger.LogDebug(ex.ToString());
        ////        return BadRequest(
        ////            ErrorMessageManagement.SetsErrorMessages(
        ////                Messages.SqlExceptionUserMessage));
        ////    }
        ////}

        /////// <summary>
        /////// Get TMS car box.
        /////// </summary>
        /////// <param name="code">Carrier code</param>
        /////// <param name="filterCode">Filter code</param>
        /////// <returns>validate carbox</returns>
        ////[Route("validations/boxcar", Name = nameof(ValidateBoxCar))]
        ////[HttpGet]
        ////[ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        ////public async Task<IActionResult> ValidateBoxCar(string carrierCode, string filterCode)
        ////{
        ////    try
        ////    {
        ////        if (string.IsNullOrEmpty(carrierCode) && string.IsNullOrEmpty(filterCode))
        ////        {
        ////            return BadRequest(
        ////           ErrorMessageManagement.SetsErrorMessages(
        ////               Messages.InvalidDataUserMessage,
        ////            (int)System.Net.HttpStatusCode.BadRequest));
        ////        }

        ////        var carrier = await carrierRepository.ValidateCarriers(carrierCode, "CarrierIdF", filterCode);

        ////        return Ok(carrier);
        ////    }
        ////    catch (SqlException ex)
        ////    {
        ////        logger.LogDebug(ex.ToString());
        ////        return BadRequest(
        ////            ErrorMessageManagement.SetsErrorMessages(
        ////                Messages.SqlExceptionUserMessage));
        ////    }
        ////    catch (System.Exception ex)
        ////    {
        ////        logger.LogDebug(ex.ToString());
        ////        return BadRequest(
        ////            ErrorMessageManagement.SetsErrorMessages(
        ////                Messages.SqlExceptionUserMessage));
        ////    }
        ////}

        /////// <summary>
        /////// Get TMS carrier pilot.
        /////// </summary>
        /////// <param name="code">Carrier code</param>
        /////// <param name="filterCode">Filter code</param>
        /////// <returns>validate pilot</returns>
        ////[Route("validations/pilot", Name = nameof(ValidatePilot))]
        ////[HttpGet]
        ////[ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        ////public async Task<IActionResult> ValidatePilot(string carrierCode, string filterCode)
        ////{
        ////    try
        ////    {
        ////        if (string.IsNullOrEmpty(carrierCode) && string.IsNullOrEmpty(filterCode))
        ////        {
        ////            return BadRequest(
        ////           ErrorMessageManagement.SetsErrorMessages(
        ////               Messages.InvalidDataUserMessage,
        ////            (int)System.Net.HttpStatusCode.BadRequest));
        ////        }

        ////        var carrier = await carrierRepository.ValidateCarriers(carrierCode, "CarrierIdP", filterCode);

        ////        return Ok(carrier);
        ////    }
        ////    catch (SqlException ex)
        ////    {
        ////        logger.LogDebug(ex.ToString());
        ////        return BadRequest(
        ////            ErrorMessageManagement.SetsErrorMessages(
        ////                Messages.SqlExceptionUserMessage));
        ////    }
        ////    catch (System.Exception ex)
        ////    {
        ////        logger.LogDebug(ex.ToString());
        ////        return BadRequest(
        ////            ErrorMessageManagement.SetsErrorMessages(
        ////                Messages.SqlExceptionUserMessage));
        ////    }
        ////}
    }
}