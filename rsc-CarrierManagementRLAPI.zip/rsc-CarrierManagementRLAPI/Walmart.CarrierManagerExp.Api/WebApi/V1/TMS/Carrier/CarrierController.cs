//---------------------------------------------------------------------------------------
// <copyright file="CarrierController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    using Microsoft.AspNetCore.Cors;
    #region Using

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Common.Middlewares.Authorization;
    using Walmart.CarrierManagerExp.Api.Repository;

    #endregion Using

    /// <summary>
    /// Products Controller sample
    /// </summary>
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route(Path + "api/v{version:apiVersion}/carrier")]
    public partial class CarrierController : BaseApiController
    {
        #region Fields

        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<CarrierController> logger;

        /// <summary>
        /// Carrier repository
        /// </summary>
        private ICarrierRepository carrierRepository;

        /// <summary>
        /// box car repository
        /// </summary>
        private IBoxCarRepository boxCarRepository;

        /// <summary>
        /// Pilot repository
        /// </summary>
        private IPilotRepository pilotRepository;

        /// <summary>
        /// Vehicle repository
        /// </summary>
        private IVehicleRepository vehicleRepository;

        private IAuthorizationMiddleware authorizationMiddleware;

        #endregion Fields

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="CarrierController" /> class
        /// </summary>
        /// <param name="carrierRepository">Carrier repository</param>
        /// <param name="boxCarRepository">Box car repository</param>
        /// <param name="pilotRepository">Pilot repository</param>
        /// <param name="vehicleRepository"></param>
        /// <param name="logger">Logger repository</param>
        public CarrierController(ICarrierRepository carrierRepository, IBoxCarRepository boxCarRepository, IPilotRepository pilotRepository, IVehicleRepository vehicleRepository, ILogger<CarrierController> logger, IAuthorizationMiddleware authorizationMiddleware)
        {
            this.carrierRepository = carrierRepository;
            this.logger = logger;
            this.boxCarRepository = boxCarRepository;
            this.pilotRepository = pilotRepository;
            this.vehicleRepository = vehicleRepository;
            this.authorizationMiddleware = authorizationMiddleware;
        }

        #endregion Constructor
    }
}