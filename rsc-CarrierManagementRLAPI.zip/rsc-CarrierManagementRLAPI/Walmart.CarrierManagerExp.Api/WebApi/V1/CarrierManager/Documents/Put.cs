//---------------------------------------------------------------------------------------
// <copyright file="Put.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using

    /// <summary>
    /// Documents controller post methods
    /// </summary>
    public partial class DocumentsController : BaseApiMasterServiceController
    {
        #region Methods

        /// <summary>
        /// Create a new document
        /// Set Content-Type:<code>Application/Json</code>
        /// </summary>
        /// <param name="document">Product entity</param>
        /// <returns>Result response</returns>
        [HttpPut]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        [Route("")]
        public async Task<IActionResult> Put([FromForm] CarrierDocument document)
        {
            try
            {
                if (!await this.authorizationMiddleware.validateUserById(Request, document.CarrierId ?? 0)) return this.Unauthorized();
                if (!await this.authorizationMiddleware.validateUserByDocument(Request, document.CarrierDocumentId ?? 0)) return this.Unauthorized();
                if (!ModelState.IsValid)
                {
                    return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.InvalidDataUserMessage,
                     (int)System.Net.HttpStatusCode.BadRequest));
                }
                

                var uploadResult = await UploadFile(document);

                if (!uploadResult.Success)
                {
                    if (!string.IsNullOrEmpty(uploadResult.Messages))
                    {
                        logger.LogError(uploadResult.Messages);
                    }

                    return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Resources.Documents.Error6,
                     (int)System.Net.HttpStatusCode.Conflict));
                }

                document.TokenFileShare = uploadResult.FileId;

                var response = await documentRepository.Update(document);

                if (response > 0)
                {
                    var generic = await GetGenericAsync(document);

                    if (generic != null)
                    {
                        documentRepository.SendNotifications(document, generic);
                    }

                    return Ok(response);
                }
                else
                {
                    var errorMessage = Messages.NoAddRecordUserMessage;

                    return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        errorMessage,
                     (int)System.Net.HttpStatusCode.Conflict));
                }
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                logger.LogError(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.ExceptionMessage));
            }
        }

        #endregion Methods
    }
}