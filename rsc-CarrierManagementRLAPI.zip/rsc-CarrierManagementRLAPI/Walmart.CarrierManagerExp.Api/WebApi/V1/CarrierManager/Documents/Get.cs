//---------------------------------------------------------------------------------------
// <copyright file="Get.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    using System;
    using System.Collections.Generic;

    #region Using

    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using

    /// <summary>
    /// Documents controller get methods
    /// </summary>
    public partial class DocumentsController : BaseApiMasterServiceController
    {
        /// <summary>
        /// Get Documents.
        /// </summary>
        /// <param name="documentId">Document id</param>
        /// <param name="countryId">Country id</param>
        /// <param name="carrierId">TMS Carrier id</param>
        /// <param name="documentTypeId">Document type id</param>
        /// <param name="documentTypeDescription">Document type description</param>
        /// <returns>Documents collection</returns>
        [Route("")]
        [HttpGet]
        [ProducesResponseType(typeof(CarrierDocument), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> Get(int documentId = 0, int countryId = 0, int carrierId = 0, int documentTypeId = 0, string documentTypeDescription = "")
        {
            try
            {
                if (!await this.authorizationMiddleware.validateUserById(Request, carrierId)) return this.Unauthorized();
                var results = await documentRepository.GetItems(documentId, countryId, carrierId, documentTypeId, documentTypeDescription);

                if (results == null || !results.Any())
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                List<CarrierDocument> documents = new List<CarrierDocument>();
                Parallel.ForEach(results, item =>
                {
                    var res = GetLiterals(item).Result;
                    documents.Add(res);
                });
                

                return Ok(documents);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.ExceptionMessage));
            }
        }

        /// <summary>
        /// Get Documents for update.
        /// </summary>
        /// <param name="documentId">Document id</param>
        /// <returns>Documents collection</returns>
        [Route("GetDocumentToUpdate/{documentId}")]
        [HttpGet]
        [ProducesResponseType(typeof(CarrierDocument), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetDocumentToUpdate(int documentId)
        {
            try
            {
                var results = await documentRepository.GetItems(documentId);

                if (results == null || !results.Any())
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                List<CarrierDocument> documents = new List<CarrierDocument>();
                bool unauthorized = false;
                Parallel.ForEach(results, item =>
                {
                    if (!this.authorizationMiddleware.validateUserById(Request, item.CarrierId ?? 0).Result)
                    {
                        unauthorized = true;
                        return;
                    }
                    var res = GetLiterals(item, onlyCodes: true).Result;
                    documents.Add(res);
                });
                if(unauthorized)
                {
                    return this.Unauthorized();
                }
                return Ok(documents);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.ExceptionMessage));
            }
        }

        /// <summary>
        /// Download carrier documents
        /// </summary>
        /// <param name="fileToken">File token id</param>
        /// <param name="documentId">Carrier document id</param>
        /// <param name="carrierId">Carrier id</param>
        /// <returns></returns>
        [Route("downloaddocument/{fileToken},{documentId},{carrierId}", Name = "downloaddocument")]
        [HttpGet]
        [ProducesResponseType(typeof(FileResult), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> DownLoadFile(string fileToken, int documentId, int carrierId)
        {
            FileResult document;

            try
            {
                var documentResult = await documentRepository.GetByTokenFileShare(fileToken);
                if (documentResult == null) return this.NotFound();
                if (!await this.authorizationMiddleware.validateUserById(Request, documentResult.CarrierId ?? 0)) return this.Unauthorized();
                var carrierDocument = await documentRepository.GetByTokenFileShare(fileToken);

                if (carrierDocument != null && carrierDocument.CarrierDocumentId != documentId && carrierDocument.CarrierId != carrierId)
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                                Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                var results = await sftpClient.DownloadFile(new Walmart.Common.SecureFtpClient.BlobDownloadRequest { FileId = fileToken }, secretHelper.getSTFPServer());

                if (!results.Success)
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                               results.Messages ?? Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                ////using (MemoryStream stream = new MemoryStream())
                ////{
                ////    stream.Write(results.BlobStream, 0, results.BlobStream.Length);

                ////    var file = new FormFile(stream, 0, stream.Length, null, results.BlobFileName)
                ////    {
                ////        Headers = new HeaderDictionary(),
                ////        ContentDisposition = ""
                ////    };

                ////    document = file;
                ////}

                ////return this.Ok(new CarrierDocument { File = document });

                return document = File(results.BlobStream, "application/octet-stream", results.BlobFileName);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.ExceptionMessage));
            }
        }

        /// <summary>
        /// Validate if document exists using token
        /// </summary>
        /// <param name="fileToken">File token</param>
        /// <returns>Validation if file exist or not</returns>
        [Route("validatedocument")]
        [HttpGet]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> ValidateFileUsinToken(string fileToken)
        {
            try
            {
                var documentResult = await documentRepository.GetByTokenFileShare(fileToken);
                if (documentResult == null) return this.NotFound();
                if (!await this.authorizationMiddleware.validateUserById(Request,documentResult.CarrierId ?? 0)) return this.Unauthorized();
                var results = await sftpClient.DownloadFile(new Walmart.Common.SecureFtpClient.BlobDownloadRequest { FileId = fileToken }, secretHelper.getSTFPServer());

                if (!results.Success)
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                               results.Messages ?? Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                return Ok(new
                {
                    Result = 1,
                    FileName = results.BlobFileName
                });
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.ExceptionMessage));
            }
        }

        /// <summary>
        /// Get iterals
        /// </summary>
        /// <param name="document">Carrier document</param>
        /// <param name="onlyCodes">Only code</param>
        /// <returns>A populated documents</returns>
        private async Task<CarrierDocument> GetLiterals(CarrierDocument document, bool onlyCodes = false)
        {
            var carrier = await carrierRepository.GetByCarrierId(document.CarrierId.Value);

            if (carrier != null)
            {
                document.LiteralCarrier = $"{carrier.CarrierCode} {carrier.CarrierName ?? carrier.BusinessName}";
            }

            var generic = await genericRepository.GetItem(genericRepository.GetIdentifier(document));

            if (generic != null)
            {
                document.LiteralTransports = $"{generic.Code} {generic.Description ?? generic.CarrierName}";

                var type = generic.Identifier.Substring(generic.Identifier.Length - 1);

                if (onlyCodes)
                {
                    switch (type.ToUpper())
                    {
                        case "V":
                            document.LiteralUnit = $"{generic.Code}";
                            break;

                        case "P":
                            document.LiteralPilot = $"{generic.Code}";
                            break;

                        case "F":
                            document.LiteralBoxCar = $"{generic.Code}";
                            break;

                        default:
                            break;
                    }
                }
                else
                {
                    switch (type.ToUpper())
                    {
                        case "V":
                            document.LiteralUnitBoxCar = $"{generic.Code} {generic.Description ?? generic.CarrierName}";
                            break;

                        case "P":
                            document.LiteralPilot = $"{generic.Code} {generic.Description ?? generic.CarrierName}";
                            break;

                        case "F":
                            document.LiteralUnitBoxCar = $"{generic.Code} {generic.Description ?? generic.CarrierName}";
                            break;

                        default:
                            break;
                    }
                }
            }

            document.LiteralExpirationDate = document.ExpirationDate.Value.ToShortDateString();
            document.LiteralNotificationDate = document.NotificationDate.Value.ToShortDateString();
            document.LiteralCreationDate = document.CreationDate.Value.ToShortDateString();

            ////document.LiteralActive = document.Active == true ? "Habilitado" : "Inhabilitado";

            document.LiteralActive = document.ExpirationDate.Value.Date >= DateTime.Now.Date ? "Habilitado" : "Inhabilitado";

            if (document.ExpirationDate.Value.Date < DateTime.Now.Date)
            {
                document.IsApprove = 4;
                document.LiteralActive = "Inhabilitado";
            }
            else if (document.IsApprove == 2)
            {
                document.StatusDocument = Resources.Documents.StatusApproved;
            }
            else if (document.IsApprove == 1)
            {
                document.StatusDocument = Resources.Documents.StatusAprovePending;
            }
            if (document.IsApprove == 3)
            {
                document.StatusDocument = Resources.Documents.StatusExpiredDate;
            }

            //if (document.IsApprove == 2)
            //{
            //    document.StatusDocument = Resources.Documents.StatusApproved;
            //}
            //else if (document.IsApprove == 3)
            //{
            //    document.StatusDocument = Resources.Documents.StatusExpiredDate;
            //}
            //else
            //{
            //    document.StatusDocument = Resources.Documents.StatusAprovePending;
            //}

            return document;
        }
    }
}
