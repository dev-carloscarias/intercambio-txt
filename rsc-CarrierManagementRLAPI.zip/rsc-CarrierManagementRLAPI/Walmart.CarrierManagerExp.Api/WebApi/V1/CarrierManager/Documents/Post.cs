//---------------------------------------------------------------------------------------
// <copyright file="Post.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.Common.Helpers;
    using Walmart.CarrierManagerExp.Api.Resources.Main;

    #endregion Using

    /// <summary>
    /// Documents controller post methods
    /// </summary>
    public partial class DocumentsController : BaseApiMasterServiceController
    {
        #region Methods

        /// <summary>
        /// Create a new document
        /// Set Content-Type:<code>Application/Json</code>
        /// </summary>
        /// <param name="document">Product entity</param>
        /// <returns>Result response</returns>
        [HttpPost]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        [Route("")]
        public async Task<IActionResult> Post([FromForm] CarrierDocument document)
        {
            try
            {
                if (!await this.authorizationMiddleware.validateUserById(Request, document.CarrierId ?? 0)) return this.Unauthorized();
                var uploadResult = await UploadFile(document);
                

                if (!ModelState.IsValid)
                {
                    return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.InvalidDataUserMessage,
                     (int)System.Net.HttpStatusCode.BadRequest));
                }

                var objResult = await documentRepository.GetItems();

                if (objResult != null && objResult.Any())
                {
                    var objSearch = objResult.ToList().FindAll(o => o.CarrierIdF == document.CarrierIdF &&
                        o.CarrierIdV == document.CarrierIdV &&
                            o.CarrierIdP == document.CarrierIdP &&
                                o.CountryId == document.CountryId &&
                                    o.CarrierId == document.CarrierId &&
                                        o.DocumentTypeId == document.DocumentTypeId);

                    if (objSearch != null && objSearch.Any())
                    {
                        return BadRequest(
                        ErrorMessageManagement.SetsErrorMessages(
                            V1.Resources.Documents.Error2345,
                            (int)System.Net.HttpStatusCode.Conflict));

                    }
                }


                if (!uploadResult.Success)
                {
                    if (!string.IsNullOrEmpty(uploadResult.Messages))
                    {
                        logger.LogError(uploadResult.Messages);
                    }

                    return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        V1.Resources.Documents.Error6,
                     (int)System.Net.HttpStatusCode.BadGateway));
                }

                document.TokenFileShare = uploadResult.FileId;

                var response = await documentRepository.Add(document);

                if (response > 0)
                {
                    var obj = await GetGenericAsync(document);

                    documentRepository.SendNotifications(document, obj);

                    if (document.CarrierIdP != null)
                    {
                        var countries = await this.countryRepository.GetAll();

                        if (document.CountryId == countries.Where(c => c.CountryName.ToUpper() == "EL SALVADOR").FirstOrDefault().Id)
                        {
                            var documentTyoe = await this.documentTypeRepository.GetIAllowedDays(document.CarrierId.Value, document.CarrierIdP.Value);

                            if (documentTyoe != null && documentTyoe.AllowedDays != null)
                            {
                                var pilot = this.pilotRepository.Get(null, null, id: document.CarrierIdP.Value, carrierId: document.CarrierId.Value).Result.FirstOrDefault();

                                return Ok(new
                                {
                                    Status = "Ok",
                                    Notification = true,
                                    Period = documentTyoe.AllowedDays.Value,
                                    pilot.PilotCode,
                                    pilot.PilotName
                                });
                            }
                        }
                    }

                    return Ok(response);
                }
                else
                {
                    var errorMessage = Messages.NoAddRecordUserMessage;

                    switch (response)
                    {
                        case -2:
                            errorMessage = V1.Resources.Documents.Error2345;
                            break;

                        case -3:
                            errorMessage = V1.Resources.Documents.Error2345;
                            break;

                        case -4:
                            errorMessage = V1.Resources.Documents.Error2345;
                            break;

                        case -5:
                            errorMessage = V1.Resources.Documents.Error2345;
                            break;

                        default:
                            break;
                    }

                    return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        errorMessage,
                     (int)System.Net.HttpStatusCode.Conflict));
                }
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                logger.LogError(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.ExceptionMessage));
            }
        }

        #endregion Methods
    }
}