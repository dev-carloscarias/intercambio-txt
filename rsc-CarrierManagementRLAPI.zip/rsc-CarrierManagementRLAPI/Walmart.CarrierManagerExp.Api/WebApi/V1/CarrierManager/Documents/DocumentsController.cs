//---------------------------------------------------------------------------------------
// <copyright file="DocumentTypeController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    using System.Threading.Tasks;
    #region Using

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Walmart.CarrierManagerExp.Api.Common.Middlewares.Authorization;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.Common.Helpers.Handlers;

    #endregion Using

    /// <summary>
    /// Document controller
    /// </summary>
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route(Path + "api/v{version:apiVersion}/document")]
    public partial class DocumentsController : BaseApiMasterServiceController
    {
        #region Fields

        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<DocumentsController> logger;

        /// <summary>
        /// Configuration interface
        /// </summary>
        private readonly IOptions<AppSettings> configuration;

        /// <summary>
        /// sftp client
        /// </summary>
        private ISftpClient sftpClient;

        /// <summary>
        /// Document repository
        /// </summary>
        private IDocumentsRepository documentRepository;

        /// <summary>
        /// Document repository
        /// </summary>
        private ICarrierRepository carrierRepository;

        /// <summary>
        /// Carrier  repository
        /// </summary>
        private IGenericRepository genericRepository;

        /// <summary>
        /// box car repository
        /// </summary>
        private IBoxCarRepository boxCarRepository;

        /// <summary>
        /// Pilot repository
        /// </summary>
        private IPilotRepository pilotRepository;

        /// <summary>
        /// Vehicle repository
        /// </summary>
        private IVehicleRepository vehicleRepository;

        /// <summary>
        /// Contry repository
        /// </summary>
        private ICountryRepository countryRepository;

        /// <summary>
        /// Document type
        /// </summary>
        private IDocumentTypeRepository documentTypeRepository;

        private IAuthorizationMiddleware authorizationMiddleware;

        #endregion Fields

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentsController" /> class
        /// </summary>
        /// <param name="documentRepository">Carrier document repository</param>
        /// <param name="genericRepository">TMS Carrier generic repository</param>
        /// <param name="carrierRepository">TMS Carrier repository</param>
        /// <param name="boxCarRepository">Box car repository</param>
        /// <param name="pilotRepository">Pilot repository</param>
        /// <param name="vehicleRepository">Vehicle repository</param>
        /// <param name="countryRepository">Country repository</param>
        /// <param name="documentTypeRepository">Document type repository</param>
        /// <param name="secretHelper">Secret Helper repository</param>
        /// <param name="logger">Logger class</param>
        /// <param name="configuration">Apps settings configuration constans</param>
        /// <param name="sftpClient">Sfpt client for documents management</param>
        /// <param name="memoryCacheHelper">Memory cache helper</param>
        public DocumentsController(IDocumentsRepository documentRepository, IGenericRepository genericRepository, ICarrierRepository carrierRepository, IBoxCarRepository boxCarRepository, IPilotRepository pilotRepository, IVehicleRepository vehicleRepository, ICountryRepository countryRepository, IDocumentTypeRepository documentTypeRepository, ILogger<DocumentsController> logger, IOptions<AppSettings> configuration, ISftpClient sftpClient, IMemoryCacheHelper memoryCacheHelper, ISecretHelper secretHelper, IAuthorizationMiddleware authorizationMiddleware) : base (configuration, logger, sftpClient, memoryCacheHelper, secretHelper)
        {
            this.documentRepository = documentRepository;
            this.logger = logger;
            this.configuration = configuration;
            this.sftpClient = sftpClient;
            this.genericRepository = genericRepository;
            this.carrierRepository = carrierRepository;
            this.boxCarRepository = boxCarRepository;
            this.pilotRepository = pilotRepository;
            this.vehicleRepository = vehicleRepository;
            this.countryRepository = countryRepository;
            this.documentTypeRepository = documentTypeRepository;
            this.authorizationMiddleware = authorizationMiddleware;
        }

        /// <summary>
        /// Get a generic carrier 
        /// </summary>
        /// <param name="document">Carier document</param>
        /// <returns>A generic carrier entity</returns>
        protected async Task<GenericCarrier> GetGenericAsync(CarrierDocument document)
        {
            var obj = await genericRepository.GetItem(genericRepository.GetIdentifier(document));

            return obj;
        }


        #endregion Constructor
    }
}