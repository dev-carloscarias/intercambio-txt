//---------------------------------------------------------------------------------------
// <copyright file="ReportsController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    using System.Threading.Tasks;
    #region Using

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Walmart.CarrierManagerExp.Api.Common.Middlewares.Authorization;
    using Walmart.CarrierManagerExp.Api.Repository;

    #endregion Using

    /// <summary>
    /// Report partial class controller
    /// </summary>
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route(Path + "api/v{version:apiVersion}/report")]
    public partial class ReportsController : BaseApiController
    {
        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<ReportsController> logger;

        /// <summary>
        /// Carrier repository interface
        /// </summary>
        private IReportRepository reportRepository;

        /// <summary>
        /// Tms report repository interface
        /// </summary>
        private ITmsCarrierReportRepository tmsCarrierReport;
        private IAuthorizationMiddleware authorizationMiddleware;

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportsController" /> class
        /// </summary>
        /// <param name="logger">Logger repository for errors events</param>
        /// <param name="reportRepository">Report repository</param>
        /// <param name="tmsCarrierReport">Tms carrier report repository</param>
        public ReportsController (ILogger<ReportsController> logger, IReportRepository reportRepository, ITmsCarrierReportRepository tmsCarrierReport, IAuthorizationMiddleware authorizationMiddleware)
        {
            this.logger = logger;
            this.reportRepository = reportRepository;
            this.tmsCarrierReport = tmsCarrierReport;
            this.authorizationMiddleware = authorizationMiddleware;
        }
    }
}
