//---------------------------------------------------------------------------------------
// <copyright file="Get.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    using System.Collections.Generic;

    #region Using

    using System.Data.SqlClient;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using


    /// <summary>
    /// Report partial class controller get actions
    /// </summary>
    public partial class ReportsController : BaseApiController
    {

        /// <summary>
        /// Get document status report
        /// </summary>
        /// <param name="carrierId">Carrier id</param>
        /// <param name="documentType">Document type id</param>
        /// <param name="carrierIdF">Carrier box car id</param>
        /// <param name="carrierIdV">Carrier vehicle id</param>
        /// <param name="carrierIdP">Carrier pilot id</param>
        /// <param name="applyFor">Applay for specific kind of docuemnts</param>
        /// <returns>Document status report</returns>
        [Route("statusreport/{carrierId}")]
        [HttpGet]
        [ProducesResponseType(typeof(CarrierDocument), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> Get(int carrierId, int? documentType = null, int? carrierIdF = null, int? carrierIdV = null, int? carrierIdP = null, string applyFor = " ")
        {
            try
            {
                if (!await this.authorizationMiddleware.validateUserById(Request, carrierId)) return this.Unauthorized();
                var results = await reportRepository.GetReport(carrierId, documentType, carrierIdF, carrierIdV, carrierIdP, System.Web.HttpUtility.UrlDecode(applyFor));

                if (results == null || !results.Any())
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                string ids = string.Empty;

                var unique = results.GroupBy(x => x.CarrierIdentifier).Select(g => g.First());

                unique.ToList().ForEach(r =>
                {
                    ids = ids + r.CarrierIdentifier + ",";
                });

                var tmsReports = await tmsCarrierReport.GetReportByIdentifiers(ids);

                if (tmsReports == null || !tmsReports.Any())
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                var reporMix = results.ToList().Select(r =>
                {
                    var find = tmsReports.ToList().Find(rp => rp.Identifier == r.Identifier);

                    if (find != null)
                    {
                        r.Description = find.Description;
                        r.Code = find.Code;
                        r.Identifier = find.Identifier;
                        r.CountryName = find.CountryName;
                        r.Name = find.Name;
                    }
                    
                    return r;
                }).AsQueryable();

                results = reporMix.Where(c => !string.IsNullOrEmpty(c.Code));

                return Ok(results);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.ExceptionMessage));
            }
        }
    }
}
