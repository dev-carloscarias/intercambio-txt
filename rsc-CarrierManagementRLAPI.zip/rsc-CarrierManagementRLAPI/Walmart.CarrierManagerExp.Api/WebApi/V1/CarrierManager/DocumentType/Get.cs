﻿//---------------------------------------------------------------------------------------
// <copyright file="Get.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using

    /// <summary>
    /// Document type controller get methods
    /// </summary>
    public partial class DocumentTypeController : BaseApiController
    {
        /// <summary>
        /// Get Document types.
        /// </summary>
        /// <param name="countryId">Country id</param>
        /// <param name="applyTo">Apply to</param>
        /// <param name="documentTypeId">Document type id</param>
        /// <returns>Document types collection</returns>
        [Route("")]
        [HttpGet]
        [ProducesResponseType(typeof(DocumentType), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> Get(int countryId = 0, string applyTo = "", int documentTypeId = 0)
        {
            try
            {
                var results = await documentTypeRepository.GetItems(countryId, applyTo, documentTypeId);

                if (results == null || !results.Any())
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                return Ok(results);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }
    }
}