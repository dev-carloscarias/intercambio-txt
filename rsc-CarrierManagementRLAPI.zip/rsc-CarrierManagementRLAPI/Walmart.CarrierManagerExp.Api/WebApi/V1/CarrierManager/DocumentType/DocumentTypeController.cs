﻿//---------------------------------------------------------------------------------------
// <copyright file="DocumentTypeController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;

    #endregion Using

    /// <summary>
    /// Document type controller
    /// </summary>
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route(Path + "api/v{version:apiVersion}/documentType")]
    public partial class DocumentTypeController : BaseApiController
    {
        #region Fields

        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<DocumentTypeController> logger;

        /// <summary>
        /// Document type repository
        /// </summary>
        private IDocumentTypeRepository documentTypeRepository;

        #endregion Fields

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentTypeController" /> class
        /// </summary>
        /// <param name="documentTypeRepository">Document type repository</param>
        /// <param name="logger">Document type controller logger</param>
        public DocumentTypeController(IDocumentTypeRepository documentTypeRepository, ILogger<DocumentTypeController> logger)
        {
            this.documentTypeRepository = documentTypeRepository;
            this.logger = logger;
        }

        #endregion Constructor
    }
}