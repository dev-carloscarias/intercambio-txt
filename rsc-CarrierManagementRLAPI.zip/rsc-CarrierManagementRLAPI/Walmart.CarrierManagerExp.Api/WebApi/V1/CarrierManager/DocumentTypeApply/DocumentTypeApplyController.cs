//---------------------------------------------------------------------------------------
// <copyright file="DocumentTypeApplyController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;

    #endregion Using

    /// <summary>
    /// Document type apply partial controller
    /// </summary>
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route(Path + "api/v{version:apiVersion}/documentTypeApply")]
    public partial class DocumentTypeApplyController : BaseApiController
    {
        #region Fields

        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<DocumentTypeApplyController> logger;

        /// <summary>
        /// Document type repository
        /// </summary>
        private IDocumentTypeApplyRepository documentTypeApplyRepository;

        #endregion Fields

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentTypeApplyController" /> class
        /// </summary>
        /// <param name="documentTypeApplyRepository">Document type repository</param>
        /// <param name="logger">Document type controller logger</param>
        public DocumentTypeApplyController(IDocumentTypeApplyRepository documentTypeApplyRepository, ILogger<DocumentTypeApplyController> logger)
        {
            this.documentTypeApplyRepository = documentTypeApplyRepository;
            this.logger = logger;
        }

        #endregion Constructor
    }
}
