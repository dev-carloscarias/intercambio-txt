//---------------------------------------------------------------------------------------
// <copyright file="Get.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Linq;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using

    /// <summary>
    /// Document type apply controller get methods
    /// </summary>
    public partial class DocumentTypeApplyController : BaseApiController
    {
        /// <summary>
        /// Get document type apply using filters
        /// </summary>
        /// <param name="id">Record id</param>
        /// <param name="applyTo">Apply name</param>
        /// <param name="applyToEn">Apply name in english</param>
        /// <param name="active">Inidicates if have active or not records</param>
        /// <returns></returns>
        [Route("")]
        [HttpGet]
        [ProducesResponseType(typeof(DocumentTypeApply), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> Get(int? id = null, string applyTo = "", string applyToEn = "", bool? active = null)
        {
            try
            {
                var results = await documentTypeApplyRepository.GetItems(id, applyTo, applyToEn, active);

                if (results == null || !results.Any())
                {
                    return BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                return Ok(results);
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }
    }
}
