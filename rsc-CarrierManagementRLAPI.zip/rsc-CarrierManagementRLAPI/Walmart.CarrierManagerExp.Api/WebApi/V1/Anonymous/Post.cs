﻿//---------------------------------------------------------------------------------------
// <copyright file="Post.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Logging;
    using Microsoft.AspNetCore.Mvc;
    using Repository;
    using Walmart.Common.Helpers;
    using Walmart.CarrierManagerExp.Api.Resources.Main;

    #endregion Using

    /// <summary>
    /// Controller example partial class
    /// </summary>
    public partial class ProductsWTController : BaseApiController
    {
        #region Methods

        /// <summary>
        /// Example to creates a new product.
        /// Use the POST http verb.
        /// Set Content-Type:<code>Application/Json</code>
        /// </summary>
        /// <param name="product">Product entity</param>
        /// <returns>Result response</returns>
        [HttpPost]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        [Route("")]
        public async Task<IActionResult> Post([FromBody] Product product)
        {
            var affected = 0;
            try
            {
                if (!this.ModelState.IsValid)
                {
                    return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.InvalidDataUserMessage,
                     (int)System.Net.HttpStatusCode.BadRequest));
                }

                affected = await this.productRepository.Add(product);

                if (affected > 0)
                {
                    return this.Ok(affected);
                }
                else
                {
                    return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.NoAddRecordUserMessage,
                     (int)System.Net.HttpStatusCode.Conflict));
                }
            }
            catch (SqlException ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogError(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogDebug(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        #endregion Methods
    }
}