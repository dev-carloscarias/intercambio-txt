﻿//---------------------------------------------------------------------------------------
// <copyright file="Put.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Logging;
    using Repository;
    using Walmart.Common.Helpers;
    using Microsoft.AspNetCore.Mvc;
    using System.Net;
    using Walmart.CarrierManagerExp.Api.Resources.Main;

    #endregion Using

    /// <summary>
    /// Controller example partial class
    /// </summary>
    public partial class ProductsWTController : BaseApiController
    {
        #region Methods

        /// <summary>
        /// Example to saves the entire Product object to the object specified by key (id). Is supposed to overwrite all properties
        /// Use the PUT http verb
        /// <code>Set Content-Type:Application/Json</code>
        /// </summary>
        /// <param name="id">Product identity</param>
        /// <param name="product">Product entity</param>
        /// <returns>Response result</returns>
        [HttpPut]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        [Route("{id}", Name = "PutOneWt")]
        public async Task<IActionResult> Put(int id, [FromBody] Product product)
        {
            var affected = 0;
            BadRequestObjectResult br_NoUpdateRecordUserMessage;
            BadRequestObjectResult br_SqlExceptionUserMessage;
            BadRequestObjectResult br_InvalidModelUserMessage;

            br_NoUpdateRecordUserMessage = this.BadRequest(
                                                ErrorMessageManagement.SetsErrorMessages(
                                                Messages.NoUpdateRecordUserMessage,
                                                (int)System.Net.HttpStatusCode.Conflict));

            br_SqlExceptionUserMessage = this.BadRequest(
                                            ErrorMessageManagement.SetsErrorMessages(
                                            Messages.SqlExceptionUserMessage));

            br_InvalidModelUserMessage = this.BadRequest(
                                            ErrorMessageManagement.SetsErrorMessages(
                                            Messages.InvalidModelUserMessage,
                                            (int)System.Net.HttpStatusCode.BadRequest));

            try
            {
                if (!this.ModelState.IsValid)
                {
                    return br_InvalidModelUserMessage;
                }

                affected = await this.productRepository.Update(product);

                logger.LogInformation("Affected = ", affected);

                if (affected > 0)
                {
                    return this.Ok(affected);
                }
                else
                {
                    return br_NoUpdateRecordUserMessage;
                }
            }
            catch (SqlException ex)
            {
                this.logger.LogError(ex.GetType().FullName, id, "Error updating product", br_SqlExceptionUserMessage, ex.ToString());
                this.logger.LogDebug(ex.GetType().FullName, id, "Error updating product", br_SqlExceptionUserMessage, ex.ToString());
                return br_SqlExceptionUserMessage;
            }
            catch (System.Exception ex)
            {
                this.logger.LogError(ex.GetType().FullName, id, br_SqlExceptionUserMessage, "Error updating product", ex);
                this.logger.LogDebug(ex.GetType().FullName, id, "Error updating product", ex);
                return br_SqlExceptionUserMessage;
            }
            finally
            {
               
            }
        }

        #endregion Methods
    }
}