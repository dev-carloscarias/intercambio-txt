//---------------------------------------------------------------------------------------
// <copyright file="CountryController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    using System.Threading.Tasks;
    #region Using

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Walmart.CarrierManagerExp.Api.Repository;

    #endregion Using

    /// <summary>
    /// Country controller
    /// </summary>
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route(Path + "api/v{version:apiVersion}/masterservcices/countries")]
    public partial class CountryController : BaseApiController
    {
        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<CountryController> logger;

        /// <summary>
        /// Country repository
        /// </summary>
        private ICountryRepository countryRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="CountryController" /> class
        /// </summary>
        /// <param name="countryRepository">Country repository</param>
        /// <param name="logger">Country controller logger</param>
        public CountryController(ICountryRepository countryRepository, ILogger<CountryController> logger)
        {
            this.countryRepository = countryRepository;
            this.logger = logger;
        }

    }
}
