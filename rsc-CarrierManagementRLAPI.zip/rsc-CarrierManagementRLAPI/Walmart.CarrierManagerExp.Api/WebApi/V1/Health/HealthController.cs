﻿using Microsoft.AspNetCore.Mvc;

namespace Walmart.CarrierManagerExp.Api.V1
{
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route(Path + "api/v{version:apiVersion}/Health")]
    public partial class HealthController : BaseApiController
    {

        public HealthController() { }
    }
}
