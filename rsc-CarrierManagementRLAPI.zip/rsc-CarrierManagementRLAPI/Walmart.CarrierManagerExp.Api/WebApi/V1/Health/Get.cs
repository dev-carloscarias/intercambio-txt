﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Walmart.CarrierManagerExp.Api.V1
{
    public partial class HealthController : BaseApiController
    {
        [Route("")]
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return this.Ok();
        }
    }
}
