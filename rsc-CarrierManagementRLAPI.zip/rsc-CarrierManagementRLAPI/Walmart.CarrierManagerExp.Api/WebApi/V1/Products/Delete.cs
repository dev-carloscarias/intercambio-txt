﻿//---------------------------------------------------------------------------------------
// <copyright file="Delete.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
   using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using

    /// <summary>
    /// Controller example partial class
    /// </summary>
    public partial class ProductsController : BaseApiController
    {
        #region Methods

        /// <summary>
        /// Example for use of the verb HTTP DELETE
        /// </summary>
        /// <param name="id">Product code</param>
        /// <returns>Integer value</returns>
        [HttpDelete, Authorize]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        [Route("{id}", Name = "DeleteOne")]
        public async Task<IActionResult> Delete(int id)
        {
            var affected = 0;

            try
            {
                if (!this.ModelState.IsValid)
                {
                    return this.BadRequest(ErrorMessageManagement.SetsErrorMessages(
                        Messages.InvalidDataUserMessage,
                    (int)System.Net.HttpStatusCode.BadRequest));
                }

                affected = await this.productRepository.Delete(id.ToString());

                if (affected > 0)
                {
                    return this.Ok(affected);
                }
                else
                {
                    return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.NotFoundRecordUserErrorMessage,
                    (int)System.Net.HttpStatusCode.BadRequest));
                }
            }
            catch (SqlException ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogError(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogError(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.ExceptionMessage));
            }
        }

        #endregion Methods
    }
}