﻿//---------------------------------------------------------------------------------------
// <copyright file="ProductsController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;

    #endregion Using

    /// <summary>
    /// Products Controller sample
    /// </summary>
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route("api/v{version:apiVersion}/products")]
    public partial class ProductsController : BaseApiController
    {
        #region Fields

        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<ProductsWTController> logger;

        /// <summary>
        /// Product repository
        /// </summary>
        private IProductRepository productRepository;

        #endregion Fields

        #region Constructor

        /// <summary>
        ///
        /// </summary>
        /// <param name="productRepository"></param>
        /// <param name="logger"></param>
        public ProductsController(IProductRepository productRepository, ILogger<ProductsWTController> logger)
        {
            this.productRepository = productRepository;
            this.logger = logger;
        }

        #endregion Constructor
    }
}