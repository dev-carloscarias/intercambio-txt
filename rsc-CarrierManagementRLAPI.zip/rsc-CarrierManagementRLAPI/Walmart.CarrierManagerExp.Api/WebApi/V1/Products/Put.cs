﻿//---------------------------------------------------------------------------------------
// <copyright file="Put.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Repository;
    using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using

    /// <summary>
    /// Controller example partial class
    /// </summary>
    public partial class ProductsController : BaseApiController
    {
        #region Methods

        /// <summary>
        /// Example to saves the entire Product object to the object specified by key (id). Is supposed to overwrite all properties
        /// Use the PUT http verb
        /// <code>Set Content-Type:Application/Json</code>
        /// </summary>
        /// <param name="id">Product identity</param>
        /// <param name="product">Product entity</param>
        /// <returns>Response result</returns>
        [HttpPut, Authorize]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        [Route("{id}", Name = "PutOne")]
        public async Task<IActionResult> Put(int id, [FromBody] Product product)
        {
            var affected = 0;
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                       Messages.InvalidModelUserMessage,
                    (int)System.Net.HttpStatusCode.BadRequest));
                }

                affected = await productRepository.Update(product);

                if (affected > 0)
                {
                    return Ok(affected);
                }
                else
                {
                    return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.NoUpdateRecordUserMessage,
                    (int)System.Net.HttpStatusCode.Conflict));
                }
            }
            catch (SqlException ex)
            {
                logger.LogDebug(ex.ToString());
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                logger.LogDebug(ex.ToString());
                logger.LogDebug(ex.ToString());
                return BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        #endregion Methods
    }
}