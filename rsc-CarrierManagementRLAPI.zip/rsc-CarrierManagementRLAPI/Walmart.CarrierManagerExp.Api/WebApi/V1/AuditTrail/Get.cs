﻿//---------------------------------------------------------------------------------------
// <copyright file="Get.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Net;
    using System.Threading.Tasks;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.Common.Helpers;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Resources.Main;

    #endregion Using

    /// <summary>
    /// Audit trail controller class
    /// </summary>
    public partial class AuditTrailController : BaseApiController
    {
        #region Methods

        /// <summary>
        /// Use the Get http verb
        /// </summary>
        /// GET api/v1/audittrail
        /// <returns>Audit trail collection</returns>
        [HttpGet, Authorize]
        [ProducesResponseType(typeof(IEnumerable<AuditTrail>), (int)HttpStatusCode.OK)]
        [Route("")]
        public async Task<IActionResult> Get()
        {
            try
            {
                return this.Ok(await this.auditTrailRepository.GetAll());
            }
            catch (SqlException ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogError(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogError(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        /// <summary>
        /// Get audit trail entity
        /// </summary>
        /// <param name="id">Audit trail property</param>
        /// GET api/v1/audittrail/1
        /// <returns>Audit trail entity</returns>
        [HttpGet, Authorize]
        [ProducesResponseType(typeof(AuditTrail), (int)HttpStatusCode.OK)]
        [Route("{id}", Name = "GetOneAudit")]
        public async Task<IActionResult> Get(int id)
        {
            try
            {
                var auditTrail = await this.auditTrailRepository.GetItem(id.ToString(CultureInfo.InvariantCulture));

                if (auditTrail == null)
                {
                    return this.BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         System.Net.HttpStatusCode.NotFound.ToString()));
                }

                return this.Ok(auditTrail);
            }
            catch (SqlException ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogError(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogError(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        #endregion Methods
    }
}