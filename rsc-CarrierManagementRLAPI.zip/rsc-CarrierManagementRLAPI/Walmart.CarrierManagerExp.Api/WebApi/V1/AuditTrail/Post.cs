﻿//---------------------------------------------------------------------------------------
// <copyright file="Post.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using System.Data.SqlClient;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Repository;
    using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using

    /// <summary>
    /// Audit trail controller class
    /// </summary>
    public partial class AuditTrailController : BaseApiController
    {
        #region Methods

        /// <summary>
        /// Add audit trail log
        /// </summary>
        /// <param name="audit">Audit trail entity</param>
        /// <returns>Result response</returns>
        [HttpPost, Authorize]
        [ProducesResponseType(typeof(int), (int)HttpStatusCode.OK)]
        [Route("")]
        public async Task<IActionResult> Post([FromBody] AuditTrail audit)
        {
            var affected = 0;
            try
            {
                if (!this.ModelState.IsValid)
                {
                    return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.InvalidDataUserMessage,
                        HttpStatusCode.BadRequest.ToString()));
                }

                affected = await this.auditTrailRepository.Add(audit);

                if (affected > 0)
                {
                    return this.Ok(affected);
                }
                else
                {
                    return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.NoAddRecordUserMessage,
                        HttpStatusCode.Conflict.ToString()));
                }
            }
            catch (SqlException ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogDebug(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogDebug(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        #endregion Methods

    }
}