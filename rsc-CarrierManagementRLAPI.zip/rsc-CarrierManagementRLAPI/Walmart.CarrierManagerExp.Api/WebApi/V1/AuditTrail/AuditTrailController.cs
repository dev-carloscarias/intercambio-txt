﻿//---------------------------------------------------------------------------------------
// <copyright file="AuditTrailController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V1
{
    #region Using

    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Repository;

    #endregion Using

    /// <summary>
    /// AuditTrail Controller sample
    /// </summary>
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route("api/v{version:apiVersion}/audittrail")]
    public partial class AuditTrailController : BaseApiController
    {
        #region Fields

        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<ProductsWTController> logger;

        /// <summary>
        /// Audit trail repository
        /// </summary>
        private IAuditTrailRepository auditTrailRepository;

        #endregion Fields

        #region Constructor

        /// <summary>
        ///
        /// </summary>
        /// <param name="auditTrailRepository"></param>
        /// <param name="logger"></param>
        public AuditTrailController(IAuditTrailRepository auditTrailRepository, ILogger<ProductsWTController> logger)
        {
            this.auditTrailRepository = auditTrailRepository;
            this.logger = logger;
        }

        #endregion Constructor
    }
}