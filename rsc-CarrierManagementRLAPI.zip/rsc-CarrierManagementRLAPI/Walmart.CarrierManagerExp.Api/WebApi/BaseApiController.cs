﻿//---------------------------------------------------------------------------------------
// <copyright file="BaseApiController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api
{
    using Microsoft.AspNetCore.Cors;
    #region Using

    using Microsoft.AspNetCore.Mvc;
    using Walmart.Common.Helpers.Handlers;

    #endregion Using

    /// <summary>
    /// Base controller class
    /// </summary>
    [EnableCors("AllowOrigin")]
    public class BaseApiController : ControllerBase
    {
        /// <summary>
        /// Get realtive path
        /// </summary>
        protected const string Path = "carriermanagement/";
        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseApiController" /> class
        /// </summary>
        public BaseApiController()
        {
  
        }

        #endregion Constructor
    }
}