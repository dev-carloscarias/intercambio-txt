//---------------------------------------------------------------------------------------
// <copyright file="SftpMasterService.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api
{
    using System;
    using System.IO;
    using System.Net.Http.Headers;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.Common.SecureFtpClient;

    /// <summary>
    /// Master Services web api
    /// </summary>
    public partial class BaseApiMasterServiceController : BaseApiController
    {
        /// <summary>
        /// Upload file using master services
        /// </summary>
        /// <param name="document">Document entity</param>
        /// <returns>Blobupload model result</returns>
        protected async Task<BlobUploadResponse> UploadFile(CarrierDocument document)
        {
            IFormFile file = document.File;
            var sftpEntity = new BlobUploadRequest();
            byte[] bytes = null;
            string fileName = string.Empty;

            if (file != null && file.Length > 0)
            {

                
                fileName = System.IO.Path.GetFileName(file.FileName);
                if (fileName.Contains("..") || fileName.Contains("/") || fileName.Contains("\\"))
                {
                    throw new ArgumentException("Invalid filename: Path traversal detected");
                }

                using (var reader = new MemoryStream())
                {

                    file.CopyTo(reader);
                    bytes = reader.ToArray();
                    
                }
            }

            sftpEntity = new BlobUploadRequest
            {
                SensitiveData = true,
                FileName = fileName,
                UserName = document.ActionUser,
                File = bytes
            };

            BlobUploadResponse blobUpResult = await SftpClient.UploadFile(sftpEntity, this.secretHelper.getSTFPServer());

            return blobUpResult;
        }

        /// <summary>
        /// Download file using file token
        /// </summary>
        /// <param name="key">File token</param>
        /// <returns>BlobDownModel resut</returns>
        protected async Task<BlobDownloadResponse> DownLoadFile(string key)
        {
            BlobDownloadRequest down = new BlobDownloadRequest
            {
                FileId = key
            };

            BlobDownloadResponse blobDownResult = await SftpClient.DownloadFile(down, this.secretHelper.getSTFPServer());

            return blobDownResult;
        }
    }
}