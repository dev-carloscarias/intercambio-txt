//---------------------------------------------------------------------------------------    
// <copyright file="ISftpClient.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Aguero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api
{
    using System;
    using System.Net.Http;
    using System.Threading.Tasks;
    using Walmart.Common.SecureFtpClient;

    /// <summary>
    /// File transfer interface
    /// </summary>
    public interface ISftpClient : IDisposable
    {
        /// <summary>
        /// Send request to post web REST service resource add file using HttpClient
        /// </summary>
        /// <param name="entityRequest">File entity request</param>
        /// <param name="client">Http client</param>
        /// <param name="route">Master service route</param>
        /// <returns>File code</returns>
        Task<BlobUploadResponse> UploadFile(BlobUploadRequest entityRequest, string route);

        /// <summary>
        /// Send request to post web REST service resource to get file using HttpClient
        /// </summary>
        /// <param name="entityRequest">File code request</param>
        /// <param name="client">Http client</param>
        /// <param name="route">Master service route</param>
        /// <returns>Stream file</returns>
        Task<BlobDownloadResponse> DownloadFile(BlobDownloadRequest entityRequest, string route);
    }
}