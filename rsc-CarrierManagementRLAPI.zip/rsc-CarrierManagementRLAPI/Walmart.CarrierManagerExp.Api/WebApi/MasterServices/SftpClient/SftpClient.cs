//---------------------------------------------------------------------------------------
// <copyright file="SftpClient.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Aguero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api
{
    #region Using

    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.IO.Compression;
    using System.Linq;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Net.Security;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Newtonsoft.Json;
    using Walmart.CarrierManagerExp.Api.Common.Handlers.Helpers;
    using Walmart.Common.Helpers.Handlers;
    using Walmart.Common.Models;
    using Walmart.Common.SecureFtpClient;

    #endregion Using

    /// <summary>
    /// File transfer class
    /// </summary>
    public class SftpClient : ISftpClient
    {
        #region Fields

        /// <summary>
        /// Dispose value
        /// </summary>
        private bool disposedValue = false;

        #endregion Fields



        #region Public Methods

        /// <summary>
        /// Send request to post web REST service resource add file using HttpClient
        /// </summary>
        /// <param name="entityRequest">File entity request</param>
        /// <param name="client">Http client</param>
        /// <param name="route">Master service route</param>
        /// <returns>File code</returns>
        public async Task<BlobUploadResponse> UploadFile(BlobUploadRequest entityRequest, string route)
        {
            return await UploadFileMethodBlob(entityRequest, route);
        }

        /// <summary>
        /// Send request to post web REST service resource to get file using HttpClient
        /// </summary>
        /// <param name="entityRequest">File code request</param>
        /// <param name="client">Http client</param>
        /// <param name="route">Master service route</param>
        /// <returns>Stream file</returns>
        public async Task<BlobDownloadResponse> DownloadFile(BlobDownloadRequest entityRequest, string route)
        {
            return await DownloadFileMethodBlob(entityRequest, route);
        }

        #endregion Public Methods

        #region IDisposable Support

        /// <summary>
        /// This code added to correctly implement the disposable pattern.
        /// </summary>
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        /// <param name="disposing">Dispose property</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.
                disposedValue = true;
            }
        }

        #endregion IDisposable Support

        #region Private Methods

        /// <summary>
        /// Send request to post web REST service resource add file using HttpClient
        /// </summary>
        /// <param name="blobUploadRequest">File code request</param>
        /// <param name="client">Http client</param>
        /// <param name="route">Master service route</param>
        /// <returns>File code</returns>
        private async Task<BlobUploadResponse> UploadFileMethodBlob(BlobUploadRequest blobUploadRequest, string route)
        {
            try
            {
                var client = new HttpClient(new HttpClientHandler
                {
                    AutomaticDecompression = DecompressionMethods.None | DecompressionMethods.Deflate,
                    ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; }
                });
                client = WebApiFileManager(client);
                var body = new MultipartFormDataContent();
                var file = new ByteArrayContent(blobUploadRequest.File.Select(a => a).ToArray());
                file.Headers.ContentType = MediaTypeHeaderValue.Parse("multipart/form-data");

                body.Add(file, "file", blobUploadRequest.FileName);


                /*file.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
                {
                    FileName = blobUploadRequest.FileName
                };*/

                if (!string.IsNullOrEmpty(blobUploadRequest.FileId))
                {
                    body.Add(new StringContent(blobUploadRequest.FileId), "filedId");
                }
                if (!string.IsNullOrEmpty(blobUploadRequest.UserName))
                {
                    body.Add(new StringContent(blobUploadRequest.UserName), "username");
                }
                body.Add(new StringContent(Convert.ToInt32(blobUploadRequest.SensitiveData).ToString()), "sensitivedata");


                body.Add(file);

                var response = await client.PostAsync(
                    string.Format(
                        "{0}FileIndex", route),
                    body).ConfigureAwait(false);

                //// Obtener código de generación de archivo
                var content = await response.Content.ReadAsStreamAsync().ConfigureAwait(false);
                
                WebApiResponse result = JsonConvert.DeserializeObject<WebApiResponse>(response.Content.ReadAsStringAsync().Result);
                var test = result.Results.ToString();
                var uploadData = new BlobUploadResponse();

                if (result.Header.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var res = JsonConvert.DeserializeObject<List<BlobUploadResponse>>(result.Results.ToString());

                    uploadData.Success = true;
                    uploadData.FileId = res.FirstOrDefault().FileId;
                }
                else
                {
                    uploadData.Messages = result.Errors.UserMessage;
                }

                return await Task.FromResult(uploadData);
            } catch (Exception ex)
            {
                throw ex;
            }
            
        }

        /////// <summary>
        /////// Send request to post web REST service resource add file using HttpClient
        /////// </summary>
        /////// <param name="entityRequest">File entity request</param>
        /////// <returns>File code</returns>
        ////private async Task<BlobUploadResponse> UploadFileWithCredentials(BlobUploadRequest entityRequest)
        ////{
        ////    var webApiAudit = new HttpHandler();
        ////    var body = new MultipartFormDataContent();
        ////    var file = new ByteArrayContent(entityRequest.File.Select(a => a).ToArray());

        ////    file.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
        ////    {
        ////        FileName = entityRequest.FileName
        ////    };

        ////    file.Headers.ContentDisposition.Parameters.Add(
        ////       new NameValueHeaderValue(
        ////           "username",
        ////           entityRequest.SftpUserName));

        ////    file.Headers.ContentDisposition.Parameters.Add(
        ////        new NameValueHeaderValue(
        ////            "password",
        ////            entityRequest.SftpPassword));

        ////    file.Headers.ContentDisposition.Parameters.Add(
        ////        new NameValueHeaderValue(
        ////            "host",
        ////            entityRequest.SftpHost));

        ////    file.Headers.ContentDisposition.Parameters.Add(
        ////        new NameValueHeaderValue(
        ////            "port",
        ////       entityRequest.SftpPort.ToString()));

        ////    file.Headers.ContentDisposition.Parameters.Add(
        ////        new NameValueHeaderValue(
        ////            "sharefolder",
        ////        HttpUtility.UrlEncode(entityRequest.SftpShareFolder)));

        ////    body.Add(file);

        ////    var response = await webApiAudit.PostAsync(
        ////        string.Format(
        ////            "{0}FileIndex/Service.PostWithCredentials",
        ////            ServiceHelper.BaseAddress("SftpApi")),
        ////        body).ConfigureAwait(false);

        ////    //// Obtener código de generación de archivo
        ////    dynamic result = JsonConvert.DeserializeObject<WebApiResponse<object>>(response.Content.ReadAsStringAsync().Result);
        ////    var uploadData = new BlobUploadResponse();

        ////    if (result.Header.StatusCode == System.Net.HttpStatusCode.OK)
        ////    {
        ////        uploadData.Success = true;
        ////        uploadData.FileId = result.Results.FileId;
        ////    }
        ////    else
        ////    {
        ////        uploadData.Messages = result.Errors.UserMessage;
        ////    }

        ////    return await Task.FromResult(uploadData);
        ////}

        /// <summary>
        /// Send request to post web REST service resource to get file using HttpClient
        /// </summary>
        /// <param name="blobDownloadRequest">File code request</param>
        /// <param name="client">Http client</param>
        /// <param name="route">Master service route</param>
        /// <returns>Stream file</returns>
        private async Task<BlobDownloadResponse> DownloadFileMethodBlob(BlobDownloadRequest blobDownloadRequest, string route)
        {
            var client = new HttpClient(new HttpClientHandler
            {
                AutomaticDecompression = DecompressionMethods.None | DecompressionMethods.Deflate,
                ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; }
            });
            client = WebApiFileManager(client);
            var jsonRequest = JsonConvert.SerializeObject(new { fileId = blobDownloadRequest.FileId });
            var body = new StringContent(jsonRequest);

            body.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await client.PostAsync(
                string.Format(
                    "{0}FileIndex/Service.GetStreamFile",
                    route),
                body).ConfigureAwait(false);

            //// Retornar entidad DownloadFile
            ////

            var responseBody = response.Content.ReadAsStringAsync().Result;
            var result = JsonConvert.DeserializeObject<WebApiResponse>(Encoding.UTF8.GetString(Encoding.Default.GetBytes(responseBody)));
            var downloadData = new BlobDownloadResponse();

            if (result.Header.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var res = JsonConvert.DeserializeObject<List<BlobDownloadResponse>>(result.Results.ToString());
                res.FirstOrDefault().Success = true;

                return res.FirstOrDefault();
            }
            else
            {
                downloadData.Messages = result.Errors.UserMessage;
                return await Task.FromResult(downloadData);
            }
        }

        /////// <summary>
        /////// Send request to post web REST service resource to get file using HttpClient
        /////// </summary>
        /////// <param name="entityRequest">Entity request property</param>
        /////// <returns>Stream file</returns>
        ////private async Task<BlobDownloadResponse> DownloadFileWithCredentials(BlobDownloadRequest entityRequest)
        ////{
        ////    var webApiAudit = new HttpHandler();
        ////    var jsonRequest = JsonConvert.SerializeObject(new { fileId = entityRequest.FileId });
        ////    var body = new StringContent(jsonRequest);

        ////    body.Headers.ContentType = new MediaTypeHeaderValue("application/json");

        ////    body.Headers.ContentDisposition = new ContentDispositionHeaderValue("credentials");

        ////    body.Headers.ContentDisposition.Parameters.Add(
        ////       new NameValueHeaderValue(
        ////           "username",
        ////           entityRequest.SftpUserName));

        ////    body.Headers.ContentDisposition.Parameters.Add(
        ////        new NameValueHeaderValue(
        ////            "password",
        ////            entityRequest.SftpPassword));

        ////    body.Headers.ContentDisposition.Parameters.Add(
        ////        new NameValueHeaderValue(
        ////            "host",
        ////            entityRequest.SftpHost));

        ////    body.Headers.ContentDisposition.Parameters.Add(
        ////        new NameValueHeaderValue(
        ////            "port",
        ////        entityRequest.SftpPort.ToString()));

        ////    body.Headers.ContentDisposition.Parameters.Add(
        ////        new NameValueHeaderValue(
        ////            "sharefolder",
        ////        HttpUtility.UrlEncode(entityRequest.SftpShareFolder)));

        ////    ////body.Add(file);

        ////    var response = await webApiAudit.PostAsync(
        ////        string.Format(
        ////            "{0}FileIndex/Service.GetStreamFileWithCredentials",
        ////            ServiceHelper.BaseAddress("SftpApi")),
        ////        body).ConfigureAwait(false);

        ////    //// Retornar entidad DownloadFile
        ////    ////
        ////    dynamic result = JsonConvert.DeserializeObject<WebApiResponse<object>>(response.Content.ReadAsStringAsync().Result);
        ////    var downloadData = new BlobDownloadResponse();

        ////    if (result.Header.StatusCode == System.Net.HttpStatusCode.OK)
        ////    {
        ////        downloadData.Success = true;
        ////        downloadData.BlobFileName = result.Results.FileName;
        ////        downloadData.BlobStream = result.Results.BlobStream;
        ////    }
        ////    else
        ////    {
        ////        downloadData.Messages = result.Errors.UserMessage;
        ////    }

        ////    return await Task.FromResult(downloadData);
        ////}

        public HttpClient WebApiFileManager(HttpClient client)
        {
                          
                SecretHelper secretHelper = new SecretHelper(Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"));
                RSAHelper _rsaHelper = new RSAHelper(secretHelper);
                _rsaHelper.GetPrivateKeyFromFile();
                DateTime dat = DateTime.Now.AddMinutes(1);

                long unixTime = ((DateTimeOffset)dat).ToUnixTimeMilliseconds();
                client.DefaultRequestHeaders.Add("WM_SVC.NAME", secretHelper.getWmSvcName());
                client.DefaultRequestHeaders.Add("WM_SVC.ENV", secretHelper.getWmSvcEnv());
                client.DefaultRequestHeaders.Add("WM_CONSUMER.ID", secretHelper.getWmConsumerId());
                client.DefaultRequestHeaders.Add("WM_CONSUMER.INTIMESTAMP", unixTime.ToString());
                client.DefaultRequestHeaders.Add("WM_SEC.AUTH_SIGNATURE", _rsaHelper.Signature(secretHelper.getWmConsumerId(), unixTime, secretHelper.getWmRegistryVersion()));
                client.DefaultRequestHeaders.Add("WM_SEC.KEY_VERSION", secretHelper.getWmRegistryVersion());

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate { return true; });
                client.Timeout = Timeout.InfiniteTimeSpan;
                return client;
           
        }

        #endregion Private Methods

    }
}