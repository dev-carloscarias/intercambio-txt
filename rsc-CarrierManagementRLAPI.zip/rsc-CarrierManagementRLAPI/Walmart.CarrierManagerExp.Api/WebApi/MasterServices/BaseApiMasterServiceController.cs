﻿//---------------------------------------------------------------------------------------
// <copyright file="BaseApiMasterServiceController.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Esteban Barboza Muñoz</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api
{
    using System.Diagnostics.CodeAnalysis;
    using System.Net;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Net.Security;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Microsoft.Extensions.Options;
    using Newtonsoft.Json;
    using Walmart.CarrierManagerExp.Api.Repository;
    using Walmart.Common.Models;
    ////using System.Runtime.Caching;
    using System;
    using Walmart.Common.Helpers.Handlers;

    /// <summary>
    /// Master Services web api
    /// </summary>
    public partial class BaseApiMasterServiceController : BaseApiController
    {
        /// <summary>
        /// Logger object
        /// </summary>
        public readonly ILogger Logger;

        /// <summary>
        /// App settings object
        /// </summary>
        public readonly IOptions<AppSettings> Config;

        /// <summary>
        /// File transfer field
        /// </summary>
        public readonly ISftpClient SftpClient;

        /// <summary>
        /// Cache memory helper transfer field
        /// </summary>
        public readonly IMemoryCacheHelper cacheHelper;
        public readonly ISecretHelper secretHelper;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseApiMasterServiceController" /> class
        /// </summary>
        /// <param name="config">Apps settings constants</param>
        /// <param name="logger">Loguer class</param>
        /// <param name="sftpClient">Sftp client</param>
        /// <param name="cacheHelper">Cache helper class</param>
        public BaseApiMasterServiceController(IOptions<AppSettings> config, ILogger<BaseApiMasterServiceController> logger, ISftpClient sftpClient, IMemoryCacheHelper cacheHelper,
            ISecretHelper secretHelper)
        {
            this.Config = config;
            this.SftpClient = sftpClient;
            this.Logger = logger;
            this.cacheHelper = cacheHelper;
            this.secretHelper = secretHelper;
        }

        /// <summary>
        /// Gets or sets web master service client class
        /// </summary>
        [ExcludeFromCodeCoverage]
        public HttpClient WebApiMasterServices
        {
            get
            {

                var client = new HttpClient(new HttpClientHandler
                {
                    AutomaticDecompression = DecompressionMethods.Deflate,
                    ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; }
                });

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                if (cacheHelper.GetValue("CAMSSOToken") != null)
                {
                    client.DefaultRequestHeaders.Add("Authorization", $"Bearer {cacheHelper.GetValue("CAMSSOToken").ToString()}");
                    return client;
                }

                var jsonRequest = string.Empty;

                var objTokenRequest = new
                {
                    clientId = secretHelper.getItemFileClientId(),
                    clientSecret = secretHelper.getItemFileClientSec(),
                    requiredScopes = secretHelper.getItemFileTokenScopes()
                };

                jsonRequest = JsonConvert.SerializeObject(objTokenRequest);

                var body = new StringContent(jsonRequest);
                body.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                var response = this.WebApiTokenProvider.PostAsync($"{secretHelper.getSTSTokenProvider()}TokenResponses/Service.GetNewAccessToken", body).Result;
                var result = JsonConvert.DeserializeObject<WebApiResponse>(response.Content.ReadAsStringAsync().Result);

                if (result != null && result.Header.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    return null;
                }

                var tokenProvider = JsonConvert.DeserializeObject<TokenProvider>(result.Results.ToString());
                cacheHelper.Add("CAMSSOToken", tokenProvider.AccessToken, DateTimeOffset.UtcNow.AddSeconds(tokenProvider.ExpiresIn));
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {tokenProvider.AccessToken}");

                return client;
            }

            set
            {
                this.WebApiMasterServices = value;
            }
        }

        /// <summary>
        /// Gets or sets web token provider client class
        /// </summary>
        [ExcludeFromCodeCoverage]
        private HttpClient WebApiTokenProvider
        {
            get
            {
                var client = new HttpClient(new HttpClientHandler { AutomaticDecompression = DecompressionMethods.Deflate });

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate { return true; });

                return client;
            }

            set
            {
                this.WebApiTokenProvider = value;
            }
        }
    }
}
