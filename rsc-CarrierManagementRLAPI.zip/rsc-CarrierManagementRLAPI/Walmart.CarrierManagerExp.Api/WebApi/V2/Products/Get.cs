﻿//---------------------------------------------------------------------------------------
// <copyright file="Get.cs" company="Walmart México y Centroamérica">
//   Copyright (c) Deny to distribute this code.
// </copyright>
// <author>Carlos Agüero Fallas</author>
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp.Api.V2
{
    #region Using

    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Logging;
    using Walmart.CarrierManagerExp.Api.Repository;
   using Walmart.CarrierManagerExp.Api.Resources.Main;
    using Walmart.Common.Helpers;

    #endregion Using

    /// <summary>
    /// Controller example partial class
    /// </summary>
    public partial class ProductsController : BaseApiController
    {
        #region Methods

        /// <summary>
        /// Get the product list
        /// </summary>
        /// GET api/v1/products
        /// <returns>Collection of products</returns>
        [Route("")]
        [HttpGet, Authorize]
        [ProducesResponseType(typeof(IEnumerable<Product>), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> Get()
        {
            try
            {
                return this.Ok(await this.productRepository.GetAll());
            }
            catch (SqlException ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogError(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception ex)
            {
                this.logger.LogDebug(ex.ToString());
                this.logger.LogDebug(ex.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        /// <summary>
        /// Obtain the specific product given its identifier.
        /// </summary>
        /// <param name="id">Product id</param>
        /// GET api/v1/products/1
        /// <returns>Specific product</returns>
        [Route("{id}", Name = "GetOneProduct")]
        [HttpGet]
        [ProducesResponseType(typeof(Product), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> GetById(int id)
        {
            try
            {
                var product = await this.productRepository.GetItem(id.ToString(CultureInfo.InvariantCulture));

                if (product == null)
                {
                    return this.BadRequest(
                         ErrorMessageManagement.SetsErrorMessages(
                             Messages.NotFoundRecordUserErrorMessage,
                         (int)System.Net.HttpStatusCode.NotFound));
                }

                return this.Ok(product);
            }
            catch (SqlException exception)
            {
                this.logger.LogDebug(exception.ToString());
                this.logger.LogError(exception.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
            catch (System.Exception exception)
            {
                this.logger.LogDebug(exception.ToString());
                this.logger.LogDebug(exception.ToString());
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Messages.SqlExceptionUserMessage));
            }
        }

        #endregion Methods
    }
}