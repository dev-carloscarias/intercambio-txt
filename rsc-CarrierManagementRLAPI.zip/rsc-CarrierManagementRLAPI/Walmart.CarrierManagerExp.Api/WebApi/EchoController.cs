﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Helpers;

namespace Walmart.CarrierManagerExp.Api
{
    /// <summary>
    /// Controlador del echo para determinar si el API esta corriendo y
    /// conectándose correctamente a la base de datos.
    /// </summary>
    [ApiVersion("1.0")]
    [ApiVersion("2.0")]
    [Produces("application/json")]
    [Route("api/v{version:apiVersion}/echo")]
    public class EchoController : BaseApiController
    {
        #region Fields

        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<EchoController> logger;

        /// <summary>
        /// Echo repository
        /// </summary>
        private IEchoRepository echoRepository;

        #endregion Fields

        #region Constructor

        /// <summary>
        ///
        /// </summary>
        /// <param name="echoRepository"></param>
        /// <param name="logger"></param>
        public EchoController(IEchoRepository echoRepository, ILogger<EchoController> logger)
        {
            this.echoRepository = echoRepository;
            this.logger = logger;
        }

        #endregion Constructor

        #region Methods

        /// <summary>
        /// Permite determinar si existe una conexión satisfactoria a la BD.
        /// </summary>
        /// <returns></returns>
        [Route("")]
        [HttpGet]
        [ProducesResponseType(typeof(bool), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> Get()
        {
            try
            {
                this.logger.LogInformation("Method Get");
                var result = await this.echoRepository.IsConnectionSuccessful();
                return this.Ok(result);
            }
            catch (SqlException ex)
            {
                this.logger.LogDebug((this.StatusCode((int)HttpStatusCode.InternalServerError).ToString()));
                this.logger.LogError((this.StatusCode((int)HttpStatusCode.InternalServerError).ToString()));
                this.logger.LogError(ex.Message);

                return this.StatusCode((int)HttpStatusCode.InternalServerError);
                throw;
            }
            catch (System.Exception ex)
            {
                this.logger.LogDebug((this.StatusCode((int)HttpStatusCode.InternalServerError).ToString()));
                this.logger.LogError((this.StatusCode((int)HttpStatusCode.InternalServerError).ToString()));
                this.logger.LogError(ex.Message);

                return this.StatusCode((int)HttpStatusCode.InternalServerError);
                throw;
            }
        }

        #endregion Methods
    }
}