﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Serialization;
using Serilog;
using Serilog.Sinks.Elasticsearch;
using Walmart.CarrierManagerExp.Api.Common.Handlers;
using Walmart.CarrierManagerExp.Api.Common.Handlers.Falcon;
using Walmart.CarrierManagerExp.Api.Common.Middlewares.Authorization;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Helpers.Handlers;


namespace Walmart.CarrierManagerExp.Api
{
    /// <summary>
    /// Setup the configuration when the Application starts
    ///
    /// #001 Add cors
    ///
    /// </summary>
    public class Startup
    {
        private IApiVersionDescriptionProvider versionDescProvider;
        private IConfiguration Configuration { get; }
        private ISecretHelper secretHelper;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to add services to the container.
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            //application settings
            services.AddOptions();

            services.AddMvc();

            // #001 Add Cors
            services.AddCors(options =>
            {
                options.AddPolicy("AllowOrigin",
                builder => builder.WithOrigins(
                    "https://lcmnt20000gt.cam.wal-mart.com:4460/", 
                    "http://localhost:4460",
                    "https://localhost:4462",
                    "https://localhost:3000",
                    "http://localhost:3000",
                    "http://localhost:4459",
                    "https://lcmnt20000gt.cam.wal-mart.com:4462",
                    "http://lcmnt20000gt.cam.wal-mart.com:4462",
                    "https://qa.retaillink2.wal-mart.com/carriermanagement",
                    "https://qa.retaillink2.wal-mart.com/",
                    "https://qa.retaillink2.wal-mart.com",
                    "https://qa.rl2.wal-mart.com/carriermanagement",
                    "http://localhost:3000/carriermanagement",
                    "https://cam.carrier.dev.management.rl.wal-mart.com",
                    "https://cam.carrier.stg.management.rl.wal-mart.com",
                    "https://retaillink2.wal-mart.com/carriermanagement",
                    "https://retaillink2.wal-mart.com/",
                    "https://retaillink2.wal-mart.com",
                    "https://cam.carrier.management.rl.wal-mart.com"
                    )
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                 );
            });
            secretHelper = new SecretHelper(Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT"));
            string CarrierConnectionString = secretHelper.getDBCarrierConnection();
            string tmsConnectionString = secretHelper.getDBTMSConnection();

            //Dependencies Injection Setup
            services.AddSingleton<IFalcon, Falcon>();
            services.AddSingleton<ILoggingHandler, LoggingHandler>();
            services.AddSingleton<IAuthorizationMiddleware, AuthorizationMiddleware>();
            services.TryAdd(ServiceDescriptor.Singleton(typeof(ILogger<>), typeof(Logger<>)));
            services.TryAdd(ServiceDescriptor.Singleton(typeof(ISftpClient), typeof(SftpClient)));
            services.TryAdd(ServiceDescriptor.Singleton(typeof(IMemoryCacheHelper), typeof(MemoryCacheHelper)));
            services.Add(new ServiceDescriptor(typeof(IEchoRepository), new EchoRepository(CarrierConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IProductRepository), new ProductRepository(CarrierConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IAuditTrailRepository), new AuditTrailRepository(CarrierConnectionString)));
            services.Add(new ServiceDescriptor(typeof(ICarrierRepository), new CarrierRepository(tmsConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IDocumentTypeRepository), new DocumentTypeRepository(CarrierConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IDocumentsRepository), new DocumentsRepository(CarrierConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IGenericRepository), new GenericRepository(tmsConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IBoxCarRepository), new BoxCarRepository(tmsConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IVehicleRepository), new VehicleRepository(tmsConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IPilotRepository), new PilotRepository(tmsConnectionString)));
            services.Add(new ServiceDescriptor(typeof(ITmsCarrierReportRepository), new TmsCarrierReportRepository(tmsConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IReportRepository), new ReportRepository(CarrierConnectionString)));
            services.Add(new ServiceDescriptor(typeof(IDocumentTypeApplyRepository), new DocumentTypeApplyRepository(CarrierConnectionString)));
            services.Add(new ServiceDescriptor(typeof(ICountryRepository), new CountryRepository(tmsConnectionString)));
            
            services.AddSingleton<ISecretHelper>(secretHelper);
            //Log info in debug mode

            //Versioning
            services.AddApiVersioning(o =>
            {
                o.ApiVersionReader = new UrlSegmentApiVersionReader();
                o.ReportApiVersions = true;
            });


            //Custom response
            services
            .AddMvcCore(opt => opt.Filters.Add(typeof(CustomResultFilter)))
            .AddAuthorization()
            .AddApiExplorer()
            .AddVersionedApiExplorer(options =>
            {
                options.GroupNameFormat = "'v'VVV";
                options.SubstituteApiVersionInUrl = true;
            })
             .AddJsonOptions(opt =>
             {
                 opt.JsonSerializerOptions.PropertyNamingPolicy = null;
                 opt.JsonSerializerOptions.DictionaryKeyPolicy = null;
             });

            services.AddAntiforgery();


            //Swagger
            versionDescProvider = CreateApiVersionDescriptionProvider(services);
            services.AddSwaggerGen(c =>
            {
                foreach (var description in versionDescProvider.ApiVersionDescriptions)
                {
                    c.SwaggerDoc(description.GroupName, CreateInfoForApiVersion(description));
                }

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });

            //logging
            string elacticSeacrhUri = secretHelper.getElasticSearchUrl();
            string elacticSeacrhIndexFormat = secretHelper.getElasticSearchFormat();
            string elacticSeacrhTemplateName = secretHelper.getElasticSearchTemplate();
            string elacticSeacrhTypeName = secretHelper.getElasticSearchType();

            Log.Logger = new LoggerConfiguration()
                .WriteTo.Elasticsearch(new ElasticsearchSinkOptions(new Uri(elacticSeacrhUri))
                {
                    AutoRegisterTemplate = true,
                    IndexFormat = elacticSeacrhIndexFormat, //"walmart-index-{0:yyyy.MM}"
                    TemplateName = elacticSeacrhTemplateName, //"apinetcore-events"
                    TypeName = elacticSeacrhTypeName //"Walmart.CarrierManagerExp.Api"
                }).CreateLogger();

#if DEBUG
            Log.Logger.Information("Hola Walmart.CarrierManagerExp.Api!");
#endif
        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        /// <param name="loggerFactory"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            ////app.UseOptions();
            string basePath = secretHelper.getApiBaseUrl();
            loggerFactory.AddSerilog();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseCors("AllowOrigin");  // #001
            app.UseAuthentication();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseSwagger(c => c.RouteTemplate = "carriermanagement/api/{documentName}/swagger/swagger.json");
            app.UseSwaggerUI(c =>
            {
                foreach (var description in versionDescProvider.ApiVersionDescriptions)
                {
                    c.EnableValidator(null);
                    c.SwaggerEndpoint($"{basePath}/carriermanagement/api/{description.GroupName}/swagger/swagger.json", description.GroupName);
                    c.RoutePrefix = string.Empty;
                }
            });
            app.UseDefaultFiles(new DefaultFilesOptions
            {
                DefaultFileNames = new List<string> { "swagger" }
            });
            
            app.UsePathBase(new Microsoft.AspNetCore.Http.PathString("/carriermanagement"));
        }

        private OpenApiInfo CreateInfoForApiVersion(ApiVersionDescription apiVersionDesc)
        {
            return new OpenApiInfo
            {
                Version = apiVersionDesc.GroupName,
                Title = "Walmart CarrierManagment Vendors API " + apiVersionDesc.ApiVersion,
                Description = "Web API for Carrier Documents vendors module",
                TermsOfService = new Uri("https://walmart.org/licenses/MIT"),
                Contact = new OpenApiContact
                {
                    Name = "Walmart",
                    Email = ""
                },
                License = new OpenApiLicense
                {
                    Name = "Walmart",
                    Url = new Uri("https://walmart.org/licenses/MIT"),
                }
            };
        }

        private IApiVersionDescriptionProvider CreateApiVersionDescriptionProvider(IServiceCollection services)
        {
            return services.BuildServiceProvider().GetRequiredService<IApiVersionDescriptionProvider>();
        }
    }
}
