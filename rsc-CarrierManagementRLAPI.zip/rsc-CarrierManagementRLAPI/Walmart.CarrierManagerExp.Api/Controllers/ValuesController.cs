﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Walmart.Common.Models;
using Serilog.Extensions.Logging;

namespace Walmart.CarrierManagerExp.Api.Controllers
{
    /// <summary>
    /// test sample controller
    /// </summary>
    [ApiVersion("1.0")]
    [Produces("application/json")]
    [Route("api/v{version:apiVersion}/values")]
    public class ValuesController : ControllerBase
    {
        /// <summary>
        /// Log4net class
        /// </summary>
        private readonly ILogger<ValuesController> logger;

        /// <summary>
        ///
        /// </summary>
        /// <param name="logger"></param>
        public ValuesController(ILogger<ValuesController> logger)
        {
            this.logger = logger;
        }

        // GET api/values
        /// <summary>
        /// Get all the values into a compressed paginated response
        /// </summary>
        /// <param name="offset">Optional offset to skip</param>
        /// <param name="limit">Optional limit of records to retrieve</param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<PagedResult<string>> Get(int offset = 0, int limit = 500)
        {
            int total = 0;
            var list = GetArray(offset, limit, out total);

            //Samples of logging into elacticSeacrh
#if DEBUG
            //Serilog.Log.Logger.Information("EVENTO!");
            //logger.LogInformation("Getting the paginated values.");
            //logger.LogError(new Exception("This a controlled exception to be logged."), "Error Sample");
#endif
            //

            return base.Ok(list.ToPagedResult(offset, limit, total));
        }

        private List<string> GetArray(int offset, int limit, out int total)
        {
            var list = new List<string>();
            for (int i = 0; i < 1572; i++)
            {
                list.Add("value" + i);
            }
            total = list.Count;
            list = list.Skip(offset)
                        .Take(limit)
                        .ToList();

            return list;
        }

        // GET api/values/5
        /// <summary>
        /// Get a specific value
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return Ok("value");
        }

        // POST api/values
        /// <summary>
        ///
        /// </summary>
        /// <param name="value"></param>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        /// <summary>
        ///
        /// </summary>
        /// <param name="id"></param>
        /// <param name="value"></param>
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        /// <summary>
        ///
        /// </summary>
        /// <param name="id"></param>
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}