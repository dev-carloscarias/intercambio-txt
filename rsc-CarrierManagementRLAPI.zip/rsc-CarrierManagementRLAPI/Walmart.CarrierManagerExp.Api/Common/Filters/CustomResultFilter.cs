﻿using System;
using System.Collections;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Walmart.Common.Helpers;
using Walmart.Common.Helpers.Handlers;
using Walmart.Common.Models;

namespace Walmart.CarrierManagerExp.Api
{



    /// <summary>
    ///
    ///  Custom result filter for the Walmart Response
    ///
    ///  Checkmarx issue Missing_HSTS_Header ommited on .cxignore based on
    ///
    ///  <!-- https://docs.microsoft.com/en-us/ASPNET/Core/security/enforcing-ssl?view=aspnetcore-2.2&tabs=visual-studio -->
    ///
    ///  Apps deployed in a reverse proxy configuration allow the proxy to handle connection security (HTTPS).
    ///  If the proxy also handles HTTPS redirection, there's no need to use HTTPS Redirection Middleware.
    ///  If the proxy server also handles writing HSTS headers (for example, native HSTS support in IIS 10.0 (1709) or later),
    ///  HSTS Middleware isn't required by the app. For more information, see Opt-out of HTTPS/HSTS on project creation
    ///
    ///  We will use Linkerd as Reverse Proxy
    ///
    /// </summary>
    public class CustomResultFilter : IResultFilter
    {
        private ILogger<CustomResultFilter> ILog;

        private readonly IOptions<AppSettings> config;
        private readonly ISecretHelper secretHelper;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="config"></param>
        public CustomResultFilter(ILogger<CustomResultFilter> logger, IOptions<AppSettings> config, ISecretHelper secretHelper)
        {
            ILog = logger;
            this.config = config;
            this.secretHelper = secretHelper;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="context"></param>
        public void OnResultExecuted(ResultExecutedContext context)
        {
            //
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="context"></param>
        public void OnResultExecuting(ResultExecutingContext context)
        {
#if DEBUG
            ILog.LogInformation($"Adding custom format to response");
#endif

            // Validate public parameter
            if (context == null) return;

            var res = context.Result as FileContentResult;

            if (res != null)
            {
                Type value = res.GetType();

                bool formFile = typeof(FileContentResult).IsAssignableFrom(value);

                if (formFile) return;
            }

            WebApiResponse webApiResponse = new WebApiResponse();
            webApiResponse.Header = new HeaderResponse();
            webApiResponse.Header.Version = "1.0.0";
            webApiResponse.Header.Timestamp = DateTime.Now;
            webApiResponse.Errors = new ErrorMessages();

            if (context.Result is OkObjectResult)
            {
                var result = context.Result as OkObjectResult;
                webApiResponse.Header.StatusCode = (HttpStatusCode)result.StatusCode.Value;
                webApiResponse.Results = result.Value;
                Type valueType = result.Value.GetType();
                bool isIQueryable = typeof(IQueryable).IsAssignableFrom(valueType);
                bool isEnumerable = typeof(IEnumerable).IsAssignableFrom(valueType);
                bool isPagedResult = typeof(IPagedResult).IsAssignableFrom(valueType);

                if (isPagedResult)
                {
                    webApiResponse.Header.TotalResults = ((IPagedResult)result.Value).Total;
                    webApiResponse.Header.ReturnedResults = ((IPagedResult)result.Value).Limit;
                    if (webApiResponse.Header.ReturnedResults > webApiResponse.Header.TotalResults)
                        webApiResponse.Header.ReturnedResults = webApiResponse.Header.TotalResults;
                }
                else if (isIQueryable)
                {
                    webApiResponse.Header.TotalResults
                        = webApiResponse.Header.ReturnedResults = ((IQueryable)result.Value).GetEnumerator().Count();
                }
                else if (isEnumerable)
                {
                    webApiResponse.Header.TotalResults
                        = webApiResponse.Header.ReturnedResults = ((IEnumerable)result.Value).GetEnumerator().Count();
                }
                else
                {
                    webApiResponse.Header.TotalResults = 1;
                    webApiResponse.Header.ReturnedResults = 1;
                }
            }
            else if (context.Result is BadRequestObjectResult)
            {
                var result = context.Result as BadRequestObjectResult;
                webApiResponse.Header.StatusCode = (HttpStatusCode)result.StatusCode.Value;
                webApiResponse.Errors.Code = result.StatusCode.Value;
                context.HttpContext.Response.StatusCode = result.StatusCode.Value;
                if (result.Value is SerializableError)
                {
                    var error = result.Value as SerializableError;
                    webApiResponse.Errors.UserMessage = GetSerializableErrorValue(error, "userMessage");
                    webApiResponse.Errors.InternalMessage = GetSerializableErrorValue(error, "internalMessage");
                    object errorCode = 0;

                    try
                    {
                        error.TryGetValue("codeError", out errorCode);
                        webApiResponse.Errors.Code = result.StatusCode.Value;

                    }
                    catch (ArgumentNullException ex)
                    {
                        ILog.LogDebug(ex.ToString());
                        ILog.LogError(ex.ToString());
                    }

                }
                else
                {
                    webApiResponse.Results = result.Value;
                }
            }
            else if (context.Result is StatusCodeResult)
            {
                var result = context.Result as StatusCodeResult;
                webApiResponse.Header.StatusCode = (HttpStatusCode)result.StatusCode;
                webApiResponse.Errors.Code = result.StatusCode;
                context.HttpContext.Response.StatusCode = result.StatusCode;
            }

            string jsonString = JsonConvert.SerializeObject(webApiResponse);
            byte[] totalBytes = UTF8Encoding.UTF8.GetBytes(jsonString);

            context.HttpContext.Response.Headers.Remove("Content-Type");
            context.HttpContext.Response.Headers.Add("Content-Type", "application/json");
            context.HttpContext.Response.Headers.Add("Access-Control-Allow-Origin", "*");
            context.HttpContext.Response.Headers.Add("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
            context.HttpContext.Response.ContentLength = totalBytes.LongLength;
            context.HttpContext.Response.WriteAsync(jsonString);

        }

        private string GetSerializableErrorValue(SerializableError error, string key)
        {
            try
            {
                return ((string[])error[key]).First();
            }
            catch (SqlException ex)
            {
                //Log.Error(ex.Message);
                //Log.Debug(ex.Message);
                ILog.LogError(ex.ToString());
                ILog.LogDebug(ex.ToString());
                return string.Empty;
            }
            catch (Exception ex)
            {
                //Log.Error(ex.Message);
                //Log.Debug(ex.Message);
                ILog.LogError(ex.ToString());
                ILog.LogDebug(ex.ToString());
                return string.Empty;
            }
        }
    }
}