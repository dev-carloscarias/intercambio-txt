﻿namespace Walmart.CarrierManagerExp.Api.Common
{
    public static class Constants
    {
        public static string PRODUCTION = "production";
        public static string WM_SEC_AUTH_ID = "WM_SEC.AUTH_ID";
        public static string WM_SEC_AUTH_TOKEN = "WM_SEC.AUTH_TOKEN";
        public static int EXPIRE_HOURS = 4;
    }
}
