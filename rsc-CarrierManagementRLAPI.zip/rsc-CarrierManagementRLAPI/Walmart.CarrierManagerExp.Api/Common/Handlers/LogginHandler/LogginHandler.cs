﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Diagnostics;
using System;

namespace Walmart.CarrierManagerExp.Api.Common.Handlers
{
    public class LoggingHandler : ILoggingHandler
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(typeof(ILoggingHandler));

        public void AddError(Exception ex, HttpRequest request)
        {

            StringValues referer;
            request.Headers.TryGetValue("visado_origin", out referer);
            StackTrace trace = new StackTrace(ex, true);
            string filename = trace.GetFrame(trace.FrameCount - 1).GetFileName();
            System.Console.WriteLine(ex.Message.ToString());
            var errorObject = new Dictionary<string, object>
                {
                    {"log_type", "ERROR"},
                    {"action", "ERROR"},
                    {"app_name", "VisadoSeguridad"},
                    {"file_name", filename.Substring(filename.LastIndexOf("\\") + 1)},
                    {"http_request",  request.Method.ToString()},
                    {"message", ex.Message.ToString()},
                    {"timestamp", DateTime.Now},
                    {"log_original", ex.StackTrace.ToString()},
                    {"hostname",  referer.ToString()},
                    {"source_ip",  request.HttpContext.Connection.RemoteIpAddress.ToString()},
                };
            log.Error(JsonConvert.SerializeObject(errorObject));
        }

        public void AddError(Exception ex)
        {
            StringValues referer = "";
            StackTrace trace = new StackTrace(ex, true);
            string filename = trace.GetFrame(trace.FrameCount - 1).GetFileName();

            var errorObject = new Dictionary<string, object>
                {
                    {"log_type", "ERROR"},
                    {"action", "ERROR"},
                    {"app_name", "VisadoSeguridad"},
                    {"file_name", filename.Substring(filename.LastIndexOf("\\") + 1)},
                    {"http_request",  " "},
                    {"message", ex.Message.ToString()},
                    {"timestamp", DateTime.Now},
                    {"log_original", ex.StackTrace.ToString()},
                    {"hostname",  referer.ToString()},
                    {"source_ip",  " "},
                };
            log.Error(JsonConvert.SerializeObject(errorObject));
            System.Console.WriteLine(JsonConvert.SerializeObject(errorObject));
        }


    }
}
