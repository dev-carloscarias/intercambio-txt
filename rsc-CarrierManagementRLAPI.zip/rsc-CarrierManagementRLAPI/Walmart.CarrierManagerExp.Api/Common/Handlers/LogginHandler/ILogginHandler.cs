﻿using Microsoft.AspNetCore.Http;
using System;

namespace Walmart.CarrierManagerExp.Api.Common.Handlers
{
    public interface ILoggingHandler
    {
        void AddError(Exception ex, HttpRequest request);
        void AddError(Exception ex);
    }
}
