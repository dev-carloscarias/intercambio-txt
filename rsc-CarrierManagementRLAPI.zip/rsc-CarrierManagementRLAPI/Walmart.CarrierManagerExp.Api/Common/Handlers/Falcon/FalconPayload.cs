﻿using Newtonsoft.Json;
using System;

namespace Walmart.CarrierManagerExp.Api.Common.Handlers.Falcon
{
    public class UserInfo
    {

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("payload")]
        public UserInfoPayLoad payload { get; set; }
    }

    public class Partner
    {
        public Partner(string name, string vendorId)
        {
            this.name = name;
            this.vendorId = vendorId;
        }

        [JsonProperty("name")]
        public string name { get; set; }

        [JsonProperty("vendorId")]
        public string vendorId { get; set; }
    }

    public class UserInfoPayLoad
    {

        [JsonProperty("loginId")]
        public string loginId { get; set; }

        [JsonProperty("partners")]
        public Partner[] partners { get; set; }

        [JsonProperty("ldapGroup")]
        public String[] ldapGroup { get; set; }
    }


    public class FalconPayload
    {
    }
}
