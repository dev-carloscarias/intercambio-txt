﻿using System.Threading.Tasks;

namespace Walmart.CarrierManagerExp.Api.Common.Handlers.Falcon
{


    public interface IFalcon
    {
        Task<UserInfo> GetUserInfo(string token, string loginId);

    }

}
