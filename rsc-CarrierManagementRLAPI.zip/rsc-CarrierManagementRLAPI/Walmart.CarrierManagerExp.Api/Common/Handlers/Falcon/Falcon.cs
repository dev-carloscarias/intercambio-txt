﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System;
using Walmart.Common.Helpers.Handlers;

namespace Walmart.CarrierManagerExp.Api.Common.Handlers.Falcon
{
    public class Falcon : IFalcon
    {

        private readonly ISecretHelper secretHandler;
        private readonly ILoggingHandler _logginHandler;
        public Falcon(ISecretHelper secretHandler, ILoggingHandler _logginHandler)
        {
            this.secretHandler = secretHandler;
            this._logginHandler = _logginHandler;
        }

        public async Task<UserInfo> GetUserInfo(string token, string loginId)
        {
            try
            {
                HttpClient httpClient = new HttpClient();

                var payloadObject = new Dictionary<string, string>
                {
                    {"iamToken",token.ToString()},
                    {"clientId", secretHandler.getFalconClientId() },
                    {"clientType", secretHandler.getFalconType() },
                    {"loginId",loginId.ToString()}

                };

                string json = JsonConvert.SerializeObject(payloadObject);
                StringContent data = new StringContent(json, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await httpClient.PostAsync(secretHandler.getFalconBaseUrl(), data);
                string result = response.Content.ReadAsStringAsync().Result;

                //get user Info
                UserInfo userInfo = JsonConvert.DeserializeObject<UserInfo>(result);

                return userInfo;
            }
            catch (Exception err)
            {
                this._logginHandler.AddError(err);
                return null;
            }

        }
    }
}
