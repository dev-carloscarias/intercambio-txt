﻿using System.IO;
using System.Security.Cryptography;
using System.Text;
using System;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto.Parameters;
using Walmart.Common.Helpers.Handlers;

namespace Walmart.CarrierManagerExp.Api.Common.Handlers.Helpers
{
    public class RSAHelper : IRSAHelper
    {
        private RSACryptoServiceProvider _pvFile;
        private static string _pvString;
        private readonly ISecretHelper _secretHandler;
        public RSAHelper(ISecretHelper secretHelper)
        {
            this._secretHandler = secretHelper;

        }

        public void GetPrivateKeyFromFile()
        {
            _pvString = _secretHandler.getServiceRegistryPK();

            _pvString = _pvString.Replace("\\n", "\n");
            using (TextReader privateKeyTextReader = new StringReader(_pvString))
            {
                var readkey = new Org.BouncyCastle.OpenSsl.PemReader(privateKeyTextReader).ReadObject();
                RSAParameters rsaParams = DotNetUtilities.ToRSAParameters((RsaPrivateCrtKeyParameters)readkey);
                _pvFile = new RSACryptoServiceProvider();
                _pvFile.ImportParameters(rsaParams);

            }
        }

        public string Signature(string consumer, long timestamp, string version)
        {
            string txtSignature = $"{consumer}\n{timestamp.ToString()}\n{version}\n";
            var signature = _pvFile.SignData(Encoding.UTF8.GetBytes(txtSignature), CryptoConfig.CreateFromName("SHA256"));
            return Convert.ToBase64String(signature);
        }

    }
}
