﻿namespace Walmart.CarrierManagerExp.Api.Common.Handlers.Helpers
{
    public interface IRSAHelper
    {
         void GetPrivateKeyFromFile();
        string Signature(string consumer, long timestamp, string version);
    }
}
