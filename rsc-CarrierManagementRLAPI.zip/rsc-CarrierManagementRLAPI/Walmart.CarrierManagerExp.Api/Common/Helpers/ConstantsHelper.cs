﻿using System.Diagnostics.CodeAnalysis;

namespace Walmart.ApplicationName.Api.Common.Helpers
{
    /// <summary>
    /// Constant helper class
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class ConstantsHelper
    {
        #region Configs keys
        /// <summary>
        /// Content size for compress key
        /// </summary>
        public const string ContentSizeValue = "ContentSizeValue";

        /// <summary>
        /// Identity server token key
        /// </summary>
        public const string Sts = "STS";

        /// <summary>
        /// Active queue service key
        /// </summary>
        public const string ActiveMQServiceKey = "ActiveMQServiceKey";

        /// <summary>
        /// Scopes constant key
        /// </summary>
        public const string RequiredScopes = "RequiredScopes";
        #endregion       
    }
}
