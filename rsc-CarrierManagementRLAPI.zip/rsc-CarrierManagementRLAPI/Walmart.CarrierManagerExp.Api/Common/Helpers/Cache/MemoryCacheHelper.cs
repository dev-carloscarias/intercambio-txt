//---------------------------------------------------------------------------------------    
// <copyright file="MemoryCacheHelper.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Carlos Agero Fallas</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp
{
    #region Using
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Runtime.Caching;
    #endregion    

    /// <summary>
    /// Memory cache
    /// To register data set:
    /// memoryCache.Add(token, userId, DateTimeOffset.Now.AddHours(1));
    /// Get data from cache:
    /// object result = memoryCache.GetValue(token);
    /// if (result == null)
    /// {
    ///    Get and set data in cache    
    /// }
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class MemoryCacheHelper : IMemoryCacheHelper
    {
        /// <summary>
        /// Dispose value
        /// </summary>
        private bool disposedValue = false;

        #region Methods
        /// <summary>
        /// Get cache value
        /// </summary>
        /// <param name="key">Cache key</param>
        /// <returns>Object cache</returns>
        public object GetValue(string key)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            return memoryCache.Get(key);
        }

        /// <summary>
        /// Add cache value
        /// </summary>
        /// <param name="key">Cache key</param>
        /// <param name="value">Cache value</param>
        /// <param name="absExpiration">Cache expiration value</param>
        /// <returns>Create the cache object</returns>
        public bool Add(string key, object value, DateTimeOffset absExpiration)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            return memoryCache.Add(key, value, absExpiration);
        }

        /// <summary>
        /// Delete cache value
        /// </summary>
        /// <param name="key">Cache key</param>
        public void Delete(string key)
        {
            MemoryCache memoryCache = MemoryCache.Default;
            if (memoryCache.Contains(key))
            {
                memoryCache.Remove(key);
            }
        }
        #endregion        

        #region IDisposable Support

        /// <summary>
        /// This code added to correctly implement the disposable pattern.
        /// </summary>
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        /// <param name="disposing">Dispose property</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.
                this.disposedValue = true;
            }
        }
        #endregion       
    }
}