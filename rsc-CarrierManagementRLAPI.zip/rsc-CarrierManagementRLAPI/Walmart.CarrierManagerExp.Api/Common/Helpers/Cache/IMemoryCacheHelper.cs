﻿//---------------------------------------------------------------------------------------    
// <copyright file="IMemoryCacheHelper.cs" company="Walmart México y Centroamérica">    
//   Copyright (c) Deny to distribute this code.    
// </copyright>    
// <author>Esteban Barboza Muñoz</author>    
//----------------------------------------------------------------------------------------
namespace Walmart.CarrierManagerExp
{
    #region Using
    using System;
    #endregion
    /// <summary>
    /// Memory cache interface
    /// </summary>
    public interface IMemoryCacheHelper : IDisposable
    {
        /// <summary>
        /// Add cache object
        /// </summary>
        /// <param name="key">Token key</param>
        /// <param name="value">Token value</param>
        /// <param name="absExpiration">Token expiration</param>
        /// <returns>Status process</returns>
        bool Add(string key, object value, DateTimeOffset absExpiration);

        /// <summary>
        /// Delete cache object
        /// </summary>
        /// <param name="key">Token key</param>
        void Delete(string key);

        /// <summary>
        /// Get cache object
        /// </summary>
        /// <param name="key">Token key</param>
        /// <returns>Cache object</returns>
        object GetValue(string key);
    }
}