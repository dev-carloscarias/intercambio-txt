﻿namespace Walmart.CarrierManagerExp.Api
{
    /// <summary>
    /// Clase que mapea las configuraciones desde el archivo de configuracion json
    /// </summary>
    public class AppSettings
    {
        /// <summary>
        ///
        /// </summary>
        public string BaseUrl { get; set; }

        /// <summary>
        ///
        /// </summary>
        public string STS { get; set; }

        /// <summary>
        ///
        /// </summary>
        public string RequiredScopes { get; set; }

        /// <summary>
        ///
        /// </summary>
        public long ContentSizeValue { get; set; }

        /// <summary>
        /// Gets or sets client id
        /// </summary>
        public string ClientId { get; set; }

        /// <summary>
        /// Gets or sets secret
        /// </summary>
        public string ClientSecret { get; set; }

        /// <summary>
        /// Gets or sets token provider url
        /// </summary>
        public string STSTokenProvider { get; set; }

        /// <summary>
        /// Gets or sets token provider scopes
        /// </summary>
        public string TokenProviderScopes { get; set; }

        /// <summary>
        /// Gets or sets sftp server
        /// </summary>
        public string SftpServer { get; set; }

        /// <summary>
        /// Gets or sets country service
        /// </summary>
        public string CountryService { get; set; }

        /// <summary>
        /// Gets or sets cors
        /// </summary>
        public string Cors { get; set; }
    }
}