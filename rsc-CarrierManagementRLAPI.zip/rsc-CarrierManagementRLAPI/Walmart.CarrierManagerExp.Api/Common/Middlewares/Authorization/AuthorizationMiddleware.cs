﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection.Metadata;
using System.Threading.Tasks;
using Walmart.CarrierManagerExp.Api.Common.Handlers.Falcon;
using Walmart.CarrierManagerExp.Api.Repository;
using Walmart.Common.Helpers.Handlers;

namespace Walmart.CarrierManagerExp.Api.Common.Middlewares.Authorization
{
    public class AuthorizationMiddleware : IAuthorizationMiddleware
    {
        private readonly ISecretHelper secretHelper;
        private readonly IFalcon falcon;
        private readonly IMemoryCacheHelper memoryCacheHelper;
        private ICarrierRepository carrierRepository;
        private IDocumentsRepository documentsRepository;

        public AuthorizationMiddleware(ISecretHelper secretHelper, IFalcon falcon, IMemoryCacheHelper memoryCacheHelper, ICarrierRepository carrierRepository,
            IDocumentsRepository documentsRepository)
        {
            this.secretHelper = secretHelper;
            this.falcon = falcon;
            this.memoryCacheHelper = memoryCacheHelper;
            this.carrierRepository = carrierRepository;
            this.documentsRepository = documentsRepository;
        }

        public async Task<int[]> getVendors(HttpRequest request)
        {
            List<int> list = new List<int>();
            string envVar = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            HttpContext httpContext = request.HttpContext;
            StringValues loginId, token;
            httpContext.Request.Headers.TryGetValue(Constants.WM_SEC_AUTH_ID, out loginId);
            httpContext.Request.Headers.TryGetValue(Constants.WM_SEC_AUTH_TOKEN, out token);
            if (loginId == StringValues.Empty) return list.ToArray();
            if (token == StringValues.Empty) return list.ToArray();

            UserInfo userInfo = await getUser(request);

            if (!envVar.ToLower().Contains(Constants.PRODUCTION))
            {
                userInfo = new UserInfo();
                userInfo.payload = new UserInfoPayLoad();
                userInfo.payload.partners = new Partner[]
               {
                    new Partner("ACORDE","145532"),
                    new Partner("QA VENDOR","249964071"),
                    new Partner("MANPOWER NICARAGUA S.A","134242")
               };
            }
            else
            {
                if (userInfo == null) return list.ToArray();
                if (userInfo.Status != "OK") return list.ToArray();
                if (userInfo.payload == null) return list.ToArray();
                if (userInfo.payload.partners == null) return list.ToArray();
            }

            foreach (var partner in userInfo.payload.partners)
            {
                list.Add(Int32.Parse(partner.vendorId));
            }



            return list.ToArray();
            
        }

        public async Task<Boolean> checkEmail(HttpRequest request, string email)
        {
            HttpContext httpContext = request.HttpContext;
            StringValues loginId, token;
            httpContext.Request.Headers.TryGetValue(Constants.WM_SEC_AUTH_ID, out loginId);
            httpContext.Request.Headers.TryGetValue(Constants.WM_SEC_AUTH_TOKEN, out token);
            if (loginId == StringValues.Empty) return false;
            if (token == StringValues.Empty) return false;

            UserInfo userInfo = await getUser(request);
            if (userInfo == null) return false;
            if (userInfo.Status != "OK") return false;
            if (userInfo.payload == null) return false;

            return email == userInfo.payload.loginId;
        }

        public async Task<bool> validateUserByCode(HttpRequest request, string code)
        {
            var carrierInfo = await this.carrierRepository.GetItem(code);
            if (carrierInfo == null) return false;
            return await this.checkEmail(request, carrierInfo.CarrierEmail);
        }


        public async Task<bool> validateUserById(HttpRequest request, int id)
        {
            UserInfo userInfo = await this.getUser(request);
            if (userInfo == null) return false;
            if (userInfo.Status != "OK") return false;
            if (userInfo.payload == null) return false;

            var carrierInfo = await this.carrierRepository.GetByEmail(userInfo.payload.loginId);
            if (carrierInfo == null) return false;

            return carrierInfo.Count(x =>  x.CarrierId == id) > 0;
        }

        private async Task<UserInfo> getUser(HttpRequest request)
        {
            StringValues loginId, token;
            HttpContext httpContext = request.HttpContext;
            httpContext.Request.Headers.TryGetValue(Constants.WM_SEC_AUTH_ID, out loginId);
            httpContext.Request.Headers.TryGetValue(Constants.WM_SEC_AUTH_TOKEN, out token);
            return await falcon.GetUserInfo(token, loginId);
        }

        public async Task<Boolean> validateUserByDocument(HttpRequest request, int documentId)
        {
            UserInfo userInfo = await this.getUser(request);
            if (userInfo == null) return false;
            if (userInfo.Status != "OK") return false;
            if (userInfo.payload == null) return false;
            var findDocument = await documentsRepository.GetById(documentId);
            if (findDocument == null)
            {
                return false;
            }
            var carrierInfo = await this.carrierRepository.GetByEmail(userInfo.payload.loginId);
            if (carrierInfo == null) return false;
            return carrierInfo.Count(x => x.CarrierId == findDocument.CarrierId) > 0;
        }
    }
}
