﻿using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System;

namespace Walmart.CarrierManagerExp.Api.Common.Middlewares.Authorization
{
    public interface IAuthorizationMiddleware
    {
        Task<Boolean> validateUserByCode(HttpRequest request, string email);
        Task<Boolean> validateUserById(HttpRequest request, int id);
        Task<Boolean> validateUserByDocument(HttpRequest request, int documentId);
        Task<Boolean> checkEmail(HttpRequest request, string email);
        Task<int[]> getVendors(HttpRequest request);
        
    }
}
