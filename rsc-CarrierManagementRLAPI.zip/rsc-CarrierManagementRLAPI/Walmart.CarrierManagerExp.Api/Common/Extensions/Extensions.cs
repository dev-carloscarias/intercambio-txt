﻿using System.Collections;
using System.Linq;
using System.Collections.Generic;
using Walmart.Common.Models;

namespace Walmart.CarrierManagerExp.Api
{
    /// <summary>
    ///
    /// </summary>
    public static class Extensions
    {
        /// <summary>
        ///
        /// </summary>
        /// <param name="enumerator"></param>
        /// <returns></returns>
        public static IEnumerable ToEnumerable(this IEnumerator enumerator)
        {
            while (enumerator.MoveNext())
                yield return enumerator.Current;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="enumerator"></param>
        /// <returns></returns>
        public static int Count(this IEnumerator enumerator)
        {
            int total = 0;
            while (enumerator.MoveNext())
                total++;
            return total;
        }

        /// <summary>
        ///
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="enumerable"></param>
        /// <param name="offset"></param>
        /// <param name="limit"></param>
        /// <param name="total"></param>
        /// <returns></returns>
        public static PagedResult<T> ToPagedResult<T>(this IEnumerable<T> enumerable, int offset, int limit, int total)
        {
            PagedResult<T> page = new PagedResult<T>()
            {
                Offset = offset,
                Limit = limit,
                Total = total,
                Data = new List<T>()
            };
            page.Data.AddRange(enumerable);
            return page;
        }
    }
}