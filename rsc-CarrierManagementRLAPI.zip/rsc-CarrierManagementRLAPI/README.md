# ASP.NET CORE Web API

![alternativetext](_images/mainApi.PNG "Modern Api")

# Plantilla Web API para CAM Usando Asp.Net core

## Documentación Inicial

## CI & CD 

GitHub: https://gecgithub01.walmart.com/camts/gea-aspnetcoreapitemplate 

Looper: https://ci.walmart.com/job/CAM-GP-EnterpriseArchitecture/job/NetCoreApiTemplate/

Concord: https://concord.prod.walmart.com/#/org/Default/project/CAM-GP-EnterpriseArchitecture/process

## Características
+ Este proyecto fue creado con:
  + [ASP.NET Core 2.1](https://docs.microsoft.com/en-us/aspnet/core/?view=aspnetcore-2.1)
  + [Visual Studio 2017](https://visualstudio.microsoft.com/)
  + [Framework .Net Core 2.1](https://dotnet.microsoft.com/download/dotnet-core/)
  + [Swagger UI](https://swagger.io/tools/swagger-ui/)
  + [Web Api Versioning](https://github.com/microsoft/aspnet-api-versioning)
+  Clases parciales para controladores y servicios.
+  Capacidad para implementar versionamiento en el API, sin la necesidad de crear un nuevo proyecto.
+  Inyección de dependencias [Asp.Netcore](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/dependency-injection?view=aspnetcore-2.1). Si es requerido previa modificación de los controladores
+  Multi lenguaje usando archivos de recursos.
+  [Logging](https://docs.microsoft.com/en-us/aspnet/core/fundamentals/logging/?view=aspnetcore-2.1) con Microsoft ASP Net Logging.
+  [ElasticSearch](https://www.elastic.co/es/) componente centralizado para escribir logs en índices de ElasticSearch.

## Instalación

+ Descargar como zip la plantilla Walmart Web API del repositorio [Git](https://gecgithub01.walmart.com/camts/webapitemplate).
+ En la raíz de la solución hacer click derecho y ejecutar la opción **Clean Solution**
+ En la raíz de la solución hacer click derecho y ejecutar la opción **Rebuild Solution**, para actualizar referencias Nuget

## Proceso de desarrollo

Es obligatorio respetar la estructura de carpetas definidas para el desarrollo de cualquier aplicación

Como estándar se debe cumplir que cada clase creada tenga definida su interfaz esto para permitir mas facilmente la creación de inyección de dependencias y pruebas unitarias.

   ![alternativetext](_images/project.PNG "Project folder")

### 1. Renombrar aplicación

Antes de iniciar el proceso de desarrollo, se debe renombrar las carpetas, la solución, los proyectos y los namespaces de la plantilla con el nombre definido para la aplicación.

En general para cada uno de los pasos es, reemplazar el segmento **[ApplicationName]** con el nombre definido para la aplicación:

  + Cerrar Visual Studio
  + Renombrar las carpetas fuera de Visual Studio `(Walmart.[ApplicationName].Api, Walmart.[ApplicationName].Api.Repository)` con el nombre definido para la aplicación.
  + Abrir la solución, ignorar advertencias.
  + Ir a cada uno de los proyectos no disponibles y hacer lo siguiente:
    + Abrir ventana de propiedades **F4**
    + Establecer la propiedad **File Path** con la nueva ubicación del proyecto(carpetas renombradas).
  + Recargar el proyecto, hacer click derecho y ejecutar el método **Reload Project**.
  + Cambiar el nombre del proyecto, hacer click derecho y ejecutar el método **Rename**.
  + Cambiar el nombre de la solución, hacer click derecho y ejecutar el método **Rename**.
  + Renombrar las siguientes propiedades en cada proyecto:
    + Nombre del ensamblado **Assembly name**.
    + El root namespace **Default namespace**.
  + Renombrar los namespaces de los archivos existentes y sus referencias dentro de la aplicación.    
  + Renombrar los siguientes **assembly attributes** en `Propertires/AssemblyInfo.cs`:
    + AssemblyProductAttribute
    + AssemblyTitleAttribute.
  + Renombrar el XML documentation file, esto se encuentra dando Click derecho al proyecto, despues es propiedades y seguidamente en la pestaña Build.
	 *Imagen de ejemplo*
	 ![XML](_images/XMLDocumentation.PNG "XML documentation file")
  + Renombrar en el archivo Looper el project.
	 *Imagen de ejemplo*
	 ![LooperProject](_images/LooperName.PNG "LooperProject")
  + Hacer click derecho y ejecutar **Clean Solution**
    + Ir a la carpeta **bin** y eliminar todos los archivos.
  + Hacer click derecho y ejecutar **Rebuild Solution**
  + El proceso debe estar limpio de warnings(0) y errores(0).
  + Ejecutar la aplicación, debe cargar sin problemas.

#### 1.1 Modificar referencia de la aplicación para Identity Server

Una vez renombrada la aplicación es requerido modificar las llaves de configuración para el identity server dentro de la aplicación, con la información suministrada por el staff de arquitectura para el siguiente valor:

+ Scope

1. Ir al archivo **appsettings.json**, buscar y modificar los siguientes valores con la información suministrada por el staff de arquitectura para las llaves:  **`STS`** y **`RequiredScopes`**

```json

"STS": "https://localhost:44333",
"RequiredScopes": "write"

```

### 2. Crear entidades para base de datos

  + En el proyecto **Repository**, ir a la carpeta `Entities/[MyEntity]` ahí se deben crear las entidades con base en las tablas que se van a trabajar:
    + Debe contener un Id numérico
    + Nombre de atributos iguales

       ![alternativetext](_images/entities.PNG "Entities folder")

### 3. Crear los repositorios para las entidades de base de datos

  + Por norma todo movimiento desde y hacia la base de datos se debe realizar por medio de objetos como:  
    + Procedimientos almacenados
    + Funciones
    + Vistas

  + En el proyecto **Repository**, ir a la carpeta `Repositories/`,crear las clases necesarias para la implementación de las llamadas a base de datos.
    + El repositorio obligatoriamente debe tener una interfaz con los métodos correspondientes
    + Las clases deben heredar de, **GenericRepository**, la cual expone los siguientes métodos:

    ```js

        public abstract class GenericRepository<T> : IDisposable where T : class
        {
            protected GenericRepository();
            protected GenericRepository(string connectionString);

            public SqlConnection Connection { get; }

            public virtual void Dispose();
            public virtual T PopulateRecord(SqlDataReader reader);
            protected virtual void Dispose(bool disposing);
            protected async Task<int> ExecuteCommand(SqlCommand command);
            protected async Task<IQueryable<T>> ExecuteStoredProc(SqlCommand command);
            protected async Task<T> GetRecord(SqlCommand command);
            protected async Task<IQueryable<T>> GetRecords(SqlCommand command);
            protected async Task<(int total, IQueryable<T> result)> GetPagedRecords(SqlCommand command);
            protected async Task<bool> TestConnection();
        }
    ```

+ El método **PopulateRecord** es el único que se puede sobre escribir y es por medio del cual se hace la carga de datos a la entidad(funciones GET).

    ```js

        /// <summary>
        /// Populate entity Example
        /// </summary>
        /// <param name="reader">Represents a way of reading a forward-only stream of rows from a SQL Server database</param>
        /// <returns>Entity example product</returns>
        public override Product PopulateRecord(SqlDataReader reader)
        {
            return SqlReaderHelper.GetPopulateObject<Product>(reader);            
        }

    ```

En la ruta **Repositories/AuditTrail** y **Respositories/Products**, se exponen los ejemplos más comunes para la gestión de base de datos por medio del objeto **GenericRepository**

  ![alternativetext](_images/repositories.PNG "Repositories folder")

#### 3.1. Paginado de resultados

Para el paginado de resultados se retorna la estrutura `PagedResult`.
  ![PagedResult<T>](_images/pagedResults.png "Estructura de Paginado")

Para ello se necesita de una consulta SQL que devuelva los registros paginados los cuales deben de devolver una columna de tipo `integer` con nombre `__total` que contiene la cantidad total de registros en la tabla.

> | ⚠️WARNING: No olvides agregar la columna de alias `__total` y de tipo `int`! |
| --- |



Podemos realizarlos de 2 formas básicamente:
  + Usando versiones **>= SQL Server 2016**:
    + Se debe usar una consulta SELECT con FETCH y OFFSET:
    ![SQL1](_images/fetch.png "Fecth y Offset")
  + Usando versiones **< SQL Server 2016**:
    + Se debe usar un procedimiento almacenado propio que ordene y pagine los registros:
    ![SQL2](_images/sp.png "Procedimiento")

Ambos métodos usan el mismo método base del repositorio `GenericRepository`:
![BaseRep](_images/PagedRecords.png "Método Paginado")


### 4. Crear elementos para el servicio API

+ En el proyecto **Api**, crear los controladores necesarios para acceder a las entidades del repositorio de base de datos:
  + Se debe definir en que versiones estará disponible el nuevo endpoint.
  + Organización por carpetas según la versión y subcarpetas con el nombre de la entidad respectiva
  + Los controladores son clases parciales y obligatoriamente deben tener el nombre correspondiente al verbo Http(POST, PUT, GET, POST), lo que se llama operaciones CRUD.
  + Se puede crear métodos adicionales los verbos http llamados funciones o acciones que en ambos casos pueden retornar información.
    + Funciones:
      + Retornan información que no corresponde necesariamente a una entidad o colección definida en el servicio.
      + Asociadas al verbo **GET** en el controlador del servicio.
    + Acciones:
      + Asociadas al verbo **POST** en el controlador del servicio.
      + Utilizada para ejecutar transacciones complejas.
      + Enviar datos que no son necesariamente entidades del servicio.
      + Permite actualizar ciertas propiedades de una entidad.
      + Puede manipular varias entidades al mismo tiempo.
 + Documentación de los métodos de controlador
    + El proyecto principal ***Api*** está configurado para poder generar un archivo de documentación XML cada vez que se compíle el proyecto. Ya viene configurado en la plantilla API que se genere el archivo  ***bin\Walmart.CarrierManagerExp.Api.xml***.
        + Esto significa que cuando se despliegue a un servidor, se debe tener en cuenta también desplegar este archivo en la misma ubicación ***bin\Walmart.CarrierManagerExp.Api.xml***.
        
        > | ⚠️WARNING: No olvides copiar el archivo de documentación 
        `Walmart.CarrierManagerExp.Api.XML` a tu servidor web o tu Api no funcionará! |
| --- |
    + Todos los controladores deben de heredar de la clase **base** llamada **`BaseApiController`**.
    + Todos los métodos deben estar marcados con el atributo **`ProducesResponseType`** indicando el tipo de objeto a retornar, este tipo es el Data Contract que será enviado como parte del Response, ejemplo **`Product`** o **`IEnumerable<Product>`**.
    + Todos los métodos deben estar marcados con el atributo **`Route`** indicando la ruta MVC para acceder al método del api.
    
      > | ⚠️WARNING: Si tienes más de un endpoint con la misma firma y verbo HTTP deberás indicar un nombre de ruta usando `[Route("", Name = "")]`! |
| --- |
    + Todos los métodos deben marcarse como ***async*** y por consiguiente declarar su tipo de retorno como **`Task<IActionResult>`**.
    + Todos los métodos deben hacer uso de los métodos **base** ***Ok()*** y ***BadRequest()***.
        + Usar ***Ok()*** cuando se devuelva un dato o conjunto de datos satisfactoriamente.
        + Usar ***BadRequest()*** cuando ocurra una excepción o error.
        + Si se desea usar algún otro code usar ***StatusCode()***.
    + Al usar estos métodos **base**, se estará retornando siempre un objeto del tipo **`WebApiResponse`**. Este objeto es el que se devuelve al cliente del api, y lleva los datos solicitados en la propiedad *Results*.
    + Al usar esto métodos **base**, se estará usando también la funcionalidad de ***Compression*** del contenido del response.
    + Ejemplo de método de controlador:
    ```csharp
        /// <summary>
        /// Get the product list
        /// </summary>
        /// GET api/v1/products
        /// <returns>Collection of products</returns>
        [Route("")]
        [HttpGet, Authorize]
        [ProducesResponseType(typeof(IEnumerable<Product>), (int)HttpStatusCode.OK)]
        public async Task<IActionResult> Get()
        {
            try
            {
                return this.Ok(await this.productRepository.GetAll());
            }
            catch (SqlException ex)
            {
                return this.BadRequest(
                    ErrorMessageManagement.SetsErrorMessages(
                        Api.Resources.Main.Messages.SqlExceptionUserMessage,
                    ex.ToString()));
            }
        }
    ```
    + Ejemplo de respuesta de controlador:

        ![alternativetext](_images/result0.png  "Response Content")
    + Si se necesita, se puede cambiar la información del API, tales como contacto, email, descripción, licencia y terminos del servicio, modificando el fuente dentro de la región ***Swagger*** de la clase **`Startup.cs`**.  
    + Se puede acceder a la documentación del api, a través del URL https://localhost:44307/swagger. Suponiendo que nuestro apí está desplegado en localhost y usando el puerto 44307.

  + En la carpeta **WebApi/V1/[Entidad]/**, están los ejemplos básicos para el desarrollo de los métodos descritos para el servicio.

       ![alternativetext](_images/controllers.PNG "Components folder")

#### 4.1 Agregar versiones del API

Algunas veces es necesario crear más de una versión del api, para evitar conflictos en casos en los que ya existe una primera versión del api en producción y está siendo usada por ciertas aplicaciones, para ello la plantilla nos permite agregar más versiones del api realizando lo siguiente:
 + Crear la estructura necesaria dentro del folder WebApi, ejemplo: WebApi>V3>[Entidad]>[Entidad]Controller.cs
 + Crear la clase WebApiConfig dentro del folder V3. Esta contendrá los métodos necesarios para que se inicialize parámetros en caso de ser necesario para la nueva versión.  
 + Decorar la clase del controlador usando el atributo **`ApiVersion`**, ejemplo: `[ApiVersion("3.0")]`
 + Decorar la clase del controlador usando el atributo **`Route`**, ejemplo: `[Route("api/v{version:apiVersion}/entidad")]`
 + Decorar cada uno de los endpoints HTTp (Get,Post,Delete,Put) con el atributo **`ProducesResponseType`**, ejemplo: `[ProducesResponseType(typeof(IEnumerable<Product>), (int)HttpStatusCode.OK)]`
 + Decorar cada uno de los endpoints HTTp (Get,Post,Delete,Put) con el atributo **Route**, ejemplo: `[Route("{id:int}", Name = "GetOneProductV3")]`

#### 4.2 Paginado de resultados

A nivel de Api, los endpoints que devuelvan listado de resultados, deben devolver resultados paginados. Por lo que se deben de agregar 2 parámetros opcionales al request:
+ **offset**: Indica el número de registros a saltar u obviar. 0 por defecto.
+ **limit**: Indica la cantidad de registros a devolver. 500 por defecto.

> | ⚠️WARNING: No olvides agregar los valores por defecto a ambos parámetros `offset` y `limit`! |
| --- |

Estos son opcionales (si no son pasados toman valores por defecto) y son especificados en la URL del endpoint, como por ejemplo:

   + https://localhost:44307/api/v1/productswt?offset=5&limit=7
   + https://localhost:44307/api/v1/productswt?limit=7
   + https://localhost:44307/api/v1/productswt

### 5. Crear archivos de recurso

Ver [Multilenguaje Walmart Web API].

### 6. Crear pruebas unitarias

  + Crear los pruebas unitarias necesarias(al menos 2 test por método desarrollado) en cada una de las clases creadas.  
  + Para más información revisar el apartado [Estándar pruebas unitarias]

### 7. Archivo appsettings.json

Se establecen un grupo de parámetros de configuración y secciones personalizadas para utilización dentro de la aplicación.

+ Variable content size para servicios api.
+ Configuración de autorización.
+ Configuración de base de datos.
+ Configuración de logging.

El detalle de los parámetros se muestra a continuación:

```json
    {
      "Logging": {
        "LogLevel": {
          "Default": "Warning"
        }
      },
      "ConnectionStrings": {
        "WebApiContextConnection": "Data Source=SERVER\\INSTANCE;Initial Catalog=GeneralDB;User ID=sa;Password=sa"
      },
      "AllowedHosts": "*",
      "AppSettings": {
        "BaseUrl": "https://localhost:44307",
        "STS": "https://localhost:44333",
        "RequiredScopes": "write",
        "ContentSizeValue": "860",
        "elasticsearch-url": "http://localhost:9200/",
        "elasticsearch-indexFormat": "walmart-api-index-{0:yyyy.MM}",
        "elasticsearch-templateName": "apinetcore-events",
        "elasticsearch-typeName": "Walmart.CarrierManagerExp.Api"
      }
    }

```

En general los cambios que se deben realizar a los parámetros son los siguientes:

+  La llave **BaseUrl** indica la URL raíz de la aplicación (o sitio web dependiendo de como se despliegue), se debe mantener el protocolo de la misma (Http o Https).
+  La llave **STS** indica la URL del issuer de tokens de acceso, se utiliza para validar el token enviado a cada endpoint del Api.
+  La llave **RequiredScopes** indica el scope o los scopes separados por espacio que se deben de validar en el token de acceso enviado a cada endpoint del Api.
+  La llave **ContentSizeValue** indica la cantidad de bytes a partir de la cual se ejecutará la compresión de los datos en el servicio API.
   +  Configuración inicial equivale a 860 bytes.
+  **Configuracion para base de datos**
   + En la sección **connectionStrings** se debe realizar la configuración de las credenciales para la base de datos.
+  **Configuración de logging**: En esta sección se agregan los valores de conexión a eleacticSearch
   + La llave **elasticsearch-url** indica la URL de elasticSearch.
   + La llave **elasticsearch-indexFormat** indica el patrón de generación del nombre del índice en elasticSearch.
   + La llave **elasticsearch-templateName** indica el nombre del template de registro de log o nombre de la estructura del evento.
   + La llave **elasticsearch-typeName** indica el nombre del tipo de la estrutura a usar en elasticSearch. Usar el nombre del proyecto API que se desarrolle.

### 8. elasticSearch

+ Open Source. (https://www.elastic.co/products/elastic-stack)
+ Fácil instalación y configuración.
+ Alto performance en las aplicaciones.


Utilizada dentro de la aplicación para registrar excepciones no controladas y enviarlas ìndices dentro del elasticSearch de forma automática sin programación requerida.
Si es necesaria su utilización directamente en controlador hacer lo siguiente:

+ Crear el atributo privado `private readonly ILogger<MyController> logger;`
+ Injectarlo en el constructor del controlador:

```csharp

    #region Constructor
    /// <summary>
    ///
    /// </summary>
    /// <param name="logger"></param>
    public MyController(ILogger<MyController> logger)
    {
        //..
        this.logger = logger;
    }
    #endregion
  ```

Ejemplo de utilización:

```csharp
   ...
    this.logger.LogInformation("Getting the paginated values.");
    this.logger.LogError(new Exception("This a controlled exception to be logged."), "Error Sample");  
    ...
```

### 9. Secciones de la Plantilla Api (Bonus)

#### Startup Class

![Startup.cs](_images/startup.png "Startup Class")

#### Configuración de Inyección de Dependencias

![Startup.cs](_images/DI.png "Dependecy Injection")

#### Configuración de Versionado

![Startup.cs](_images/version.png "Versioning")

#### Configuración de Respuesta Personalizada

![Startup.cs](_images/customresp.png "Custom Result Filter")

#### Configuración de Autenticación

![Startup.cs](_images/authorize.png "Authentication")

#### Configuración de Swagger

![Startup.cs](_images/swagger.png "Swagger")

#### Configuración de Logging

![Startup.cs](_images/logging.png "Logging")

#### Tipos de estructura en respuesta

+ WebApiResponse Error    

![Startup.cs](_images/respError.png "Error")

+ WebApiResponse Object    

![Startup.cs](_images/respObject.png "Object")

+ WebApiResponse List    

![Startup.cs](_images/respList.png "List")

+ WebApiResponse Paged List    

![Startup.cs](_images/respPaged.png "Paged List")

#### Carpeta Common local

En esta carpeta se deben agregar las clases requeridas para implementarle al Mvc de nuevos atributos, extensiones, filtros o helpers.

![alternativetext](_images/common.PNG "Common folder")

+ En la carpeta **Common/Helpers** se creó la clase: `AppSettings.cs` que encapsula las propiedades de la sección de appSettings del archivo de configuración appsettings.json.
+ En la carpeta **Common/Filters** se creó la clase: `CustomResultFilter.cs` que es la encargada de dar formato de respuesta según la estructura `WebApiResponse`.
+ En la carpeta **Common/Extensions** se creó la clase: `Extensions.cs` que define métodos para las `Enumerator` y `Enumerable`.

#### Componentes Walmart.Common

##### [Referencia Walmart.Common]()

#### Multilenguaje Walmart Web API

Un archivo de recursos es un archivo XML que contiene las cadenas que desea traducir a otros idiomas diferentes o rutas de acceso a las imágenes. El archivo de recursos contiene pares de clave y valor. Cada par es un recurso individual. En los nombres de clave no se distingue entre mayúsculas y minúsculas. Por ejemplo, un archivo de recursos podría contener un recurso con la clave Button1 y el valor Submit.

Como estándar Walmart CAM se deben incluir al menos los lenguajes `Ingles` y `Español` en cualquier desarrollo de nuevas aplicaciones.
Por lo cual se incluye el uso de archivos de recurso definidos por componente:

![alternativetext](_images/Api.Resources.PNG "Api.Resources folder")

En general el archivo de recurso local predeterminado con el idioma español(es-ES) es el terminado en **[componente].resx**
El archivo de recursos para el idioma inglés(en-US)(Estados Unidos) es el terminado en **[componente].En.resx**

+ Main: Etiquetas generales para el servicio.

## 10. Echo
Valida que el api esté desplegado, se pueda acceder y valida la conexión a la base de datos.
Devuelve códigos de respuesta **HTTP 200 Ok** 0 ***HTTP 500 Internal Server Error**.

+   https://localhost:44307/api/v1/echo
+   https://localhost:44307/api/v2/echo

## 11. Despliegue en Servidor IIS:

+ Recuerda instalar el Runtime .Net Core 2.1
+ Recuerda instalar el Hosting Bundle for Windows (https://dotnet.microsoft.com/download/thank-you/dotnet-runtime-2.1.13-windows-hosting-bundle-installer)
+ Recuerda que el Application Pool debe ser del tipo `No Managed Code` y de canalización `Integrated`.

## 12. Encriptación del AppSettings


Para la encriptación del AppSetting.json se adjunta una solución de consola llamada Walmart.Common.CrytoCLI, compilar dicha aplicación y copiar archivo a la carpeta en donde se genera el Exe, la línea de comando a utilizar es:

Encriptar: >Walmart.Common.CryptoCLI -e AppSettings.json

+ **Encrypt AppSettings**

![Encript](_images/EncryptAppSettings.png "Encrypt")

Desencriptar: >Walmart.Common.CryptoCLI -d AppSettings.json

+ **Decrypt AppSettings**

![Encript](_images/DecryptAppSettings.png "Decrypt")

> | ⚠️WARNING: Para ejecutar la solución el AppSettings debe estar encriptado.

### 12.1 Prueba mediante Postman

Para probar que la configuracion que se hizo en el appSettings es correcta, se puede probar de manera local y haciendo una solicitud mediante Postman, lo primnero que se debe hacer es obtener un token valido pasando los parametros correctos.

+ **Correct parameters**

![Parameters](_images/Parameters.PNG "Api.Resources folder")

> | ⚠️WARNING: Para que el Token sea valido tiene que estar bien configurados el STS y el RequiredScopes.

+ **Valid Token**

![TokenValido](_images/TokenValido.PNG "Api.Resources folder")

Una vez que tenemos un token valido, podemos realizar la peticion al API, es importante recalcar que el token se coloca en los headers donde KEY es igual a Authorization y el Value es igual a Bearer + token valido.

+ **Valid Token Request**

![IngresarToken](_images/IngresarToken.PNG "Api.Resources folder")

+ **Result the request** 

![Resultado](_images/Resultado.PNG "Api.Resources folder")

## 13. Kibana

Los registros de logs en ElasticSearch se puedran consultar el Kibana en la siguiente url

[http://lcmnt10029gt.cam.wal-mart.com]()

#### Ejemplo de registro en log

![Ejemplo de registro en log](_images/ElasticLogEntry.png "Api.Resources folder")

#### Ejemplo de registro en log en formato Json
	
![Ejemplo de registro en log en formato Json](_images/ElasticLogEntryJson.png "Api.Resources folder")


> | ⚠️WARNING: Debe de crearse primero el patrón del indice en Kibana antes de poder consultar las entradas del log al índice especificado en el valor elasticsearch-indexFormat del appSettings.json. Por ejemplo walmart-api-index* para el valor de elasticsearch-indexFormat especificado.


## 14. Looper y Concord

En los siguientes enlaces puede encontrar muy buena documentación sobre Looper y Concord ya que es importante hacer notar que la integración continua con AzureDevops está quedando sin soporte por parte de Bentonville y esta siendo sustituida por looper y concord, razón de mas que nos mueve a alinearnos.

+ [Documentación de Looper y Concord](https://confluence.walmart.com/pages/viewpage.action?spaceKey=CAMARCH&title=AspNetCore)

+ [Cursos de Looper y Concord](https://strati.walmart.com/training/recordings.html)

> | ⚠️WARNING: Es requisito que se lleven los cursos de looper y concord.


## 14. Historial

### V 1.0.0 Autor: Jhon Samamé Gómez (Vendor)
+ Se crea la solución usando Asp.Net Core 2.1.
+ Se crea la documentación versión inicial.
### v 1.1.0 Autor: Juan Antonio Zúñiga
+ Se añade apartado de AppSettings
+ Se añade apartado de Kibana

---
###### CAM Technology Architecture
