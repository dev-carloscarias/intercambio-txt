import { setPublicPath } from 'systemjs-webpack-interop';

setPublicPath(
    '@provider-portal/clinical-consultation-create-servicing-provider'
);
