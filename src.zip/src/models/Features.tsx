export enum Features {
    CreateClinicalConsultationFeature = 316
}
