export interface ProcedureInterface {
    code: string;
    description: string;
}
