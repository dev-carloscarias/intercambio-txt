export class AuditEventGroups {
    public static ClinicalConsultation = 'ClinicalConsultation';
}
