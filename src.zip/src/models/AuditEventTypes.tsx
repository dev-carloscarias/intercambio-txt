export class AuditEventTypes {
    public static CreateConsultationClick = 'CreateConsultationClick';
    public static ServicingProviderSearch = 'ServicingProviderSearch';
    public static ServicingProviderSearchLoadMore =
        'ServicingProviderSearchLoadMore';
}
