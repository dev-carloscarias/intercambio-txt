export interface DiagnosisInterface {
    code: string;
    description: string;
    isPrimary?: boolean;
}
