export const getCurrentLanguage = () => 'en';
export const getAllLanguages = () => ['en', 'es'];
export const changeLanguage = jest.fn();
export const i18next = jest.fn();
